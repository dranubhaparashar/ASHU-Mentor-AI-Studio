# Renderer adapters

The Streamlit app calls renderer repositories through manifest-driven adapters.

Typical outputs created by the app:

- `script.txt`
- `tts_audio.wav`
- `presenter_source.*`
- `manifest.json`
- `talking_presenter_output.mp4`

You can run renderers from the app UI or manually use the generated ZIP package.
