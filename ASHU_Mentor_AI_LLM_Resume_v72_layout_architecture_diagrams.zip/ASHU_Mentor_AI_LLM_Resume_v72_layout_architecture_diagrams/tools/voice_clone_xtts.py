"""
Consent-based XTTS voice audio generator for ASHU Mentor AI.

Runs in separate conda env, usually:
    conda activate ashu_voice
    python tools/voice_clone_xtts.py --text-file script.txt --speaker my_voice.wav --out tts_audio.wav

Safety: use only your own voice or a voice with written authorization.
"""
from __future__ import annotations

import argparse
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--text-file", required=True, help="UTF-8 text file containing script to speak")
    parser.add_argument("--speaker", required=True, help="Authorized speaker WAV/MP3/WebM sample, ideally 30-90 sec")
    parser.add_argument("--out", required=True, help="Output WAV path")
    parser.add_argument("--model", default="tts_models/multilingual/multi-dataset/xtts_v2")
    parser.add_argument("--device", default="cpu")
    args = parser.parse_args()

    text = Path(args.text_file).read_text(encoding="utf-8").strip()
    speaker = Path(args.speaker).expanduser()
    out = Path(args.out).expanduser()
    out.parent.mkdir(parents=True, exist_ok=True)

    if not text:
        raise SystemExit("Text file is empty")
    if not speaker.exists() or speaker.stat().st_size < 1000:
        raise SystemExit(f"Speaker sample not found or too small: {speaker}")

    from TTS.api import TTS  # type: ignore

    tts = TTS(model_name=args.model).to(args.device)
    tts.tts_to_file(
        text=text,
        speaker_wav=str(speaker),
        language="en",
        file_path=str(out),
    )
    if not out.exists() or out.stat().st_size < 1000:
        raise SystemExit("XTTS completed but output WAV was not created")
    print(out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
