@echo off
mkdir external_renderers 2>nul
cd external_renderers
if not exist SadTalker git clone https://github.com/OpenTalker/SadTalker.git
if not exist Wav2Lip git clone https://github.com/Rudrabha/Wav2Lip.git
if not exist LivePortrait git clone https://github.com/KwaiVGI/LivePortrait.git
if not exist MuseTalk git clone https://github.com/TMElyralab/MuseTalk.git
echo Done. Install each renderer's requirements and checkpoints from its official README.
pause
