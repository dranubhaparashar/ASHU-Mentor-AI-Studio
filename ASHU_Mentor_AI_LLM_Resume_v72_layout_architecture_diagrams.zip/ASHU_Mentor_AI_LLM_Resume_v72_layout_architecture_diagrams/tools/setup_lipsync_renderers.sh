#!/usr/bin/env bash
set -euo pipefail
mkdir -p external_renderers
cd external_renderers

echo "Choose and run only the renderer you need. Model checkpoints are not bundled."
echo "Cloning SadTalker..."
[ -d SadTalker ] || git clone https://github.com/OpenTalker/SadTalker.git

echo "Cloning Wav2Lip..."
[ -d Wav2Lip ] || git clone https://github.com/Rudrabha/Wav2Lip.git

echo "Cloning LivePortrait..."
[ -d LivePortrait ] || git clone https://github.com/KwaiVGI/LivePortrait.git

echo "Cloning MuseTalk..."
[ -d MuseTalk ] || git clone https://github.com/TMElyralab/MuseTalk.git

echo "Done. Install each renderer's requirements and checkpoints from its official README."
