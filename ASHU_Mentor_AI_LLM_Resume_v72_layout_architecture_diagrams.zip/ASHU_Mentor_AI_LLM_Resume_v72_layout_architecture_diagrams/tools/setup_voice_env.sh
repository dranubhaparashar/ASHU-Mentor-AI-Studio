#!/usr/bin/env bash
set -euo pipefail
ENV_NAME="${ASHU_VOICE_ENV:-ashu_voice}"

if ! command -v conda >/dev/null 2>&1; then
  echo "conda not found. Open an Anaconda/Miniconda shell or set CONDA_EXE." >&2
  exit 1
fi

conda create -n "$ENV_NAME" python=3.10 -y || true
conda run -n "$ENV_NAME" python -m pip install --upgrade pip setuptools wheel
conda run -n "$ENV_NAME" python -m pip install "TTS==0.22.0" soundfile pydub

echo "Voice env ready: $ENV_NAME"
echo "Test with: conda run -n $ENV_NAME python -c 'from TTS.api import TTS; print("XTTS import OK")'"
