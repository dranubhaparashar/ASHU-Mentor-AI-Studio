@echo off
set STREAMLIT_SERVER_FILE_WATCHER_TYPE=none
set STREAMLIT_SERVER_RUN_ON_SAVE=false
set STREAMLIT_BROWSER_GATHER_USAGE_STATS=false
streamlit run app.py --server.fileWatcherType none --server.runOnSave false
pause
