# ASHU Mentor AI Studio v45

AI-powered interview, evaluation, digital presenter, lip-sync rendering, and adaptive training platform.

## What v45 fixes

- Removes the nested Streamlit expander error in the lip-sync health panel.
- Adds one-time runtime setup for SadTalker and Wav2Lip inside the app.
- Checks local lip-sync renderers like Ollama.
- Uses:
  - Face photo → SadTalker
  - Presenter video / URL video → Wav2Lip
- Keeps candidate video/proctoring separate from presenter avatar source.

## Run

```bash
cd ASHU_Mentor_AI_LLM_Resume_v45_auto_lipsync_runtime_setup
pip install -r requirements.txt
streamlit run app.py
```

Open:

```text
http://localhost:8501
```

## One-time lip-sync setup

Go to:

```text
Digital Presenter Studio → Local lip-sync runtime
```

Click:

```text
Run one-time setup
```

ASHU will create a local `renderers/` folder, clone SadTalker and Wav2Lip, install requirements, and try to download SadTalker checkpoints.

For Wav2Lip, upload `wav2lip_gan.pth` once in the provided checkpoint uploader if it is not already present.

## Expected folder layout

```text
renderers/
  SadTalker/
    inference.py
    checkpoints/ or gfpgan/weights/...
  Wav2Lip/
    inference.py
    checkpoints/wav2lip_gan.pth
```


## v46 update: persistent training cache

This version adds a persistent cache for expensive deep training generation.

When the user clicks **Generate deep interactive training with PDF notes**, ASHU now:

1. Builds a stable cache key from topic, training source, language, duration, depth, delivery style, presenter identity, resume hash, JD hash, model name, and app version.
2. Checks `cache/training/<cache_key>/` before calling the LLM.
3. Loads existing training instantly if the exact configuration already exists.
4. Generates training only if there is no cache match or **Force regenerate** is checked.
5. Saves generated artifacts:
   - `training_content.json`
   - `training_notes.md`
   - `training_notes.pdf`
   - `slides.json`
   - `quiz.json`
   - `metadata.json`
6. Adds each generated training module to `cache/training/index.json` for quick search/load/delete.

This prevents repeated Ollama generation for the same training topic and configuration.


## v48 TTS and runtime fixes

If neural TTS says `No module named edge_tts`, run:

```bash
pip install -r requirements.txt
pip install edge-tts pyttsx3 imageio-ffmpeg
```

The app also attempts to install missing `edge-tts` / `pyttsx3` automatically on first TTS generation.

Torch `torch.classes` file-watcher warnings are suppressed via `.streamlit/config.toml`.

## Fix for repeated torch.classes Streamlit warning
If the terminal keeps printing:

`Examining the path of torch.classes raised: Tried to instantiate class '__path__._path'...`

run the app using:

```bash
./RUN_LINUX_SILENT.sh
```

or permanently add the Streamlit config:

```bash
./fix_streamlit_torch_warning.sh
```

This warning is caused by Streamlit's file watcher inspecting PyTorch internals. It is not a model/runtime failure. The fix disables Streamlit's file watcher for this app.

## v50 update: auto-filled local lip-sync runtime

ASHU now auto-fills renderer paths from the shared WSL location:

- SadTalker: `/home/anubhaparashar/ashu_renderers/SadTalker`
- Wav2Lip: `/home/anubhaparashar/ashu_renderers/Wav2Lip`
- Wav2Lip checkpoint: `/home/anubhaparashar/ashu_renderers/Wav2Lip/checkpoints/wav2lip_gan.pth`

If your Linux username is different, ASHU uses `~/ashu_renderers` automatically.
You normally do not need to paste renderer paths manually anymore.

The one-time setup button also tries to:

1. Clone SadTalker and Wav2Lip under `~/ashu_renderers`.
2. Install Python-3.10-friendly Wav2Lip dependencies instead of the old original requirements.
3. Download SadTalker checkpoints.
4. Download the Wav2Lip `wav2lip_gan.pth` checkpoint.
5. Re-check local renderer health.

For presenter rendering:

- Uploaded face photo → SadTalker
- Uploaded/URL presenter video → Wav2Lip

Use the silent launcher to avoid PyTorch watcher messages:

```bash
./RUN_LINUX_SILENT.sh
```

## v53 note: separate voice env

Run the app in `chatbot`. For optional voice-like-me audio, create a separate env:

```bash
cd ASHU_Mentor_AI_LLM_Resume_v53_separate_voice_env_preview
bash tools/setup_voice_env.sh
```

Then run app in chatbot:

```bash
conda activate chatbot
PYTHONNOUSERSITE=1 python -m streamlit run app.py --server.fileWatcherType none
```

The app calls `conda run -n ashu_voice python tools/voice_clone_xtts.py ...` only when an authorized voice sample is enabled.


### v54: Persistent authorized voice sample
- Record or upload a 30–90 second authorized voice sample.
- The sample is saved under `voice_samples/`.
- The latest/default sample is prefetched automatically when the app opens again.
- Use `Prefetch latest saved voice sample`, `Set current as default`, or `Clear selected sample` in the lip-sync panel.
- Voice cloning still runs in the separate `ashu_voice` conda env; the main app runs in `chatbot`.


## v55 update

The training tab now prioritizes the real recorded-voice lecture video path. The old live browser presenter is moved into a collapsed optional demo section and clearly marked as browser speech only. Use Real lip-sync renderer for saved voice sample + SadTalker/Wav2Lip video.


## v56 update

The teaching assistant preview is visible again. It is clearly labeled as a browser demo voice. The real recorded-voice lecture remains the generated SadTalker/Wav2Lip video in the Real lip-sync renderer section.


## v57 update

The local lip-sync renderer now starts as a background job so Streamlit does not freeze during SadTalker/Wav2Lip rendering. The generated voice audio is shown immediately so teaching can start while the final MP4 completes. When the renderer finishes, the app shows the final lecture video and provides a download button for the MP4 containing video + generated audio.


## v58 update

Strict authorized voice mode: when a saved voice sample is selected, the app no longer silently falls back to Edge/browser/neutral TTS. If the separate `ashu_voice` XTTS environment fails, the app shows the real error so the user knows the final lecture is not using their voice.


## v59 update

When authorized voice cloning fails, ASHU now pauses and asks the user what to do. The user can either stop and fix the voice environment/sample, or approve an automated voice fallback so the lecture generation continues. This prevents silent fake voice output while keeping the app usable.


## v60 update

The Candidate Performance & Integrity Capture purpose message has been moved from the top of Tab 0 to a collapsed expander at the bottom, keeping the main UI cleaner while retaining the compliance explanation.


## v61 update

Added an explicit Coqui/XTTS terms checkbox before first-time model download. This prevents the non-interactive EOFError where Coqui asks for Terms of Service in the terminal. When checked, the app sets `COQUI_TOS_AGREED=1` for the voice-generation subprocess.


## v62 update

Added a one-click background lecture pipeline. It starts XTTS voice generation in the background so Streamlit does not freeze. After voice audio is ready, the app can automatically start SadTalker/Wav2Lip background rendering when the user refreshes pipeline status.


## v64 update

Moved System status to the bottom of the sidebar. Added progress bars for the full background voice + video pipeline and background renderer status so users can see that voice generation/rendering is still running. Progress is stage-based: voice generation, audio ready, video rendering, completed.


## v65 update

The Teaching Assistant preview can now use the generated XTTS audio for the selected slide. Once voice generation creates `tts_audio.wav`, the assistant shows a new button: “Play generated XTTS voice in assistant.” This plays the generated voice while animating the assistant, instead of forcing the browser speech voice.


## v66 update

Added visible Pause, Resume, and Stop controls directly under the “Play generated XTTS voice in assistant” button so users do not need to scroll down to control the generated voice playback.


## v67 update

The Teaching Assistant preview can now load the generated SadTalker/Wav2Lip MP4 directly inside the assistant panel. When a rendered MP4 exists for the selected segment, the assistant shows “Play generated video in assistant” plus pause/resume/stop controls.


## v68 update

Teaching Assistant generated voice/video buttons now persist after Streamlit reruns or page refreshes. The app scans the latest `lipsync_renders/training_segment_*` folders for `tts_audio.wav` and `talking_presenter_output.mp4`, so the XTTS/video buttons do not disappear just because session state reset.


## v69 update

Added browser-safe MP4 conversion for generated videos. If a rendered MP4 plays audio but shows a black video area in the Teaching Assistant/browser player, the app now creates/reuses a `_browser.mp4` copy encoded as H.264/yuv420p/AAC with faststart before previewing or embedding it.


## v70 update

Added cached lecture prefetch. The one-click pipeline now looks for the latest generated audio/video for the selected segment and can prefetch it instead of regenerating. A “Force regenerate” checkbox lets users explicitly create a new audio/video render when needed.


## v71 update

Upgraded the Teaching Assistant generated video view into a YouTube-style mini streaming player with native video controls, custom play/pause, 10-second skip, seek bar, time display, speed selector, and volume slider.


## v72 update

Fixed the Teaching Assistant iframe cropping by increasing the component height and enabling internal scroll. Added polished architecture diagrams inside the Technical Architecture tab showing candidate runtime, presenter/voice/video generation, background caching, and evidence/safety flows.
