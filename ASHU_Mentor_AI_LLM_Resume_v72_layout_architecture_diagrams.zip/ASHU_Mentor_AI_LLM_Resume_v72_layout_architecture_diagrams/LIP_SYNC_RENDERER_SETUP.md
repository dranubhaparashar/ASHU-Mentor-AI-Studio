# Local Lip-Sync Runtime Setup

ASHU v45 includes an in-app one-time setup wizard.

## In-app setup

1. Run ASHU.
2. Open **Digital Presenter Studio**.
3. Open **Local lip-sync runtime**.
4. Click **Run one-time setup**.
5. After setup, click **Check renderers now**.

## Renderer routing

| Presenter source | Renderer |
|---|---|
| Authorized face photo | SadTalker |
| Authorized presenter video / YouTube URL | Wav2Lip |

## Notes

SadTalker and Wav2Lip are not background services like Ollama. They are command-line renderers. ASHU marks them ready when the repo, inference file, checkpoints, Python dependencies, and FFmpeg are detected.

Wav2Lip checkpoints are often distributed separately. Upload `wav2lip_gan.pth` or `wav2lip.pth` once using the ASHU UI if automatic setup cannot fetch it.

## v50 auto setup notes

The app now pre-fills renderer paths automatically. Recommended shared WSL folder:

```text
~/ashu_renderers
```

Expected files:

```text
~/ashu_renderers/SadTalker/inference.py
~/ashu_renderers/SadTalker/checkpoints/SadTalker_V0.0.2_256.safetensors
~/ashu_renderers/Wav2Lip/inference.py
~/ashu_renderers/Wav2Lip/checkpoints/wav2lip_gan.pth
```

If these files exist, open ASHU and click **Check renderers now**. The fields should already contain the correct values.
