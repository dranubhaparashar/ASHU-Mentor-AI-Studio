#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
export PYTHONNOUSERSITE=1
export STREAMLIT_SERVER_FILE_WATCHER_TYPE=none
export STREAMLIT_SERVER_RUN_ON_SAVE=false
export STREAMLIT_BROWSER_GATHER_USAGE_STATS=false
python -m streamlit run app.py --server.fileWatcherType none --server.runOnSave false
