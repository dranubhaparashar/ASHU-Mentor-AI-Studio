"""
ASHU Mentor AI Studio
Cached Training Engine + Candidate Insight Engine + Digital Presenter Engine + Auto-Filled Local Lip-Sync Runtime

Run:
    pip install -r requirements.txt
    streamlit run app.py

Open:
    http://localhost:8501

Important safety note:
    Presenter photo/video/URL must be authorized. This app does not support non-consensual
    impersonation. The built-in presenter is the default.
"""

from __future__ import annotations

import base64
import contextlib
import csv
import datetime as dt
import io
import json
import os
import random
import re
import shutil
import subprocess
import sys
import textwrap
import uuid
import zipfile
import math
import hashlib
import importlib.util
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# Prevent Streamlit file watcher from inspecting torch.classes and flooding terminal logs.
os.environ.setdefault("STREAMLIT_SERVER_FILE_WATCHER_TYPE", "none")
os.environ.setdefault("STREAMLIT_SERVER_RUN_ON_SAVE", "false")

import pandas as pd
import numpy as np
import requests
import streamlit as st
from PIL import Image, ImageStat

# Reduce OpenCV/FFmpeg terminal noise before importing cv2.
os.environ.setdefault("OPENCV_LOG_LEVEL", "SILENT")
os.environ.setdefault("OPENCV_FFMPEG_LOGLEVEL", "quiet")

try:
    import cv2
except Exception:  # pragma: no cover
    cv2 = None

try:
    import PyPDF2
except Exception:  # pragma: no cover
    PyPDF2 = None

try:
    import docx
except Exception:  # pragma: no cover
    docx = None

try:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
except Exception:  # pragma: no cover
    SimpleDocTemplate = None


try:
    import yt_dlp
except Exception:  # pragma: no cover
    yt_dlp = None

try:
    import imageio_ffmpeg
except Exception:  # pragma: no cover
    imageio_ffmpeg = None

# Keep OpenCV/FFmpeg codec warnings from flooding the terminal.
os.environ.setdefault("OPENCV_LOG_LEVEL", "SILENT")
if cv2 is not None:
    try:
        cv2.setLogLevel(0)
    except Exception:
        pass

# -----------------------------------------------------------------------------
# Paths
# -----------------------------------------------------------------------------
BASE_DIR = Path(__file__).parent.resolve()
ASSETS_DIR = BASE_DIR / "assets"
DOWNLOAD_DIR = BASE_DIR / "downloads"
RECORDINGS_DIR = BASE_DIR / "recordings"
PRESENTER_DIR = BASE_DIR / "presenter_sources"
VOICE_SAMPLE_DIR = BASE_DIR / "voice_samples"
PROCTOR_DIR = BASE_DIR / "proctoring_artifacts"
REPORT_DIR = BASE_DIR / "report_exports"
LIPSYNC_DIR = BASE_DIR / "lipsync_renders"
CACHE_DIR = BASE_DIR / "cache"

# Default shared renderer location. This is intentionally outside OneDrive/project folders
# because SadTalker/Wav2Lip paths with spaces or sync folders often break subprocesses.
DEFAULT_RENDERER_ROOT = Path(os.environ.get("ASHU_RENDERERS_ROOT", str(Path.home() / "ashu_renderers"))).expanduser()
DEFAULT_SADTALKER_REPO = DEFAULT_RENDERER_ROOT / "SadTalker"
DEFAULT_WAV2LIP_REPO = DEFAULT_RENDERER_ROOT / "Wav2Lip"
DEFAULT_WAV2LIP_CHECKPOINT = DEFAULT_WAV2LIP_REPO / "checkpoints" / "wav2lip_gan.pth"
TRAINING_CACHE_DIR = CACHE_DIR / "training"
RESUME_CACHE_DIR = CACHE_DIR / "resume_profiles"
JD_CACHE_DIR = CACHE_DIR / "jd_profiles"
PRESENTER_CACHE_DIR = CACHE_DIR / "presenter_personas"
for d in [ASSETS_DIR, DOWNLOAD_DIR, RECORDINGS_DIR, PRESENTER_DIR, VOICE_SAMPLE_DIR, PROCTOR_DIR, REPORT_DIR, LIPSYNC_DIR, CACHE_DIR, TRAINING_CACHE_DIR, RESUME_CACHE_DIR, JD_CACHE_DIR, PRESENTER_CACHE_DIR]:
    d.mkdir(parents=True, exist_ok=True)

DEFAULT_PRESENTER_SVG = ASSETS_DIR / "default_presenter.svg"
LOGO_SVG = ASSETS_DIR / "ashu_logo.svg"
VOICE_PROFILE_FILE = VOICE_SAMPLE_DIR / "authorized_voice_profile.json"

# -----------------------------------------------------------------------------
# Streamlit setup
# -----------------------------------------------------------------------------
st.set_page_config(
    page_title="ASHU Mentor AI Studio",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded",
)

CUSTOM_CSS = """
<style>
:root {
  --ashu-navy:#071A3D;
  --ashu-blue:#0B5FFF;
  --ashu-cyan:#35D6FF;
  --ashu-soft:#EEF6FF;
  --ashu-card:#FFFFFF;
}
.block-container {padding-top: 1.1rem; max-width: 1480px;}
.stButton > button {border-radius: 12px; font-weight: 700;}
.stDownloadButton > button {border-radius: 12px; font-weight: 700;}
.hero {
  border-radius: 24px; padding: 22px 26px; color:#fff;
  background: linear-gradient(135deg, #071A3D 0%, #0B5FFF 72%, #35D6FF 100%);
  box-shadow: 0 18px 45px rgba(7, 26, 61, 0.16);
}
.hero h1,.hero h2,.hero h3,.hero p {color:#fff !important;}
.info-box {border-left: 5px solid var(--ashu-blue); background: var(--ashu-soft); padding: 14px 16px; border-radius: 14px;}
.warn-box {border-left: 5px solid #ff8a00; background: #fff7e8; padding: 14px 16px; border-radius: 14px;}
.good-box {border-left: 5px solid #07a35a; background: #eafaf1; padding: 14px 16px; border-radius: 14px;}
.avatar-card {
  border-radius: 22px; padding: 20px; color:#fff; text-align:center;
  background: linear-gradient(135deg,#071A3D,#0B5FFF);
  box-shadow: 0 18px 45px rgba(7, 26, 61, 0.16);
}
.metric-card {
  border-radius: 18px; padding: 18px; background:#fff; border:1px solid #e7eefc;
  min-height: 115px; box-shadow:0 8px 28px rgba(11,95,255,0.06);
}
.round-pill {display:inline-block; border-radius:100px; padding:6px 11px; background:#eef6ff; margin:3px; border:1px solid #cfe4ff;}
.small-muted {color:#607089; font-size:0.92rem;}

.training-chip {
  border-radius: 14px;
  padding: 10px 12px;
  background: #ffffff;
  border: 1px solid #dbeafe;
  box-shadow: 0 6px 18px rgba(11,95,255,0.05);
  margin: 7px 0;
}
.training-chip b {color:#071A3D;}
.training-chip span {color:#607089; font-size:0.82rem;}
.training-track {
  border-radius: 18px;
  padding: 15px;
  background: linear-gradient(135deg,#071A3D,#0B5FFF);
  color:#fff;
  margin-bottom: 10px;
}
.training-track h4,.training-track p {color:#fff !important; margin: 0;}
.topic-card {
  border-radius: 18px;
  padding: 16px;
  background:#fff;
  border:1px solid #e7eefc;
  box-shadow:0 8px 26px rgba(7,26,61,0.06);
  min-height: 145px;
}
.topic-card h4 {margin-top:0; color:#071A3D;}
.topic-card p {color:#607089; font-size:0.92rem;}

.subtopic-box {
  border-radius: 16px;
  padding: 14px;
  background: #F7FBFF;
  border: 1px solid #dbeafe;
  margin: 8px 0;
}
.subtopic-box b {color:#071A3D;}
.module-path {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 10px;
  margin: 10px 0 18px 0;
}
.module-step {
  border-radius: 14px;
  background: linear-gradient(135deg,#071A3D,#0B5FFF);
  color: white;
  padding: 12px;
  min-height: 84px;
}
.module-step b,.module-step span {color:white !important;}
code {white-space: pre-wrap;}
</style>
"""
st.markdown(CUSTOM_CSS, unsafe_allow_html=True)

# -----------------------------------------------------------------------------
# Default files
# -----------------------------------------------------------------------------
if not DEFAULT_PRESENTER_SVG.exists():
    DEFAULT_PRESENTER_SVG.write_text(
        """
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
  <defs>
    <linearGradient id="g" x1="0" x2="1" y1="0" y2="1">
      <stop offset="0" stop-color="#35D6FF"/><stop offset="1" stop-color="#0B5FFF"/>
    </linearGradient>
  </defs>
  <rect width="512" height="512" rx="96" fill="#071A3D"/>
  <circle cx="256" cy="214" r="126" fill="url(#g)"/>
  <circle cx="256" cy="175" r="58" fill="#F4FAFF"/>
  <path d="M148 322c22-74 194-74 216 0 6 20-10 40-31 40H179c-21 0-37-20-31-40z" fill="#F4FAFF"/>
  <path d="M349 178c30 11 55 32 71 59" fill="none" stroke="#35D6FF" stroke-width="18" stroke-linecap="round"/>
  <circle cx="424" cy="246" r="12" fill="#35D6FF"/>
  <text x="256" y="438" text-anchor="middle" font-size="44" font-weight="800" font-family="Arial" fill="#FFFFFF">ASHU</text>
</svg>
        """.strip(),
        encoding="utf-8",
    )

if not LOGO_SVG.exists():
    LOGO_SVG.write_text(
        """
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 900 240">
  <defs><linearGradient id="bg" x1="0" x2="1"><stop offset="0" stop-color="#071A3D"/><stop offset="1" stop-color="#0B5FFF"/></linearGradient></defs>
  <rect width="900" height="240" rx="35" fill="url(#bg)"/>
  <circle cx="115" cy="120" r="72" fill="#0B5FFF"/><circle cx="115" cy="90" r="28" fill="#fff"/>
  <path d="M65 158c18-53 82-53 100 0 4 14-6 27-20 27H85c-14 0-24-13-20-27z" fill="#fff"/>
  <text x="220" y="105" font-family="Arial" font-weight="900" font-size="74" fill="#fff">ASHU</text>
  <text x="222" y="158" font-family="Arial" font-weight="800" font-size="44" fill="#35D6FF">Mentor AI</text>
  <text x="224" y="198" font-family="Arial" font-size="22" fill="#dcecff">Adaptive Smart Human-like Unit</text>
</svg>
        """.strip(),
        encoding="utf-8",
    )


def find_latest_authorized_voice_sample() -> str:
    """Return the most recent saved authorized voice sample path, if available."""
    candidates: List[Path] = []
    try:
        if VOICE_PROFILE_FILE.exists():
            data = json.loads(VOICE_PROFILE_FILE.read_text(encoding="utf-8"))
            saved_path = Path(str(data.get("default_voice_sample_path", ""))).expanduser()
            if saved_path.exists() and saved_path.is_file() and saved_path.stat().st_size > 1000:
                candidates.append(saved_path)
    except Exception:
        pass
    try:
        for pat in ["authorized_voice_*", "*.wav", "*.mp3", "*.m4a", "*.webm", "*.ogg"]:
            for q in VOICE_SAMPLE_DIR.glob(pat):
                if q.is_file() and q.stat().st_size > 1000:
                    candidates.append(q)
    except Exception:
        pass
    if not candidates:
        return ""
    unique = {str(c.resolve()): c for c in candidates}
    latest = max(unique.values(), key=lambda q: q.stat().st_mtime)
    return str(latest)


def persist_authorized_voice_sample(sample_path: str, source: str = "recording") -> None:
    """Persist the chosen voice sample as the default for future app runs."""
    try:
        pth = Path(sample_path).expanduser()
        if not pth.exists():
            return
        VOICE_PROFILE_FILE.write_text(json_dumps({
            "default_voice_sample_path": str(pth),
            "source": source,
            "saved_at": dt.datetime.now().isoformat(timespec="seconds"),
            "size_bytes": pth.stat().st_size,
            "consent": "User-confirmed authorized voice sample for ASHU Mentor AI presenter audio only.",
            "usage": "Prefetch this sample for future voice generation when the user enables authorized voice cloning.",
        }), encoding="utf-8")
    except Exception:
        pass

# -----------------------------------------------------------------------------
# Session state
# -----------------------------------------------------------------------------
def ss_init(key: str, value: Any) -> None:
    if key not in st.session_state:
        st.session_state[key] = value

ss_init("candidate_profile", {})
ss_init("resume_text", "")
ss_init("role_title", "Software Developer")
ss_init("job_description", "")
ss_init("jd_profile", {})
ss_init("interview_basis", "Resume-only")
ss_init("interview_mode", "Fixed 40 questions")
ss_init("resume_questions", [])
ss_init("resume_current_question", None)
ss_init("resume_history", [])
ss_init("face_questions", [])
ss_init("face_current_question", None)
ss_init("face_history", [])
ss_init("coding_questions", [])
ss_init("coding_history", [])
ss_init("training_content", {})
ss_init("lipsync_artifacts", [])
ss_init("last_lipsync_video", "")
ss_init("authorized_voice_sample_path", "")
ss_init("authorized_voice_sample_notice", "")
if not st.session_state.authorized_voice_sample_path:
    _prefetched_voice_sample = find_latest_authorized_voice_sample()
    if _prefetched_voice_sample:
        st.session_state.authorized_voice_sample_path = _prefetched_voice_sample
        st.session_state.authorized_voice_sample_notice = "Prefetched your previously saved authorized voice sample. Tick the voice-sample option to use it."
ss_init("adaptive_recommendations", [])
ss_init("candidate_artifacts", {})
ss_init("candidate_proctor_events", [])
ss_init("presenter_profile", {
    "source_type": "built_in",
    "display_name": "ASHU Synthetic Presenter",
    "consent_confirmed": True,
    "release_id": "BUILT-IN-SYNTHETIC",
    "source_path": str(DEFAULT_PRESENTER_SVG),
    "features": {},
})
ss_init("selected_training_topic", "REST API security and JWT authentication")
ss_init("ollama_ready", False)
ss_init("sadtalker_repo_path", str(DEFAULT_SADTALKER_REPO))
ss_init("wav2lip_repo_path", str(DEFAULT_WAV2LIP_REPO))
ss_init("renderer_health", {})
ss_init("renderer_install_root", str(DEFAULT_RENDERER_ROOT))
ss_init("renderer_setup_log", "")
ss_init("active_presenter_index", 0)
ss_init("live_session_artifacts", {})
ss_init("last_training_cache_key", "")
ss_init("last_training_cache_source", "")


TRAINING_CATALOG = {'Languages': [{'topic': 'C programming',
                'level': 'Beginner → Advanced',
                'outcome': 'Master pointers, arrays, memory management, functions, structures, file handling, and common C interview '
                           'programs.'},
               {'topic': 'C++ programming',
                'level': 'Beginner → Advanced',
                'outcome': 'Learn OOP, STL, templates, memory management, inheritance, polymorphism, and competitive-programming style '
                           'questions.'},
               {'topic': 'Java programming',
                'level': 'Beginner → Advanced',
                'outcome': 'Cover OOP, collections, streams, exception handling, JVM basics, multithreading, and backend interview '
                           'questions.'},
               {'topic': 'Python programming',
                'level': 'Beginner → Advanced',
                'outcome': 'Learn syntax, data structures, OOP, decorators, generators, pandas basics, APIs, scripting, and ML-friendly '
                           'coding.'},
               {'topic': 'PHP web programming',
                'level': 'Beginner → Intermediate',
                'outcome': 'Understand server-side scripting, forms, sessions, database connection, authentication, and secure PHP '
                           'practices.'},
               {'topic': 'JavaScript programming',
                'level': 'Beginner → Advanced',
                'outcome': 'Cover ES6, DOM, async/await, promises, closures, APIs, frontend logic, and full-stack JavaScript patterns.'},
               {'topic': 'HTML',
                'level': 'Beginner',
                'outcome': 'Learn semantic structure, forms, tables, media, accessibility basics, and interview-ready web page design.'},
               {'topic': 'XML',
                'level': 'Beginner → Intermediate',
                'outcome': 'Understand XML syntax, schema concepts, parsing, configuration files, and XML in enterprise integrations.'},
               {'topic': 'CSS',
                'level': 'Beginner → Advanced',
                'outcome': 'Cover layouts, flexbox, grid, responsive design, animations, variables, and modern UI styling.'}],
 'Database': [{'topic': 'PostgreSQL',
               'level': 'Beginner → Advanced',
               'outcome': 'Learn relational design, SQL, indexes, joins, transactions, JSONB, query plans, and performance tuning.'},
              {'topic': 'MS-Access',
               'level': 'Beginner → Intermediate',
               'outcome': 'Understand tables, forms, queries, reports, relationships, and small database application design.'},
              {'topic': 'Oracle Database',
               'level': 'Beginner → Advanced',
               'outcome': 'Cover SQL, PL/SQL basics, indexes, stored procedures, transactions, and enterprise database concepts.'},
              {'topic': 'MySQL',
               'level': 'Beginner → Advanced',
               'outcome': 'Learn schema design, joins, constraints, normalization, indexes, transactions, and backend integration.'},
              {'topic': 'Firebase',
               'level': 'Beginner → Intermediate',
               'outcome': 'Understand Firestore, realtime database, authentication, security rules, hosting, and app integration.'},
              {'topic': 'MongoDB',
               'level': 'Beginner → Advanced',
               'outcome': 'Learn document modeling, CRUD, aggregation, indexing, schema design, and when to use NoSQL.'}],
 'Webserver & Hosting': [{'topic': 'Apache Tomcat',
                          'level': 'Beginner → Intermediate',
                          'outcome': 'Learn Java web deployment, WAR files, servlet container basics, ports, logs, and troubleshooting.'},
                         {'topic': 'Oracle WebLogic',
                          'level': 'Intermediate',
                          'outcome': 'Understand enterprise Java application deployment, domains, managed servers, JDBC, and production '
                                     'configuration.'},
                         {'topic': 'Apache HTTP Server',
                          'level': 'Beginner → Intermediate',
                          'outcome': 'Cover virtual hosts, reverse proxy, SSL, logs, static hosting, and common server configuration.'},
                         {'topic': 'Microsoft IIS',
                          'level': 'Beginner → Intermediate',
                          'outcome': 'Learn Windows web hosting, application pools, bindings, SSL, logs, and deployment basics.'},
                         {'topic': 'Heroku',
                          'level': 'Beginner → Intermediate',
                          'outcome': 'Understand app deployment, Procfile, dynos, environment variables, add-ons, logs, and scaling '
                                     'basics.'}],
 'Cloud Platforms': [{'topic': 'Google Cloud Platform',
                      'level': 'Beginner → Advanced',
                      'outcome': 'Learn compute, storage, IAM, Cloud Run, BigQuery, GKE, monitoring, and cloud architecture basics.'},
                     {'topic': 'ThingSpeak IoT Cloud',
                      'level': 'Beginner → Intermediate',
                      'outcome': 'Understand IoT data ingestion, channels, MATLAB analytics, dashboards, and sensor-data visualization.'},
                     {'topic': 'Xively IoT Platform',
                      'level': 'Beginner → Intermediate',
                      'outcome': 'Learn IoT device connectivity concepts, telemetry flow, dashboards, and historical IoT platform '
                                 'architecture.'},
                     {'topic': 'IBM Bluemix / IBM Cloud',
                      'level': 'Beginner → Intermediate',
                      'outcome': 'Understand cloud services, app deployment, Watson integrations, container services, and cloud-native '
                                 'concepts.'},
                     {'topic': 'Microsoft Azure',
                      'level': 'Beginner → Advanced',
                      'outcome': 'Cover Azure App Service, Container Apps, Functions, Storage, Key Vault, DevOps, monitoring, and '
                                 'enterprise deployment.'},
                     {'topic': 'Amazon Web Services',
                      'level': 'Beginner → Advanced',
                      'outcome': 'Learn EC2, S3, Lambda, RDS, IAM, VPC, CloudWatch, containers, and scalable cloud architecture.'}],
 'Hardware Platforms & Embedded Systems': [{'topic': 'Jetson Nano',
                                            'level': 'Intermediate',
                                            'outcome': 'Learn edge AI deployment, camera pipelines, CUDA basics, model inference, and '
                                                       'embedded vision workflows.'},
                                           {'topic': 'Arduino',
                                            'level': 'Beginner → Intermediate',
                                            'outcome': 'Understand sensors, actuators, serial communication, GPIO, PWM, and embedded '
                                                       'prototyping.'},
                                           {'topic': 'Raspberry Pi',
                                            'level': 'Beginner → Intermediate',
                                            'outcome': 'Learn Linux-based IoT, GPIO, camera projects, Python automation, and edge '
                                                       'computing.'},
                                           {'topic': 'Orange Pi',
                                            'level': 'Beginner → Intermediate',
                                            'outcome': 'Understand single-board computer setup, Linux, GPIO, networking, and embedded '
                                                       'application use cases.'},
                                           {'topic': 'Intel Edison',
                                            'level': 'Intermediate',
                                            'outcome': 'Learn legacy IoT prototyping concepts, Linux setup, sensors, connectivity, and '
                                                       'embedded cloud integration.'},
                                           {'topic': '8051 Microcontroller',
                                            'level': 'Beginner → Intermediate',
                                            'outcome': 'Cover architecture, registers, timers, interrupts, serial communication, and '
                                                       'assembly/C programming.'},
                                           {'topic': 'STM32F401 NUCLEO',
                                            'level': 'Intermediate',
                                            'outcome': 'Learn ARM Cortex-M programming, GPIO, timers, UART, ADC, interrupts, and STM32Cube '
                                                       'basics.'},
                                           {'topic': 'AVR XMEGA',
                                            'level': 'Intermediate',
                                            'outcome': 'Understand AVR architecture, peripherals, timers, communication protocols, and '
                                                       'embedded C programming.'},
                                           {'topic': 'AVR Dragon',
                                            'level': 'Intermediate',
                                            'outcome': 'Learn AVR debugging/programming workflows, flashing, hardware debugging, and '
                                                       'embedded development setup.'},
                                           {'topic': 'ATMEL SAM4L Xplained Pro',
                                            'level': 'Intermediate',
                                            'outcome': 'Cover ARM-based microcontroller development, low-power design, peripherals, and '
                                                       'embedded application workflows.'},
                                           {'topic': 'TIVA C TM4C123G',
                                            'level': 'Intermediate',
                                            'outcome': 'Learn ARM Cortex-M4 basics, GPIO, timers, UART, ADC, PWM, and real-time embedded '
                                                       'applications.'},
                                           {'topic': 'FRDM-K64F NXP',
                                            'level': 'Intermediate',
                                            'outcome': 'Understand ARM Cortex-M development, mbed concepts, sensors, networking, and '
                                                       'embedded systems prototyping.'},
                                           {'topic': 'Lolin NodeMCU',
                                            'level': 'Beginner → Intermediate',
                                            'outcome': 'Learn ESP8266/NodeMCU Wi-Fi IoT projects, MQTT/HTTP, sensor data, and cloud '
                                                       'dashboard integration.'},
                                           {'topic': '8086 Microprocessor',
                                            'level': 'Beginner → Intermediate',
                                            'outcome': 'Cover architecture, registers, addressing modes, instruction set, assembly '
                                                       'programming, and interrupts.'}],
 'Operating Systems': [{'topic': 'Windows XP',
                        'level': 'Foundational',
                        'outcome': 'Understand legacy Windows concepts, file system, services, networking basics, and compatibility '
                                   'context.'},
                       {'topic': 'Windows 7',
                        'level': 'Foundational',
                        'outcome': 'Learn user administration, networking, basic troubleshooting, processes, and system configuration.'},
                       {'topic': 'Windows 10',
                        'level': 'Beginner → Intermediate',
                        'outcome': 'Cover OS navigation, environment variables, networking, services, security settings, and developer '
                                   'setup.'},
                       {'topic': 'Linux Red Hat',
                        'level': 'Beginner → Advanced',
                        'outcome': 'Learn shell, users, permissions, services, package management, logs, networking, and enterprise Linux '
                                   'administration.'},
                       {'topic': 'Linux Ubuntu',
                        'level': 'Beginner → Advanced',
                        'outcome': 'Cover shell commands, apt, services, permissions, Python setup, Docker, logs, and developer '
                                   'workflows.'},
                       {'topic': 'UNIX',
                        'level': 'Foundational → Intermediate',
                        'outcome': 'Understand UNIX philosophy, shell, processes, files, permissions, pipes, and scripting concepts.'},
                       {'topic': 'DOS',
                        'level': 'Foundational',
                        'outcome': 'Learn command-line basics, file operations, batch scripts, and legacy system concepts.'},
                       {'topic': 'Raspbian',
                        'level': 'Beginner → Intermediate',
                        'outcome': 'Understand Raspberry Pi OS setup, GPIO workflows, Python, networking, and IoT deployment.'}],
 'Core Computer Science Subjects': [{'topic': 'Theory of Computation',
                                     'level': 'Academic → Interview',
                                     'outcome': 'Learn finite automata, regular languages, CFGs, Turing machines, decidability, and '
                                                'complexity basics.'},
                                    {'topic': 'Compiler Design',
                                     'level': 'Academic → Interview',
                                     'outcome': 'Cover lexical analysis, parsing, syntax trees, semantic analysis, intermediate code, '
                                                'optimization, and code generation.'},
                                    {'topic': 'Data Structures',
                                     'level': 'Beginner → Advanced',
                                     'outcome': 'Master arrays, linked lists, stacks, queues, trees, graphs, heaps, hash tables, and '
                                                'interview patterns.'},
                                    {'topic': 'Algorithms',
                                     'level': 'Beginner → Advanced',
                                     'outcome': 'Learn sorting, searching, recursion, DP, greedy, graph algorithms, complexity, and '
                                                'problem-solving strategy.'},
                                    {'topic': 'Operating System Concepts',
                                     'level': 'Academic → Interview',
                                     'outcome': 'Cover processes, threads, scheduling, synchronization, memory management, deadlock, file '
                                                'systems, and virtualization.'},
                                    {'topic': 'Computer Networks',
                                     'level': 'Academic → Interview',
                                     'outcome': 'Learn OSI/TCP-IP, IP addressing, routing, DNS, HTTP, TLS, congestion control, and network '
                                                'troubleshooting.'},
                                    {'topic': 'Internet Technology',
                                     'level': 'Beginner → Intermediate',
                                     'outcome': 'Understand web protocols, HTTP, DNS, browsers, servers, APIs, security, cookies, and web '
                                                'architecture.'},
                                    {'topic': 'Microprocessor',
                                     'level': 'Academic → Practical',
                                     'outcome': 'Cover CPU architecture, registers, instruction sets, addressing modes, assembly, '
                                                'interrupts, and interfacing.'},
                                    {'topic': 'DBMS',
                                     'level': 'Academic → Interview',
                                     'outcome': 'Learn relational model, normalization, SQL, transactions, concurrency, indexing, '
                                                'recovery, and query optimization.'},
                                    {'topic': 'Software Engineering',
                                     'level': 'Academic → Practical',
                                     'outcome': 'Cover SDLC, requirements, design, UML, testing, maintenance, Agile, estimation, and '
                                                'project documentation.'},
                                    {'topic': 'Web Development',
                                     'level': 'Beginner → Advanced',
                                     'outcome': 'Learn frontend, backend, APIs, authentication, deployment, databases, responsive UI, and '
                                                'production debugging.'}],
 'GenAI & Agentic AI': [{'topic': 'LLM Agents',
                         'level': 'Intermediate → Advanced',
                         'outcome': 'Understand tool use, planning, memory, function calling, orchestration, evaluation, and production '
                                    'safeguards.'},
                        {'topic': 'Agentic AI',
                         'level': 'Intermediate → Advanced',
                         'outcome': 'Learn autonomous workflows, multi-agent systems, state management, human approval, and governance.'},
                        {'topic': 'LangChain',
                         'level': 'Beginner → Advanced',
                         'outcome': 'Build chains, retrievers, tools, agents, memory, callbacks, and RAG applications.'},
                        {'topic': 'RAG',
                         'level': 'Beginner → Advanced',
                         'outcome': 'Learn chunking, embeddings, vector search, retrieval evaluation, grounding, citations, and '
                                    'hallucination control.'},
                        {'topic': 'FAISS',
                         'level': 'Intermediate',
                         'outcome': 'Understand vector indexing, similarity search, embeddings, nearest-neighbor search, and RAG '
                                    'integration.'},
                        {'topic': 'DeepSeek',
                         'level': 'Beginner → Intermediate',
                         'outcome': 'Learn model usage patterns, prompting, local/cloud deployment considerations, and evaluation '
                                    'workflows.'},
                        {'topic': 'Google Gemini',
                         'level': 'Beginner → Intermediate',
                         'outcome': 'Understand multimodal prompting, API usage patterns, safety, evaluation, and app integration.'},
                        {'topic': 'GPT-4o',
                         'level': 'Beginner → Intermediate',
                         'outcome': 'Learn multimodal LLM use cases, prompt structure, evaluation, safety, and production integration '
                                    'concepts.'},
                        {'topic': 'LLaMA',
                         'level': 'Beginner → Advanced',
                         'outcome': 'Understand open-weight LLMs, local deployment, quantization, fine-tuning, prompting, and evaluation.'},
                        {'topic': 'HuggingFace',
                         'level': 'Beginner → Advanced',
                         'outcome': 'Learn models, datasets, transformers, inference, spaces, pipelines, fine-tuning, and deployment.'},
                        {'topic': 'MCP',
                         'level': 'Intermediate → Advanced',
                         'outcome': 'Understand Model Context Protocol concepts, tool integration, context access, connectors, and agent '
                                    'interoperability.'},
                        {'topic': 'gRPC',
                         'level': 'Intermediate',
                         'outcome': 'Learn service definitions, stubs, streaming, deadlines, errors, and high-performance microservice '
                                    'communication.'},
                        {'topic': 'Protobuf',
                         'level': 'Intermediate',
                         'outcome': 'Understand schema design, serialization, backward compatibility, code generation, and API '
                                    'contracts.'}],
 'Optimization & MLOps': [{'topic': 'OR-Tools',
                           'level': 'Intermediate',
                           'outcome': 'Learn constraint programming, routing, scheduling, assignment, objective functions, and '
                                      'optimization modeling.'},
                          {'topic': 'PyVRP',
                           'level': 'Intermediate → Advanced',
                           'outcome': 'Understand vehicle routing, constraints, local search, benchmarks, solution quality, and '
                                      'experimentation.'},
                          {'topic': 'Ant Colony Optimization',
                           'level': 'Intermediate',
                           'outcome': 'Learn pheromone trails, heuristic desirability, exploration/exploitation, parameter tuning, and '
                                      'routing applications.'},
                          {'topic': 'INT4 Quantization',
                           'level': 'Advanced',
                           'outcome': 'Understand low-bit inference, memory savings, accuracy trade-offs, calibration, and LLM '
                                      'deployment.'},
                          {'topic': 'Low-Rank Adaptation',
                           'level': 'Intermediate → Advanced',
                           'outcome': 'Learn LoRA fine-tuning, adapters, rank selection, PEFT workflows, and deployment trade-offs.'},
                          {'topic': 'FastAPI',
                           'level': 'Beginner → Advanced',
                           'outcome': 'Build production APIs, validation, dependency injection, security, async endpoints, testing, and '
                                      'deployment.'},
                          {'topic': 'Streamlit',
                           'level': 'Beginner → Advanced',
                           'outcome': 'Create interactive data/AI apps, session state, file upload, custom components, and deployment '
                                      'workflows.'},
                          {'topic': 'Docker',
                           'level': 'Beginner → Advanced',
                           'outcome': 'Learn images, containers, Dockerfile, compose, volumes, networking, registries, and production best '
                                      'practices.'},
                          {'topic': 'CI/CD',
                           'level': 'Beginner → Advanced',
                           'outcome': 'Understand pipelines, testing, linting, artifacts, approvals, deployments, rollback, and quality '
                                      'gates.'},
                          {'topic': 'MLOps',
                           'level': 'Intermediate → Advanced',
                           'outcome': 'Cover experiment tracking, model registry, pipelines, drift, monitoring, deployment, governance, '
                                      'and reproducibility.'},
                          {'topic': 'Azure Container Apps',
                           'level': 'Intermediate',
                           'outcome': 'Deploy containerized APIs, revisions, scaling, environment variables, secrets, logs, and '
                                      'monitoring.'},
                          {'topic': 'Snowflake',
                           'level': 'Beginner → Advanced',
                           'outcome': 'Learn warehouses, databases, schemas, SQL, data loading, views, security, and analytics workflows.'},
                          {'topic': 'Redis',
                           'level': 'Beginner → Intermediate',
                           'outcome': 'Understand caching, TTL, pub/sub, queues, sessions, rate limiting, and performance use cases.'},
                          {'topic': 'pgvector',
                           'level': 'Intermediate',
                           'outcome': 'Learn vector storage in PostgreSQL, embeddings, similarity search, indexes, and RAG architecture.'}],
 'Software Tools & Frameworks': [{'topic': 'MATLAB',
                                  'level': 'Beginner → Advanced',
                                  'outcome': 'Learn numerical computing, signal/image processing, plotting, scripting, Simulink basics, '
                                             'and research prototyping.'},
                                 {'topic': 'GitHub',
                                  'level': 'Beginner → Advanced',
                                  'outcome': 'Cover Git workflows, branches, PRs, issues, actions, releases, README, and collaboration.'},
                                 {'topic': 'LaTeX',
                                  'level': 'Beginner → Advanced',
                                  'outcome': 'Write research papers, equations, tables, figures, bibliographies, IEEE/Elsevier templates, '
                                             'and publication-ready documents.'},
                                 {'topic': 'Weka',
                                  'level': 'Beginner → Intermediate',
                                  'outcome': 'Learn classical ML workflows, preprocessing, classifiers, evaluation, feature selection, and '
                                             'experiment comparison.'},
                                 {'topic': 'PyTorch',
                                  'level': 'Beginner → Advanced',
                                  'outcome': 'Build neural networks, datasets, training loops, GPU usage, transfer learning, and model '
                                             'deployment.'},
                                 {'topic': 'Caffe',
                                  'level': 'Intermediate',
                                  'outcome': 'Understand deep-learning model definitions, training, inference, and legacy CNN workflows.'},
                                 {'topic': 'OpenCV',
                                  'level': 'Beginner → Advanced',
                                  'outcome': 'Learn image/video processing, camera capture, face detection, transformations, feature '
                                             'extraction, and computer vision pipelines.'},
                                 {'topic': 'DLIB',
                                  'level': 'Intermediate',
                                  'outcome': 'Understand face landmarks, face recognition, HOG/CNN detectors, tracking, and classical CV '
                                             'utilities.'},
                                 {'topic': 'Anaconda',
                                  'level': 'Beginner → Intermediate',
                                  'outcome': 'Manage Python environments, packages, notebooks, and reproducible data science setups.'},
                                 {'topic': 'Google Colab',
                                  'level': 'Beginner → Intermediate',
                                  'outcome': 'Use cloud notebooks, GPUs, Drive integration, experiments, and ML prototyping.'},
                                 {'topic': 'Django',
                                  'level': 'Beginner → Advanced',
                                  'outcome': 'Build web apps, models, views, templates, admin, authentication, REST integration, and '
                                             'deployment.'},
                                 {'topic': 'TensorFlow',
                                  'level': 'Beginner → Advanced',
                                  'outcome': 'Create ML/deep-learning models, datasets, training, Keras workflows, serving, and '
                                             'deployment.'},
                                 {'topic': 'Spyder',
                                  'level': 'Beginner',
                                  'outcome': 'Use scientific Python IDE workflows, variable explorer, debugging, and script execution.'},
                                 {'topic': 'Jupyter Notebook',
                                  'level': 'Beginner → Advanced',
                                  'outcome': 'Create notebooks for data analysis, visualization, ML experiments, documentation, and '
                                             'reproducible workflows.'},
                                 {'topic': 'Sublime Text',
                                  'level': 'Beginner',
                                  'outcome': 'Use a lightweight code editor, packages, shortcuts, and productivity workflows.'},
                                 {'topic': 'Webots',
                                  'level': 'Intermediate',
                                  'outcome': 'Simulate robots, sensors, controllers, environments, and robotics experiments.'},
                                 {'topic': 'OpenSim',
                                  'level': 'Intermediate',
                                  'outcome': 'Understand musculoskeletal modeling, biomechanics simulation, gait analysis, and movement '
                                             'studies.'},
                                 {'topic': 'Choregraphe',
                                  'level': 'Beginner → Intermediate',
                                  'outcome': 'Program NAO/Pepper robots, behaviors, animations, dialog, and humanoid robotics demos.'},
                                 {'topic': 'RemoteXY',
                                  'level': 'Beginner → Intermediate',
                                  'outcome': 'Create mobile control interfaces for Arduino/IoT projects and embedded prototypes.'},
                                 {'topic': 'Arduino Studio',
                                  'level': 'Beginner → Intermediate',
                                  'outcome': 'Develop embedded sketches, upload firmware, debug serial output, and manage libraries.'},
                                 {'topic': 'Node.js',
                                  'level': 'Beginner → Advanced',
                                  'outcome': 'Build JavaScript backends, APIs, npm workflows, async programming, and server-side '
                                             'applications.'},
                                 {'topic': 'Flask',
                                  'level': 'Beginner → Advanced',
                                  'outcome': 'Build lightweight Python APIs/apps, routing, templates, REST endpoints, and deployment.'},
                                 {'topic': 'MobaXterm',
                                  'level': 'Beginner → Intermediate',
                                  'outcome': 'Use SSH, SFTP, terminal sessions, tunneling, and remote Linux server workflows.'},
                                 {'topic': 'Flutter',
                                  'level': 'Beginner → Intermediate',
                                  'outcome': 'Build cross-platform mobile apps, widgets, state management, APIs, and Firebase '
                                             'integration.'},
                                 {'topic': 'NetBeans',
                                  'level': 'Beginner',
                                  'outcome': 'Use Java IDE workflows, projects, debugging, and desktop/web application development.'},
                                 {'topic': 'Eclipse',
                                  'level': 'Beginner → Intermediate',
                                  'outcome': 'Use Java development workflows, projects, debugging, plugins, and enterprise development '
                                             'setup.'},
                                 {'topic': 'Android Studio',
                                  'level': 'Beginner → Intermediate',
                                  'outcome': 'Build Android apps, layouts, activities, Gradle, emulators, debugging, and deployment.'},
                                 {'topic': 'SmartDraw',
                                  'level': 'Beginner',
                                  'outcome': 'Create diagrams, flowcharts, architecture visuals, and process documentation.'},
                                 {'topic': 'RationalRose',
                                  'level': 'Beginner → Intermediate',
                                  'outcome': 'Create UML diagrams, object-oriented design models, and software-engineering documentation.'},
                                 {'topic': 'StarUML',
                                  'level': 'Beginner → Intermediate',
                                  'outcome': 'Design UML class, sequence, use-case, activity, and architecture diagrams.'},
                                 {'topic': 'Microsoft Visio',
                                  'level': 'Beginner → Intermediate',
                                  'outcome': 'Create professional system diagrams, flowcharts, architecture diagrams, and business process '
                                             'visuals.'},
                                 {'topic': 'Selenium',
                                  'level': 'Beginner → Intermediate',
                                  'outcome': 'Automate browser testing, locators, waits, test scripts, and regression workflows.'},
                                 {'topic': 'Photoshop',
                                  'level': 'Beginner → Intermediate',
                                  'outcome': 'Learn image editing, layers, masks, UI assets, and design cleanup workflows.'},
                                 {'topic': 'Flash',
                                  'level': 'Foundational',
                                  'outcome': 'Understand legacy animation workflows, timeline animation, vector assets, and historical web '
                                             'multimedia context.'},
                                 {'topic': 'Blender',
                                  'level': 'Beginner → Intermediate',
                                  'outcome': 'Create 3D models, animations, lighting, rendering, and visual assets for demos.'},
                                 {'topic': 'Vegas Pro',
                                  'level': 'Beginner → Intermediate',
                                  'outcome': 'Edit video, audio, transitions, timelines, rendering, and training/interview media clips.'}],
 'Research Interests & Advanced AI Areas': [{'topic': 'Deep Learning',
                                             'level': 'Beginner → Advanced',
                                             'outcome': 'Understand neural networks, CNNs, RNNs, transformers, optimization, '
                                                        'regularization, and practical applications.'},
                                            {'topic': 'Computer Vision',
                                             'level': 'Beginner → Advanced',
                                             'outcome': 'Learn image processing, object detection, segmentation, tracking, recognition, '
                                                        'and video analytics.'},
                                            {'topic': 'Machine Learning',
                                             'level': 'Beginner → Advanced',
                                             'outcome': 'Cover supervised/unsupervised learning, model evaluation, feature engineering, '
                                                        'overfitting, and deployment basics.'},
                                            {'topic': 'Artificial Intelligence',
                                             'level': 'Beginner → Advanced',
                                             'outcome': 'Understand search, reasoning, learning, perception, NLP, planning, and applied '
                                                        'intelligent systems.'},
                                            {'topic': 'Neural Network',
                                             'level': 'Beginner → Advanced',
                                             'outcome': 'Learn perceptrons, activations, loss functions, backpropagation, architectures, '
                                                        'and training strategies.'},
                                            {'topic': 'Data Science',
                                             'level': 'Beginner → Advanced',
                                             'outcome': 'Cover data cleaning, EDA, visualization, statistics, modeling, dashboards, and '
                                                        'business interpretation.'},
                                            {'topic': 'Internet of Things',
                                             'level': 'Beginner → Advanced',
                                             'outcome': 'Learn sensors, connectivity, MQTT/HTTP, edge devices, cloud dashboards, and IoT '
                                                        'analytics.'},
                                            {'topic': 'Internet of Everything',
                                             'level': 'Intermediate',
                                             'outcome': 'Understand people/process/data/things integration, intelligent connected systems, '
                                                        'and enterprise IoE use cases.'},
                                            {'topic': 'Robotics',
                                             'level': 'Beginner → Advanced',
                                             'outcome': 'Cover sensors, actuators, kinematics, control, navigation, simulation, and robot '
                                                        'intelligence.'},
                                            {'topic': 'Bipedal Locomotion',
                                             'level': 'Intermediate → Advanced',
                                             'outcome': 'Understand gait cycles, stability, humanoid walking, biomechanics, balance, and '
                                                        'locomotion control.'},
                                            {'topic': 'Biometrics Gait',
                                             'level': 'Intermediate → Advanced',
                                             'outcome': 'Learn gait recognition, covariates, silhouettes, pose, sensors, datasets, '
                                                        'evaluation metrics, and privacy.'},
                                            {'topic': 'Humanoid Robotics',
                                             'level': 'Intermediate',
                                             'outcome': 'Understand humanoid platforms, motion planning, perception, balance, HRI, and '
                                                        'behavior design.'},
                                            {'topic': 'Digital Image Processing',
                                             'level': 'Beginner → Advanced',
                                             'outcome': 'Learn filtering, enhancement, segmentation, transforms, feature extraction, and '
                                                        'image analysis.'},
                                            {'topic': 'Natural Language Processing',
                                             'level': 'Beginner → Advanced',
                                             'outcome': 'Cover text preprocessing, embeddings, transformers, language models, information '
                                                        'extraction, and evaluation.'},
                                            {'topic': 'Brain Computer Interface',
                                             'level': 'Intermediate',
                                             'outcome': 'Understand EEG signals, feature extraction, classification, assistive systems, '
                                                        'and human-machine interaction.'},
                                            {'topic': 'Human Computer Interaction',
                                             'level': 'Beginner → Advanced',
                                             'outcome': 'Learn usability, interaction design, accessibility, user studies, UX evaluation, '
                                                        'and human-centered systems.'}],
 'Interview Communication & Career Readiness': [{'topic': 'How to explain project ownership in interviews',
                                                 'level': 'All levels',
                                                 'outcome': 'Answer with problem, architecture, implementation, challenges, measurable '
                                                            'result, and your exact contribution.'},
                                                {'topic': 'STAR method for behavioral interviews',
                                                 'level': 'All levels',
                                                 'outcome': 'Structure Situation, Task, Action, Result answers with evidence and '
                                                            'confidence.'},
                                                {'topic': 'Technical storytelling for resume projects',
                                                 'level': 'All levels',
                                                 'outcome': 'Turn resume bullets into credible technical narratives with architecture, '
                                                            'trade-offs, and outcomes.'},
                                                {'topic': 'Mock viva preparation for project defense',
                                                 'level': 'All levels',
                                                 'outcome': 'Prepare objective, methodology, limitations, validation, future scope, and '
                                                            'cross-question answers.'},
                                                {'topic': 'Resume deep-dive interview preparation',
                                                 'level': 'All levels',
                                                 'outcome': 'Prepare every resume bullet with project context, tools, technical details, '
                                                            'challenges, and results.'},
                                                {'topic': 'Face-to-face technical confidence',
                                                 'level': 'All levels',
                                                 'outcome': 'Practice clear, calm, precise explanations while handling probing technical '
                                                            'questions.'}]}

def set_training_topic(topic: str) -> None:
    st.session_state.selected_training_topic = topic
    st.session_state.training_content = {}


def sidebar_training_hub() -> None:
    st.markdown("### Structured Training Hub")
    current_topic = st.session_state.get("selected_training_topic", "")
    st.markdown(
        f"""
<div class='training-track'>
  <h4>Current training topic</h4>
  <p>{current_topic}</p>
</div>
""",
        unsafe_allow_html=True,
    )
    quick_topics = [
        "Java programming",
        "Python programming",
        "Data Structures",
        "Algorithms",
        "DBMS",
        "Computer Networks",
        "REST API security and JWT authentication",
        "LLM Agents",
        "RAG",
        "Docker",
        "Microsoft Azure",
        "Machine Learning",
    ]
    for idx, topic in enumerate(quick_topics):
        if st.button(topic, key=f"sb_quick_topic_{idx}"):
            set_training_topic(topic)
            st.toast(f"Training topic selected: {topic}")
    with st.expander("Browse training catalog", expanded=False):
        for category, topics in TRAINING_CATALOG.items():
            st.markdown(f"**{category}**")
            for idx, item in enumerate(topics):
                st.markdown(
                    f"""
<div class='training-chip'>
  <b>{item['topic']}</b><br>
  <span>{item['level']} · {item['outcome']}</span>
</div>
""",
                    unsafe_allow_html=True,
                )
                if st.button("Select", key=f"sb_catalog_{category}_{idx}"):
                    set_training_topic(item["topic"])
                    st.toast(f"Selected: {item['topic']}")


def training_topic_gallery() -> None:
    st.subheader("Interactive training topic gallery")
    st.caption("Choose from a structured catalog covering programming, databases, cloud, embedded systems, core CS, GenAI, MLOps, tools, research areas, and interview skills. ASHU will teach using the selected presenter persona, slides, checkpoints, and quiz.")
    categories = list(TRAINING_CATALOG.keys())
    chosen_category = st.selectbox("Training category", categories, index=0)
    topics = TRAINING_CATALOG.get(chosen_category, [])
    cols = st.columns(2)
    for idx, item in enumerate(topics):
        with cols[idx % 2]:
            st.markdown(
                f"""
<div class='topic-card'>
  <h4>{item['topic']}</h4>
  <p><b>Level:</b> {item['level']}</p>
  <p><b>Outcome:</b> {item['outcome']}</p>
</div>
""",
                unsafe_allow_html=True,
            )
            if st.button(f"Use this topic", key=f"gallery_topic_{chosen_category}_{idx}"):
                set_training_topic(item["topic"])
                st.success(f"Selected training topic: {item['topic']}")


def infer_catalog_category(topic: str) -> str:
    topic_l = (topic or "").strip().lower()
    for category, items in TRAINING_CATALOG.items():
        for item in items:
            if item.get("topic", "").lower() == topic_l:
                return category
    for category, items in TRAINING_CATALOG.items():
        for item in items:
            item_topic = item.get("topic", "").lower()
            if topic_l and (topic_l in item_topic or item_topic in topic_l):
                return category
    return "Custom / Candidate Requested Topic"


def build_deep_subtopics(topic: str) -> List[Dict[str, str]]:
    """Create a deterministic deep module map before the LLM expands it."""
    topic = topic or "Selected Topic"
    category = infer_catalog_category(topic)
    common = [
        ("Foundation", f"Definition, purpose, terminology, and where {topic} is used in real projects."),
        ("Core Concepts", f"Important concepts, internal working, architecture, and mental models for {topic}."),
        ("Implementation", f"Hands-on implementation flow, libraries/tools, setup, configuration, and step-by-step build path."),
        ("Practical Example", f"Project-style walkthrough showing how {topic} is applied in interview and production scenarios."),
        ("Edge Cases", "Common mistakes, tricky cases, debugging symptoms, limitations, and failure modes."),
        ("Security / Quality", "Security risks, validation, testing, reliability, maintainability, and best practices."),
        ("Performance", "Complexity, scalability, optimization, memory/network/database impact, and trade-offs."),
        ("Interview Mastery", "Expected interview questions, ideal answer structure, STAR/project evidence, and follow-up probes."),
        ("Assessment", "Checkpoint questions, coding/design tasks, viva questions, and final quiz."),
    ]
    category_specific = []
    if "Languages" in category:
        category_specific = [
            ("Syntax & Types", "Variables, control flow, functions, modules/classes, exception handling, and I/O."),
            ("Data Structures", "Arrays/lists, maps, sets, strings, files, memory behavior, and standard libraries."),
            ("Coding Practice", "Pattern-based questions, complexity, unit testing, and clean code."),
        ]
    elif "Database" in category or topic.lower() in {"dbms", "mysql", "mongodb", "postgresql", "oracle"}:
        category_specific = [
            ("Data Modeling", "Schema design, relationships, normalization/denormalization, indexing, and constraints."),
            ("Querying", "CRUD, joins/aggregation, transactions, execution plans, and optimization."),
            ("Reliability", "Backup, replication, consistency, security, and production troubleshooting."),
        ]
    elif "Cloud" in category or "DevOps" in category or "MLOps" in category:
        category_specific = [
            ("Cloud Architecture", "Compute, storage, networking, identity, deployment, monitoring, and cost governance."),
            ("CI/CD & Operations", "Build, test, deploy, rollback, observability, secrets, and production readiness."),
            ("Case Study", "Design and deploy a small production-safe service with monitoring and scaling."),
        ]
    elif "GenAI" in category:
        category_specific = [
            ("LLM Fundamentals", "Prompting, embeddings, context windows, hallucination control, and evaluation."),
            ("RAG/Agents", "Retrieval, tools, memory, planning, orchestration, safety, and auditability."),
            ("Production GenAI", "Latency, cost, privacy, guardrails, tracing, deployment, and human review."),
        ]
    elif "Research" in category:
        category_specific = [
            ("Research Foundations", "Problem formulation, literature positioning, datasets, metrics, and baselines."),
            ("Methodology", "Model/pipeline design, experimental setup, ablations, validation, and reproducibility."),
            ("Paper Readiness", "Contribution framing, figures, tables, limitations, and publication-level writing."),
        ]
    elif "Hardware" in category:
        category_specific = [
            ("Board Architecture", "Processor, memory, GPIO, peripherals, communication protocols, and power constraints."),
            ("Embedded Programming", "Firmware setup, sensors, serial/I2C/SPI/UART, interrupts, and debugging."),
            ("IoT Integration", "Data acquisition, edge processing, cloud upload, dashboards, and reliability."),
        ]
    merged = category_specific + common
    return [{"name": name, "detail": detail} for name, detail in merged]


def render_module_deep_dive(topic: str) -> None:
    if not topic:
        return
    category = infer_catalog_category(topic)
    st.markdown("### Module roadmap and subtopics")
    st.caption("ASHU maps every selected topic into a deep learning module before generating the lecture.")
    st.markdown(
        """
<div class='module-path'>
  <div class='module-step'><b>1. Diagnose</b><br><span>Interview/coding gaps and prerequisite knowledge</span></div>
  <div class='module-step'><b>2. Teach</b><br><span>Concepts, implementation, visuals, and examples</span></div>
  <div class='module-step'><b>3. Practice</b><br><span>Checkpoints, coding/design tasks, and viva probes</span></div>
  <div class='module-step'><b>4. Report</b><br><span>PDF notes, quiz, score, and next learning plan</span></div>
</div>
""",
        unsafe_allow_html=True,
    )
    st.info(f"Selected module: **{topic}**  |  Category: **{category}**")
    cols = st.columns(3)
    for i, sub in enumerate(build_deep_subtopics(topic), 1):
        with cols[(i - 1) % 3]:
            st.markdown(
                f"""
<div class='subtopic-box'>
  <b>{i}. {sub['name']}</b><br>
  <span>{sub['detail']}</span>
</div>
""",
                unsafe_allow_html=True,
            )


def training_notes_markdown(training: Dict[str, Any], topic: str = "") -> str:
    title = training.get("title") or f"ASHU Training Notes: {topic}"
    lines = [f"# {title}", "", f"**Topic:** {topic or title}", f"**Generated:** {dt.datetime.now().strftime('%Y-%m-%d %H:%M')}", ""]
    if training.get("learning_objectives"):
        lines += ["## Learning Objectives"]
        for obj in training.get("learning_objectives", []):
            lines.append(f"- {obj}")
        lines.append("")
    if training.get("module_subtopics"):
        lines += ["## Module Subtopics"]
        for idx, item in enumerate(training.get("module_subtopics", []), 1):
            if isinstance(item, dict):
                lines.append(f"{idx}. **{item.get('name','Subtopic')}** — {item.get('detail','')}")
            else:
                lines.append(f"{idx}. {item}")
        lines.append("")
    lines.append("## Lecture Notes")
    for idx, seg in enumerate(training.get("segments", []), 1):
        lines += ["", f"### Segment {idx}: {seg.get('title','')}"]
        if seg.get("slide_bullets"):
            lines.append("**Slide points:**")
            for b in seg.get("slide_bullets", []):
                lines.append(f"- {b}")
        if seg.get("visual_description"):
            lines.append(f"**Visual:** {seg.get('visual_description')}")
        if seg.get("script"):
            lines += ["", "**Trainer script / notes:**", seg.get("script", "")]
        if seg.get("example"):
            lines += ["", "**Example / case study:**", str(seg.get("example"))]
        if seg.get("code_demo"):
            lines += ["", "**Code / pseudo-code demo:**", "```", str(seg.get("code_demo")), "```"]
        if seg.get("checkpoint_question"):
            lines += ["", f"**Checkpoint question:** {seg.get('checkpoint_question')}", f"**Expected answer:** {seg.get('expected_answer','')}"]
    if training.get("quiz"):
        lines += ["", "## Quiz"]
        for idx, q in enumerate(training.get("quiz", []), 1):
            lines.append(f"{idx}. {q.get('question','')}")
            for opt in q.get("options", []):
                lines.append(f"   - {opt}")
            lines.append(f"   **Answer:** {q.get('answer','')}")
            if q.get("explanation"):
                lines.append(f"   **Explanation:** {q.get('explanation')}")
    if training.get("handout"):
        lines += ["", "## Handout", str(training.get("handout"))]
    return "\n".join(lines)


def training_notes_pdf_bytes(training: Dict[str, Any], topic: str = "") -> bytes:
    md = training_notes_markdown(training, topic)
    if SimpleDocTemplate is None:
        return md.encode("utf-8")
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=40, leftMargin=40, topMargin=42, bottomMargin=42)
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="ASHUTitle", parent=styles["Title"], textColor=colors.HexColor("#071A3D"), fontSize=20, leading=24, spaceAfter=16))
    styles.add(ParagraphStyle(name="ASHUH2", parent=styles["Heading2"], textColor=colors.HexColor("#0B5FFF"), fontSize=14, leading=18, spaceBefore=12, spaceAfter=8))
    styles.add(ParagraphStyle(name="ASHUBody", parent=styles["BodyText"], fontSize=9.5, leading=13, spaceAfter=6))
    story = []
    for line in md.splitlines():
        esc = line.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        if line.startswith("# "):
            story.append(Paragraph(esc[2:], styles["ASHUTitle"]))
        elif line.startswith("## "):
            story.append(Paragraph(esc[3:], styles["ASHUH2"]))
        elif line.startswith("### "):
            story.append(Paragraph(esc[4:], styles["Heading3"]))
        elif line.startswith("- "):
            story.append(Paragraph("• " + esc[2:], styles["ASHUBody"]))
        elif re.match(r"^\d+\. ", line):
            story.append(Paragraph(esc, styles["ASHUBody"]))
        elif line.strip() == "```":
            continue
        elif line.strip():
            story.append(Paragraph(esc, styles["ASHUBody"]))
        else:
            story.append(Spacer(1, 5))
    doc.build(story)
    return buffer.getvalue()



def render_pdf_preview(pdf_bytes: bytes, filename: str = "training_notes.pdf") -> None:
    """Show a PDF preview inside Streamlit, with robust fallbacks.

    Some browsers download PDFs instead of opening them. This preview lets the
    candidate see notes immediately inside the app before downloading.
    """
    if not pdf_bytes:
        st.warning("PDF preview is not available because no PDF bytes were generated.")
        return

    b64 = base64.b64encode(pdf_bytes).decode("utf-8")
    st.markdown(
        f"""
        <div style="border:1px solid #d7e3ff;border-radius:16px;overflow:hidden;background:white;">
            <div style="padding:10px 14px;background:#eef6ff;color:#071A3D;font-weight:700;">
                In-app PDF preview: {filename}
            </div>
            <iframe
                src="data:application/pdf;base64,{b64}#toolbar=1&navpanes=0&scrollbar=1"
                width="100%"
                height="720px"
                style="border:0; background:white;">
            </iframe>
        </div>
        <p style="font-size:0.9rem;color:#617089;margin-top:8px;">
            If your browser blocks embedded PDF preview, use the notes preview below or the download button.
        </p>
        """,
        unsafe_allow_html=True,
    )


def render_markdown_notes_preview(notes_md: str) -> None:
    """Readable in-app training-notes preview."""
    if not notes_md:
        st.warning("Notes preview is not available yet.")
        return
    st.markdown("### Training notes preview")
    st.markdown(notes_md)

# -----------------------------------------------------------------------------
# Persistent cache helpers for expensive LLM training generation
# -----------------------------------------------------------------------------
def stable_hash_text(text: str) -> str:
    """Stable short SHA256 key for repeatable cache names."""
    return hashlib.sha256((text or "").encode("utf-8", errors="ignore")).hexdigest()[:24]


def stable_hash_obj(obj: Any) -> str:
    """Stable short SHA256 key for JSON-like payloads."""
    try:
        payload = json.dumps(obj, sort_keys=True, ensure_ascii=False, default=str)
    except Exception:
        payload = str(obj)
    return stable_hash_text(payload)


def cache_write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False, default=str), encoding="utf-8")


def cache_read_json(path: Path, default: Any = None) -> Any:
    try:
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default
    return default


def compute_text_hash(value: str) -> str:
    value = (value or "").strip()
    return stable_hash_text(value) if value else ""


def presenter_cache_identity(profile: Dict[str, Any]) -> str:
    profile = profile or {}
    payload = {
        "source_type": profile.get("source_type", ""),
        "display_name": profile.get("display_name", ""),
        "release_id": profile.get("release_id", ""),
        "source_path": profile.get("source_path", ""),
        "personas": profile.get("features", {}).get("presenter_personas", []),
    }
    return stable_hash_obj(payload)


def build_training_cache_key(
    topic: str,
    source_mode: str,
    language: str,
    duration: int,
    training_depth: str,
    delivery_style: str,
    presenter_profile: Dict[str, Any],
    resume_text: str,
    jd_text: str,
    model_name: str,
    app_version: str = "v46",
) -> str:
    payload = {
        "topic": (topic or "").strip().lower(),
        "source_mode": (source_mode or "").strip().lower(),
        "language": (language or "").strip().lower(),
        "duration": int(duration or 0),
        "training_depth": (training_depth or "").strip().lower(),
        "delivery_style": (delivery_style or "").strip().lower(),
        "presenter_id": presenter_cache_identity(presenter_profile),
        "resume_hash": compute_text_hash(resume_text),
        "jd_hash": compute_text_hash(jd_text),
        "model_name": (model_name or "").strip().lower(),
        "app_version": app_version,
    }
    return stable_hash_obj(payload)


def training_cache_folder(cache_key: str) -> Path:
    return TRAINING_CACHE_DIR / cache_key


def training_cache_exists(cache_key: str) -> bool:
    folder = training_cache_folder(cache_key)
    return (folder / "training_content.json").exists() and (folder / "training_notes.md").exists()


def save_training_cache(cache_key: str, training: Dict[str, Any], topic: str, metadata: Dict[str, Any]) -> None:
    folder = training_cache_folder(cache_key)
    folder.mkdir(parents=True, exist_ok=True)
    notes_md = training_notes_markdown(training, topic)
    pdf_bytes = training_notes_pdf_bytes(training, topic)
    cache_write_json(folder / "training_content.json", training)
    (folder / "training_notes.md").write_text(notes_md, encoding="utf-8")
    if pdf_bytes:
        (folder / "training_notes.pdf").write_bytes(pdf_bytes)
    cache_write_json(folder / "slides.json", training.get("segments", []))
    cache_write_json(folder / "quiz.json", training.get("quiz", []))
    meta = {
        **(metadata or {}),
        "cache_key": cache_key,
        "topic": topic,
        "generated_at": dt.datetime.now().isoformat(timespec="seconds"),
        "cache_folder": str(folder),
    }
    cache_write_json(folder / "metadata.json", meta)
    add_training_cache_index(cache_key, meta)


def load_training_cache(cache_key: str) -> Dict[str, Any]:
    folder = training_cache_folder(cache_key)
    training = cache_read_json(folder / "training_content.json", {}) or {}
    notes_path = folder / "training_notes.md"
    notes_md = notes_path.read_text(encoding="utf-8") if notes_path.exists() else training_notes_markdown(training)
    return {
        "training_content": training,
        "training_notes_md": notes_md,
        "metadata": cache_read_json(folder / "metadata.json", {}) or {},
        "pdf_path": str(folder / "training_notes.pdf") if (folder / "training_notes.pdf").exists() else "",
        "slides_path": str(folder / "slides.json") if (folder / "slides.json").exists() else "",
        "quiz_path": str(folder / "quiz.json") if (folder / "quiz.json").exists() else "",
        "cache_folder": str(folder),
    }


def training_cache_index_path() -> Path:
    return TRAINING_CACHE_DIR / "index.json"


def load_training_cache_index() -> List[Dict[str, Any]]:
    data = cache_read_json(training_cache_index_path(), [])
    return data if isinstance(data, list) else []


def add_training_cache_index(cache_key: str, metadata: Dict[str, Any]) -> None:
    index = load_training_cache_index()
    index = [row for row in index if row.get("cache_key") != cache_key]
    index.insert(0, {
        "cache_key": cache_key,
        "topic": metadata.get("topic", ""),
        "source_mode": metadata.get("source_mode", ""),
        "language": metadata.get("language", ""),
        "duration": metadata.get("duration", ""),
        "training_depth": metadata.get("training_depth", ""),
        "delivery_style": metadata.get("delivery_style", ""),
        "model_name": metadata.get("model_name", ""),
        "generated_at": metadata.get("generated_at", dt.datetime.now().isoformat(timespec="seconds")),
        "cache_folder": metadata.get("cache_folder", str(training_cache_folder(cache_key))),
    })
    cache_write_json(training_cache_index_path(), index[:200])


def clear_training_cache_item(cache_key: str) -> None:
    folder = training_cache_folder(cache_key)
    if folder.exists():
        shutil.rmtree(folder, ignore_errors=True)
    index = [row for row in load_training_cache_index() if row.get("cache_key") != cache_key]
    cache_write_json(training_cache_index_path(), index)


def search_training_cache(topic_query: str) -> List[Dict[str, Any]]:
    q = (topic_query or "").strip().lower()
    rows = load_training_cache_index()
    if not q:
        return rows[:10]
    return [r for r in rows if q in str(r.get("topic", "")).lower()][:10]

# -----------------------------------------------------------------------------
# Utilities
# -----------------------------------------------------------------------------
def now_id() -> str:
    return dt.datetime.now().strftime("%Y%m%d_%H%M%S") + "_" + uuid.uuid4().hex[:6]


def safe_filename(name: str) -> str:
    name = re.sub(r"[^a-zA-Z0-9_.-]+", "_", name).strip("_")
    return name[:160] or f"file_{now_id()}"


def save_uploaded_file(uploaded_file, folder: Path) -> Optional[Path]:
    if not uploaded_file:
        return None
    suffix = Path(uploaded_file.name).suffix.lower()
    out = folder / f"{Path(safe_filename(uploaded_file.name)).stem}_{now_id()}{suffix}"
    out.write_bytes(uploaded_file.getvalue())
    return out


def b64_file(path: Path) -> str:
    return base64.b64encode(path.read_bytes()).decode("utf-8")


def file_mime(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix in [".png"]:
        return "image/png"
    if suffix in [".jpg", ".jpeg"]:
        return "image/jpeg"
    if suffix in [".svg"]:
        return "image/svg+xml"
    if suffix in [".webm"]:
        return "video/webm"
    if suffix in [".mp4", ".m4v"]:
        return "video/mp4"
    return "application/octet-stream"


def read_text_file(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return ""


def extract_resume_text(uploaded_file) -> str:
    if not uploaded_file:
        return ""
    name = uploaded_file.name.lower()
    raw = uploaded_file.getvalue()
    if name.endswith(".txt"):
        return raw.decode("utf-8", errors="ignore")
    if name.endswith(".pdf") and PyPDF2:
        try:
            reader = PyPDF2.PdfReader(io.BytesIO(raw))
            return "\n".join(page.extract_text() or "" for page in reader.pages)
        except Exception as e:
            return f"[PDF extraction failed: {e}]"
    if name.endswith(".docx") and docx:
        try:
            document = docx.Document(io.BytesIO(raw))
            return "\n".join(p.text for p in document.paragraphs)
        except Exception as e:
            return f"[DOCX extraction failed: {e}]"
    return raw[:15000].decode("utf-8", errors="ignore")


def json_dumps(obj: Any) -> str:
    return json.dumps(obj, indent=2, ensure_ascii=False, default=str)


def try_parse_json(text: str) -> Any:
    if not text:
        return None
    cleaned = text.strip()
    cleaned = re.sub(r"^```json\s*", "", cleaned, flags=re.I).strip()
    cleaned = re.sub(r"^```\s*", "", cleaned).strip()
    cleaned = re.sub(r"```$", "", cleaned).strip()
    try:
        return json.loads(cleaned)
    except Exception:
        pass
    # Try extracting first JSON object/array
    for start_char, end_char in [("[", "]"), ("{", "}")]:
        s = cleaned.find(start_char)
        e = cleaned.rfind(end_char)
        if s >= 0 and e > s:
            try:
                return json.loads(cleaned[s : e + 1])
            except Exception:
                continue
    return None

# -----------------------------------------------------------------------------
# Ollama / LLM helpers
# -----------------------------------------------------------------------------
def ollama_generate(prompt: str, model: str = "qwen2.5:7b", temperature: float = 0.2, timeout: int = 120) -> str:
    """Call local Ollama if running; return empty string on failure."""
    try:
        r = requests.post(
            "http://localhost:11434/api/generate",
            json={"model": model, "prompt": prompt, "stream": False, "options": {"temperature": temperature}},
            timeout=timeout,
        )
        if r.status_code == 200:
            return r.json().get("response", "")
    except Exception:
        return ""
    return ""


def check_ollama(model: str) -> Dict[str, Any]:
    status = {"server": False, "model_present": False, "models": [], "message": ""}
    try:
        r = requests.get("http://localhost:11434/api/tags", timeout=4)
        if r.status_code == 200:
            status["server"] = True
            models = [m.get("name", "") for m in r.json().get("models", [])]
            status["models"] = models
            status["model_present"] = model in models
            status["message"] = "Ollama server reachable."
    except Exception as e:
        status["message"] = f"Ollama not reachable: {e}"
    return status


def start_ollama_if_possible() -> None:
    if check_ollama("qwen2.5:7b")["server"]:
        return
    if shutil.which("ollama"):
        try:
            subprocess.Popen(["ollama", "serve"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass


def pull_model_if_possible(model: str) -> None:
    if not shutil.which("ollama"):
        return
    try:
        subprocess.Popen(["ollama", "pull", model], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass

# -----------------------------------------------------------------------------
# Scoring / generation fallbacks
# -----------------------------------------------------------------------------
STOPWORDS = set("the is am are was were a an and or to of in on for with this that it as by from be can will we i you our their my your have has had do does did at into about also".split())


def tokenize(text: str) -> List[str]:
    return [w for w in re.findall(r"[a-zA-Z0-9]+", text.lower()) if w not in STOPWORDS]


def heuristic_score(question: str, answer: str, expected: str = "") -> Dict[str, Any]:
    q_tokens = set(tokenize(question + " " + expected))
    a_tokens = tokenize(answer)
    a_set = set(a_tokens)
    word_count = len(a_tokens)
    relevance = min(20, 8 + 2 * len(q_tokens & a_set))
    completeness = min(20, int(word_count / 4))
    technical_depth = min(20, 5 + 3 * len(re.findall(r"api|jwt|token|database|index|cache|latency|security|auth|model|algorithm|complexity|edge|test|deploy|docker|cloud|thread|async|queue|transaction", answer.lower())))
    evidence = min(20, 5 + 4 * len(re.findall(r"\d+|%|project|implemented|designed|built|optimized|debugged|tested|deployed|result|impact|metric|because|example", answer.lower())))
    communication = 10 if 30 <= word_count <= 220 else 7 if word_count > 10 else 4
    structure = 10 if any(x in answer.lower() for x in ["first", "second", "finally", "because", "example", "result", "approach", "challenge"]) else 6
    overall = min(100, relevance + completeness + technical_depth + evidence + communication + structure)
    band = "Strong" if overall >= 80 else "Good" if overall >= 65 else "Needs improvement" if overall >= 45 else "Weak"
    return {
        "overall_score": overall,
        "score_band": band,
        "rubric": {
            "relevance": relevance,
            "completeness": completeness,
            "technical_depth": technical_depth,
            "evidence_specificity": evidence,
            "communication": communication,
            "structure": structure,
        },
        "strengths": ["Answer is connected to the prompt." if relevance >= 14 else "Some relevance is present."],
        "weaknesses": ["Add more implementation evidence, trade-offs, and measurable details."],
        "missing_evidence": ["Specific architecture choices", "Failure handling", "Metrics/results"],
        "improvement_advice": "Use Problem → Approach → Implementation → Trade-offs → Result. Include exact tools, metrics, and edge cases.",
        "ideal_answer_outline": ["Clarify context", "Explain design", "Mention security/performance", "Give concrete result"],
        "follow_up_question": "Can you give one specific implementation detail and one trade-off you considered?",
        "human_review_required": True,
    }


def llm_evaluate(question: str, answer: str, role: str, expected: str, model: str) -> Dict[str, Any]:
    prompt = f"""
You are ASHU Mentor AI, an interview evaluator. Return ONLY valid JSON.
Evaluate the candidate answer. Do not make final hiring decision. Human review required.

Role: {role}
Question: {question}
Expected evidence: {expected}
Candidate answer: {answer}

JSON schema:
{{
  "overall_score": 0-100,
  "score_band": "Strong|Good|Needs improvement|Weak",
  "rubric": {{
    "relevance": 0-20,
    "correctness": 0-20,
    "technical_depth": 0-20,
    "resume_alignment": 0-15,
    "evidence_specificity": 0-15,
    "communication": 0-10
  }},
  "strengths": ["..."],
  "weaknesses": ["..."],
  "missing_evidence": ["..."],
  "improvement_advice": "...",
  "ideal_answer_outline": ["..."],
  "follow_up_question": "...",
  "human_review_required": true
}}
""".strip()
    raw = ollama_generate(prompt, model=model, temperature=0.1)
    parsed = try_parse_json(raw)
    if isinstance(parsed, dict) and "overall_score" in parsed:
        parsed["raw_llm"] = raw[:4000]
        return parsed
    fallback = heuristic_score(question, answer, expected)
    fallback["llm_fallback_used"] = True
    fallback["raw_llm"] = raw[:4000]
    return fallback


def generate_resume_question(role: str, resume_text: str, jd: str, history: List[Dict], category: str, qnum: int, model: str) -> Dict[str, Any]:
    prompt = f"""
Return ONLY valid JSON for one interview question.
Create a JD-aware + resume-aware interview question for Question {qnum}.
If a JD/domain focus is provided, the question must validate both:
1. candidate evidence from resume, and
2. JD requirement/domain fit.
If no JD is provided, use resume and target role only.

Role: {role}
Question category: {category}
Job description / domain focus: {jd[:3000]}
Resume excerpt: {resume_text[:5000]}
Previously asked questions: {[h.get('question') for h in history[-8:]]}

Schema:
{{
  "question": "...",
  "category": "{category}",
  "difficulty": "easy|medium|hard",
  "why_this_question": "...",
  "expected_evidence": ["..."],
  "red_flags": ["..."],
  "follow_up_if_weak": "...",
  "jd_requirement_tested": "specific JD/domain requirement tested, or resume_only if no JD",
  "jd_alignment": "how this question checks resume + JD fit"
}}
""".strip()
    raw = ollama_generate(prompt, model=model, temperature=0.25)
    parsed = try_parse_json(raw)
    if isinstance(parsed, dict) and parsed.get("question"):
        parsed["raw_llm"] = raw[:3000]
        return parsed
    fallback_questions = {
        "resume_project": "Walk me through one major project from your resume. What was your role, architecture, implementation, and measurable result?",
        "technical_depth": "Explain the most technically challenging part of your previous project and how you solved it.",
        "system_design": "Design a scalable backend for the project mentioned in your resume. Discuss APIs, database, security, caching, and failure handling.",
        "debugging": "Describe a complex bug you debugged in your project. How did you find the root cause and verify the fix?",
        "behavioral": "Tell me about a time when you had to learn a new technology quickly for a project. How did you approach it?",
        "role_specific": f"For a {role} role, what skills from your resume are strongest and what evidence proves them?",
        "adaptive_follow_up": "Can you explain one implementation trade-off in your previous answer and why you chose that approach?",
    }
    return {
        "question": fallback_questions.get(category, fallback_questions["technical_depth"]),
        "category": category,
        "difficulty": "medium",
        "why_this_question": "Fallback question used because LLM did not return valid JSON.",
        "expected_evidence": ["specific implementation", "tools used", "trade-offs", "result/metric"],
        "red_flags": ["generic answer", "no measurable detail", "cannot explain own project"],
        "follow_up_if_weak": "What exactly did you implement yourself?",
        "jd_requirement_tested": "fallback_resume_or_role_requirement",
        "jd_alignment": "Uses JD/domain context when provided; otherwise resume/role aligned.",
        "llm_fallback_used": True,
        "raw_llm": raw[:3000],
    }


def extract_jd_profile(jd_text: str, role: str, model: str) -> Dict[str, Any]:
    """Extract a structured JD/domain profile for JD + resume interview targeting."""
    jd_text = jd_text or ""
    if not jd_text.strip():
        return {}
    prompt = f"""
Return ONLY valid JSON. Extract a structured job/domain profile from the job description.
Target role: {role}
Job description: {jd_text[:7000]}
Schema:
{{
  "domain_summary":"",
  "primary_domain":"",
  "must_have_skills":[],
  "good_to_have_skills":[],
  "tools_platforms":[],
  "responsibilities":[],
  "expected_projects_or_experience":[],
  "coding_focus":[],
  "system_design_focus":[],
  "security_or_compliance_focus":[],
  "training_priorities":[],
  "interview_question_focus":[]
}}
""".strip()
    raw = ollama_generate(prompt, model=model, temperature=0.1)
    parsed = try_parse_json(raw)
    if isinstance(parsed, dict):
        parsed["raw_llm"] = raw[:3000]
        return parsed
    toks = list(dict.fromkeys(tokenize(jd_text)))[:80]
    return {
        "domain_summary": jd_text[:700],
        "primary_domain": role,
        "must_have_skills": toks[:20],
        "good_to_have_skills": toks[20:35],
        "tools_platforms": toks[35:50],
        "responsibilities": [],
        "expected_projects_or_experience": [],
        "coding_focus": toks[:10],
        "system_design_focus": [],
        "security_or_compliance_focus": [],
        "training_priorities": toks[:10],
        "interview_question_focus": toks[:12],
        "llm_fallback_used": True,
    }


def jd_domain_context() -> str:
    """Compact context used by interview, coding and training prompts."""
    jd = st.session_state.get("job_description", "") or ""
    profile = st.session_state.get("jd_profile", {}) or {}
    if not jd.strip() and not profile:
        return "No JD/domain description provided. Use resume and target role only."
    parts = [
        "Interview basis: Resume + optional JD/domain focus",
        f"JD excerpt: {jd[:2000]}",
        f"JD profile: {json_dumps(profile)[:3000]}",
    ]
    return "\n".join(parts)


def jd_match_summary() -> Dict[str, Any]:
    """Quick deterministic summary to show what the interview will prioritize."""
    prof = st.session_state.get("jd_profile", {}) or {}
    return {
        "basis": "Resume + JD/domain" if st.session_state.get("job_description", "").strip() else "Resume-only",
        "target_role": st.session_state.get("role_title", ""),
        "domain": prof.get("primary_domain", "Not provided"),
        "must_have_skills": prof.get("must_have_skills", [])[:12],
        "question_focus": prof.get("interview_question_focus", [])[:10],
        "training_priorities": prof.get("training_priorities", [])[:10],
        "coding_focus": prof.get("coding_focus", [])[:8],
    }


def question_category_for_index(i: int) -> str:
    plan = (
        ["resume_project"] * 8
        + ["technical_depth"] * 8
        + ["system_design"] * 6
        + ["debugging"] * 5
        + ["role_specific"] * 5
        + ["behavioral"] * 4
        + ["adaptive_follow_up"] * 4
    )
    return plan[(i - 1) % len(plan)]


@contextlib.contextmanager
def suppress_native_stderr():
    """Temporarily silence native C/C++ decoder warnings from FFmpeg/OpenCV.

    Some H.264 streams print messages like `mmco: unref short failure` directly
    to the terminal from the native decoder. They are usually non-fatal and can
    flood the VS Code terminal even when the app continues normally. Set
    ASHU_SHOW_CODEC_WARNINGS=1 before launching Streamlit if you want to see
    raw codec diagnostics for debugging.
    """
    if os.environ.get("ASHU_SHOW_CODEC_WARNINGS") == "1":
        yield
        return
    try:
        fd = sys.stderr.fileno()
        saved_fd = os.dup(fd)
        devnull_fd = os.open(os.devnull, os.O_WRONLY)
        os.dup2(devnull_fd, fd)
        os.close(devnull_fd)
        try:
            yield
        finally:
            os.dup2(saved_fd, fd)
            os.close(saved_fd)
    except Exception:
        yield

# -----------------------------------------------------------------------------
# Presenter feature extraction
# -----------------------------------------------------------------------------

def ffmpeg_executable() -> Optional[str]:
    """Return a usable FFmpeg binary path.

    imageio-ffmpeg ships a portable FFmpeg, which is more reliable inside WSL/Windows
    demos than relying on system packages.
    """
    if imageio_ffmpeg is not None:
        try:
            exe = imageio_ffmpeg.get_ffmpeg_exe()
            if exe and Path(exe).exists():
                return exe
        except Exception:
            pass
    return shutil.which("ffmpeg")


def normalize_video_for_analysis(path: Path) -> Tuple[Path, Dict[str, Any]]:
    """Create an OpenCV-safe analysis copy.

    Some YouTube videos are AV1/VP9/H.264 streams with reference-frame issues. OpenCV may
    flood the terminal with messages such as `mmco: unref short failure` or AV1 hardware
    decode errors. For analysis, we do not need the original codec; we need stable frames.
    This function transcodes the video to a lightweight MJPEG AVI using FFmpeg with
    corrupt-frame discard enabled. MJPEG is broadly readable by OpenCV and avoids repeated
    decoder warnings.
    """
    meta: Dict[str, Any] = {"input_path": str(path), "normalization_attempted": False}
    if not path.exists():
        return path, {**meta, "normalization_error": "input file missing"}

    ffmpeg = ffmpeg_executable()
    if not ffmpeg:
        return path, {**meta, "normalization_error": "ffmpeg not found; using original video"}

    out = PRESENTER_DIR / f"analysis_safe_{path.stem}_{now_id()}.avi"
    cmd = [
        ffmpeg,
        "-y",
        "-hide_banner",
        "-loglevel",
        "error",
        "-fflags",
        "+discardcorrupt",
        "-err_detect",
        "ignore_err",
        "-i",
        str(path),
        "-map",
        "0:v:0",
        "-an",
        "-vf",
        "fps=12,scale='min(1280,iw)':-2",
        "-c:v",
        "mjpeg",
        "-q:v",
        "5",
        str(out),
    ]
    meta["normalization_attempted"] = True
    meta["analysis_copy_path"] = str(out)
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=180)
        if proc.returncode == 0 and out.exists() and out.stat().st_size > 0:
            meta.update({"normalization_success": True, "ffmpeg_stderr": proc.stderr[-1200:]})
            return out, meta
        meta.update({"normalization_success": False, "ffmpeg_stderr": (proc.stderr or proc.stdout)[-2000:]})
        return path, meta
    except Exception as e:
        meta.update({"normalization_success": False, "normalization_error": str(e)})
        return path, meta

def analyze_photo(path: Path) -> Dict[str, Any]:
    try:
        img = Image.open(path).convert("RGB")
        stat = ImageStat.Stat(img.convert("L"))
        w, h = img.size
        brightness = round(stat.mean[0], 2)
        contrast = round(stat.stddev[0], 2)
        features = {
            "source_type": "photo",
            "width": w,
            "height": h,
            "brightness": brightness,
            "contrast": contrast,
            "readiness_score": int(min(100, max(30, contrast + (100 - abs(140 - brightness)) / 2))),
            "avatar_readiness_score": int(min(100, max(30, contrast + (100 - abs(140 - brightness)) / 2))),
            "representative_frame_path": str(path),
            "avatar_portrait_path": str(path),
            "review_flags": [],
            "persona_profile": {"visual_style": "photo-based professional presenter", "delivery_energy": "calm/static", "recommended_voice_style": "clear, mentor-like", "presentation_instruction": "Use the uploaded authorized face photo as presenter portrait; production lip-sync can animate it with a consent-approved renderer."},
            "production_lip_sync_adapter": {"status": "manifest_ready_not_rendered_in_lightweight_streamlit_demo", "recommended_renderers": ["LivePortrait", "SadTalker", "MuseTalk", "Wav2Lip"], "input_image": str(path), "input_audio": "TTS audio generated from LLM script", "output": "rendered_talking_presenter_video.mp4"},
            "note": "Photo-based feature-derived presenter persona. For production, add landmarks and consent verification.",
        }
        if w < 400 or h < 400:
            features["review_flags"].append("Low resolution photo")
        if brightness < 45:
            features["review_flags"].append("Low lighting")
        if contrast < 20:
            features["review_flags"].append("Low contrast / possible blur")
        return features
    except Exception as e:
        return {"source_type": "photo", "error": str(e), "readiness_score": 0, "review_flags": ["Photo unreadable"]}


def _load_cv2_face_detector():
    """Load OpenCV's built-in frontal-face detector when available."""
    if cv2 is None:
        return None
    try:
        cascade_path = Path(cv2.data.haarcascades) / "haarcascade_frontalface_default.xml"
        detector = cv2.CascadeClassifier(str(cascade_path))
        if detector.empty():
            return None
        return detector
    except Exception:
        return None


def _detect_faces_in_frame(frame, detector) -> List[Tuple[int, int, int, int]]:
    """Detect faces and return boxes in original-frame coordinates."""
    if detector is None or frame is None:
        return []
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    h, w = gray.shape[:2]
    # Downscale for reliable speed, then map boxes back to original coordinates.
    target_w = 720
    scale = 1.0
    det_gray = gray
    if w > target_w:
        scale = target_w / float(w)
        det_gray = cv2.resize(gray, (target_w, int(h * scale)), interpolation=cv2.INTER_AREA)
    try:
        faces = detector.detectMultiScale(
            det_gray,
            scaleFactor=1.08,
            minNeighbors=5,
            minSize=(36, 36),
            flags=cv2.CASCADE_SCALE_IMAGE,
        )
    except Exception:
        return []
    mapped = []
    for (x, y, fw, fh) in faces:
        if scale != 1.0:
            x, y, fw, fh = int(x / scale), int(y / scale), int(fw / scale), int(fh / scale)
        mapped.append((x, y, fw, fh))
    return mapped


def _crop_presenter_portrait(frame, face_box: Optional[Tuple[int, int, int, int]]):
    """Crop a face-centered presenter portrait from a frame.

    We do not use the first frame. We crop around the best detected face with enough
    head/shoulder context so the presenter looks natural in the UI.
    """
    if frame is None:
        return None
    h, w = frame.shape[:2]
    if not face_box:
        # Fallback: center crop if no face was detected.
        side_w = int(w * 0.55)
        side_h = int(h * 0.75)
        x1 = max(0, (w - side_w) // 2)
        y1 = max(0, (h - side_h) // 2)
        x2 = min(w, x1 + side_w)
        y2 = min(h, y1 + side_h)
        return frame[y1:y2, x1:x2]
    x, y, fw, fh = face_box
    cx = x + fw / 2
    cy = y + fh / 2
    crop_w = max(int(fw * 3.0), 260)
    crop_h = max(int(fh * 4.0), 320)
    # More space below the face for shoulders/upper body.
    x1 = int(cx - crop_w / 2)
    y1 = int(cy - fh * 1.05)
    x2 = x1 + crop_w
    y2 = y1 + crop_h
    x1 = max(0, x1)
    y1 = max(0, y1)
    x2 = min(w, x2)
    y2 = min(h, y2)
    if x2 <= x1 or y2 <= y1:
        return frame
    return frame[y1:y2, x1:x2]


def _voice_profile_for_index(index: int) -> str:
    """Default voice assignment for multi-presenter demos.

    Face images alone should not be treated as reliable gender identity proof.
    The UI exposes editable voice profiles so the admin can set female/male/neutral
    correctly for each authorized presenter.
    """
    return "female" if index % 2 == 0 else "male"


def analyze_video(path: Path, max_frames: int = 260) -> Dict[str, Any]:
    """Analyze an authorized presenter video and build a multi-presenter persona profile.

    This does NOT replay the original YouTube/uploaded video as the interview/training
    speaker. It scans the full clip, detects face-containing frames, selects up to two
    distinct presenter portraits, extracts delivery/quality features, and stores those
    portraits as feature-derived presenter personas. During interview/training the UI
    alternates between detected personas to make delivery more interactive.
    """
    if cv2 is None:
        return {"source_type": "video", "error": "OpenCV unavailable", "avatar_readiness_score": 0, "presenter_personas": []}

    analysis_path, normalization_meta = normalize_video_for_analysis(path)
    with suppress_native_stderr():
        cap = cv2.VideoCapture(str(analysis_path))
        cap_opened = cap.isOpened()
    if not cap_opened:
        with suppress_native_stderr():
            cap = cv2.VideoCapture(str(path))
            cap_opened = cap.isOpened()
    if not cap_opened:
        return {
            "source_type": "video",
            "path": str(path),
            "analysis_path": str(analysis_path),
            "error": "Video could not be opened after safe normalization. Codec/container may be unreadable.",
            "avatar_readiness_score": 0,
            "normalization": normalization_meta,
            "presenter_personas": [],
        }

    detector = _load_cv2_face_detector()
    with suppress_native_stderr():
        fps = cap.get(cv2.CAP_PROP_FPS) or 0
        frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0)
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)
    duration = round(frame_count / fps, 2) if fps else 0

    if frame_count > 0:
        sample_indices = sorted(set(int(i * max(frame_count - 1, 1) / max(max_frames - 1, 1)) for i in range(max_frames)))
    else:
        sample_indices = list(range(max_frames))

    brightness_vals, blur_vals, motion_vals = [], [], []
    sampled = 0
    face_found_frames = 0
    multiple_face_frames = 0
    largest_face_ratio_seen = 0.0
    prev_gray = None
    face_candidates: List[Dict[str, Any]] = []
    fallback_best = {"quality": -1.0, "frame": None, "idx": 0, "time": 0.0}

    for idx in sample_indices:
        with suppress_native_stderr():
            if frame_count > 0:
                cap.set(cv2.CAP_PROP_POS_FRAMES, idx)
            ok, frame = cap.read()
        if not ok:
            continue
        sampled += 1
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        brightness = float(gray.mean())
        blur = float(cv2.Laplacian(gray, cv2.CV_64F).var())
        brightness_vals.append(brightness)
        blur_vals.append(blur)
        if prev_gray is not None:
            try:
                motion_vals.append(float(cv2.absdiff(gray, prev_gray).mean()))
            except Exception:
                pass
        prev_gray = gray
        frame_time = round(idx / fps, 2) if fps else 0.0

        faces = _detect_faces_in_frame(frame, detector)
        if faces:
            face_found_frames += 1
            if len(faces) > 1:
                multiple_face_frames += 1
            for face_box in faces:
                x, y, fw, fh = face_box
                face_area_ratio = (fw * fh) / float(max(1, frame.shape[0] * frame.shape[1]))
                largest_face_ratio_seen = max(largest_face_ratio_seen, face_area_ratio)
                center_x = x + fw / 2
                center_y = y + fh / 2
                center_penalty = (abs(center_x - frame.shape[1] / 2) / frame.shape[1] + abs(center_y - frame.shape[0] / 2) / frame.shape[0]) * 100
                brightness_bonus = max(0, 120 - abs(135 - brightness))
                quality = 900 + min(face_area_ratio * 10000, 450) - center_penalty + min(blur, 260) + brightness_bonus
                # Prefer clear, substantial faces; ignore tiny background faces when possible.
                if face_area_ratio >= 0.004:
                    face_candidates.append({
                        "quality": quality,
                        "frame": frame.copy(),
                        "face_box": face_box,
                        "idx": int(idx),
                        "time": frame_time,
                        "face_area_ratio": face_area_ratio,
                        "center_x_ratio": round(center_x / max(1, frame.shape[1]), 3),
                        "center_y_ratio": round(center_y / max(1, frame.shape[0]), 3),
                        "brightness": brightness,
                        "blur": blur,
                    })
        else:
            quality = min(blur, 180) + max(0, 100 - abs(135 - brightness))
            if quality > fallback_best["quality"]:
                fallback_best = {"quality": quality, "frame": frame.copy(), "idx": int(idx), "time": frame_time}

    with suppress_native_stderr():
        cap.release()

    avg_brightness = round(sum(brightness_vals) / len(brightness_vals), 2) if brightness_vals else 0
    avg_blur = round(sum(blur_vals) / len(blur_vals), 2) if blur_vals else 0
    avg_motion = round(sum(motion_vals) / len(motion_vals), 2) if motion_vals else 0
    face_presence_ratio = round(face_found_frames / sampled, 3) if sampled else 0
    multiple_face_ratio = round(multiple_face_frames / sampled, 3) if sampled else 0

    # Select up to two distinct people. We use spatial separation as a lightweight proxy
    # for different presenters; production can replace this with face embeddings.
    selected: List[Dict[str, Any]] = []
    for cand in sorted(face_candidates, key=lambda c: c["quality"], reverse=True):
        if len(selected) >= 2:
            break
        cx = cand.get("center_x_ratio", 0.5)
        area = cand.get("face_area_ratio", 0)
        distinct = True
        for prev in selected:
            # Avoid picking the same presenter from another frame unless their face position is quite different.
            if abs(cx - prev.get("center_x_ratio", 0.5)) < 0.22 and abs(area - prev.get("face_area_ratio", area)) < 0.025:
                distinct = False
                break
        if distinct:
            selected.append(cand)

    # If only one distinct spatial slot was found, keep just one presenter. If no face found,
    # fall back to a visually clean frame so the app still runs.
    presenter_personas: List[Dict[str, Any]] = []
    portrait_path = None
    full_frame_path = None
    best_frame_index = 0
    best_frame_time = 0.0
    if selected:
        for i, cand in enumerate(selected, 1):
            portrait = _crop_presenter_portrait(cand["frame"], cand["face_box"])
            pp = PRESENTER_DIR / f"presenter_{i}_portrait_{now_id()}.jpg"
            fp = PRESENTER_DIR / f"presenter_{i}_full_frame_{now_id()}.jpg"
            try:
                cv2.imwrite(str(fp), cand["frame"])
                cv2.imwrite(str(pp), portrait if portrait is not None else cand["frame"])
            except Exception:
                pp = Path("")
                fp = Path("")
            if i == 1:
                portrait_path = pp if str(pp) else None
                full_frame_path = fp if str(fp) else None
                best_frame_index = cand["idx"]
                best_frame_time = cand["time"]
            presenter_personas.append({
                "persona_id": f"presenter_{i}",
                "display_name": f"Presenter {i}",
                "portrait_path": str(pp) if str(pp) else "",
                "full_frame_path": str(fp) if str(fp) else "",
                "frame_index": cand["idx"],
                "frame_time_seconds": cand["time"],
                "face_area_ratio": round(cand.get("face_area_ratio", 0), 5),
                "center_x_ratio": cand.get("center_x_ratio", 0.5),
                "voice_profile": _voice_profile_for_index(i - 1),
                "voice_note": "Default demo voice profile. Adjust in UI if needed; face-only gender inference is not treated as authoritative.",
                "delivery_role": "interviewer" if i == 1 else "trainer/co-interviewer",
            })
    elif fallback_best["frame"] is not None:
        pp = PRESENTER_DIR / f"presenter_fallback_visual_{now_id()}.jpg"
        try:
            cv2.imwrite(str(pp), fallback_best["frame"])
            portrait_path = pp
            best_frame_index = fallback_best["idx"]
            best_frame_time = fallback_best["time"]
        except Exception:
            pass

    score = 45
    score += 25 if face_found_frames > 0 else -20
    score += 10 if largest_face_ratio_seen >= 0.015 else 0
    score += 10 if width >= 720 and height >= 480 else -8
    score += 10 if 60 <= avg_brightness <= 190 else -8
    score += 10 if avg_blur >= 60 else -8
    score += 5 if duration >= 10 else -5
    score -= 6 if multiple_face_ratio > 0.65 else 0
    score = int(max(0, min(100, score)))

    flags = []
    if detector is None:
        flags.append("OpenCV face detector unavailable; selected frame by visual quality only")
    if face_found_frames == 0:
        flags.append("No face detected in sampled frames; upload a clearer presenter segment or use a presenter photo")
    if duration < 10:
        flags.append("Short reference video; use at least 10-20 seconds for better persona extraction")
    if avg_blur < 60:
        flags.append("Reference video may be blurry")
    if avg_brightness < 55:
        flags.append("Low lighting")
    if len(presenter_personas) >= 2:
        flags.append("Multiple presenter personas detected; ASHU will alternate presenters during teaching/interviewing")
    if portrait_path is None:
        flags.append("Presenter portrait could not be extracted")

    if avg_motion < 3:
        energy = "calm/static"
    elif avg_motion < 12:
        energy = "professional/moderate"
    else:
        energy = "expressive/high-motion"
    if avg_brightness < 70:
        visual_style = "low-light serious studio style"
    elif avg_brightness > 180:
        visual_style = "bright high-key teaching style"
    else:
        visual_style = "balanced professional style"

    return {
        "source_type": "video",
        "path": str(path),
        "analysis_path": str(analysis_path),
        "normalization": normalization_meta,
        "representative_frame_path": str(portrait_path) if portrait_path else "",
        "avatar_portrait_path": str(portrait_path) if portrait_path else "",
        "best_full_frame_path": str(full_frame_path) if full_frame_path else "",
        "best_frame_index": best_frame_index,
        "best_frame_time_seconds": best_frame_time,
        "face_detected": face_found_frames > 0,
        "face_found_frames": face_found_frames,
        "face_presence_ratio": face_presence_ratio,
        "multiple_face_ratio": multiple_face_ratio,
        "detected_presenter_count": len(presenter_personas) if presenter_personas else (1 if portrait_path else 0),
        "presenter_personas": presenter_personas,
        "multi_presenter_mode": len(presenter_personas) >= 2,
        "largest_face_area_ratio": round(largest_face_ratio_seen, 5),
        "fps": round(fps, 2),
        "frame_count": frame_count,
        "duration_seconds": duration,
        "width": width,
        "height": height,
        "sampled_frames": sampled,
        "average_brightness": avg_brightness,
        "average_blur_laplacian": avg_blur,
        "average_motion": avg_motion,
        "avatar_readiness_score": score,
        "review_flags": flags,
        "persona_profile": {
            "visual_style": visual_style,
            "delivery_energy": energy,
            "recommended_voice_style": "multi-presenter voice mapped" if len(presenter_personas) >= 2 else ("calm, clear, interview-like" if avg_motion < 12 else "energetic, engaging, trainer-like"),
            "presentation_instruction": "Use extracted presenter portraits/features as digital personas; do not replay the reference video as-is. If multiple presenters are detected, alternate between them for interaction.",
        },
        "production_lip_sync_adapter": {
            "status": "manifest_ready_not_rendered_in_lightweight_streamlit_demo",
            "recommended_renderers": ["LivePortrait", "SadTalker", "MuseTalk", "Wav2Lip"],
            "input_image": str(portrait_path) if portrait_path else "",
            "input_images": [p.get("portrait_path", "") for p in presenter_personas],
            "input_audio": "TTS audio generated from LLM question/training script",
            "output": "rendered_talking_presenter_video.mp4",
        },
        "note": "Feature-derived presenter persona. ASHU scans the video, selects best face frames, and can alternate two detected presenters. Full lip-sync requires a consent-approved renderer.",
    }


def download_presenter_url(url: str, max_mb: int = 300) -> Tuple[Optional[Path], Dict[str, Any]]:
    meta: Dict[str, Any] = {"url": url, "downloaded": False}
    if not yt_dlp:
        return None, {**meta, "error": "yt-dlp not installed"}
    outtmpl = str(DOWNLOAD_DIR / f"presenter_url_{now_id()}.%(ext)s")
    opts = {
        "outtmpl": outtmpl,
        "noplaylist": True,
        "max_filesize": max_mb * 1024 * 1024,
        "format": "bestvideo[ext=mp4][vcodec^=avc1]+bestaudio[ext=m4a]/best[ext=mp4]/best",
        "quiet": True,
        "no_warnings": True,
    }
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(url, download=True)
            path_str = ydl.prepare_filename(info)
            path = Path(path_str)
            # In merged cases extension may differ
            if not path.exists():
                matches = sorted(DOWNLOAD_DIR.glob(f"presenter_url_{path.stem.split('_')[-1]}*"))
                path = matches[0] if matches else path
            meta.update({
                "downloaded": path.exists(),
                "title": info.get("title"),
                "duration": info.get("duration"),
                "extractor": info.get("extractor"),
                "path": str(path),
            })
            return path if path.exists() else None, meta
    except Exception as e:
        return None, {**meta, "error": str(e)}


# -----------------------------------------------------------------------------
# Presenter persona helpers
# -----------------------------------------------------------------------------
def get_presenter_personas(profile: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Return detected/derived presenter personas.

    If a video contains two clear people, analyze_video stores two personas. If not,
    this returns a single persona from the current profile so the rest of the UI can
    use the same presenter-selection logic.
    """
    features = profile.get("features", {}) or {}
    personas = features.get("presenter_personas") or []
    valid = [p for p in personas if p.get("portrait_path") and Path(p.get("portrait_path", "")).exists()]
    if valid:
        return valid
    portrait = features.get("representative_frame_path") or features.get("avatar_portrait_path") or profile.get("source_path") or str(DEFAULT_PRESENTER_SVG)
    return [{
        "persona_id": "presenter_1",
        "display_name": profile.get("display_name", "ASHU Presenter"),
        "portrait_path": portrait,
        "voice_profile": features.get("voice_profile", "neutral"),
        "delivery_role": "interviewer/trainer",
    }]


def presenter_portrait_path(profile: Dict[str, Any], index: Optional[int] = None) -> Path:
    """Return the selected persona portrait.

    For video/URL sources this returns an extracted representative portrait, not a
    looping copy of the original reference video.
    """
    personas = get_presenter_personas(profile)
    if index is None:
        index = int(st.session_state.get("active_presenter_index", 0) or 0)
    if personas:
        p = personas[index % len(personas)]
        portrait = p.get("portrait_path") or p.get("avatar_portrait_path")
        if portrait and Path(portrait).exists():
            return Path(portrait)
    features = profile.get("features", {}) or {}
    portrait = features.get("representative_frame_path") or features.get("avatar_portrait_path")
    if portrait and Path(portrait).exists():
        return Path(portrait)
    source = Path(profile.get("source_path", "")) if profile.get("source_path") else DEFAULT_PRESENTER_SVG
    if source.exists() and source.suffix.lower() in [".png", ".jpg", ".jpeg", ".svg"]:
        return source
    return DEFAULT_PRESENTER_SVG


def active_presenter(profile: Dict[str, Any], index: Optional[int] = None) -> Dict[str, Any]:
    personas = get_presenter_personas(profile)
    if index is None:
        index = int(st.session_state.get("active_presenter_index", 0) or 0)
    return personas[index % len(personas)] if personas else {}


def presenter_persona_context(profile: Dict[str, Any]) -> str:
    """Create compact text that conditions LLM questions/training delivery on extracted presenter features."""
    features = profile.get("features", {}) or {}
    persona = features.get("persona_profile", {}) or {}
    flags = features.get("review_flags", []) or []
    personas = get_presenter_personas(profile)
    return json_dumps({
        "display_name": profile.get("display_name", "ASHU Presenter"),
        "source_type": profile.get("source_type", "built_in"),
        "release_id": profile.get("release_id", ""),
        "readiness_score": features.get("avatar_readiness_score", features.get("readiness_score", 100)),
        "detected_presenter_count": len(personas),
        "presenters": [{"name": p.get("display_name"), "voice_profile": p.get("voice_profile"), "role": p.get("delivery_role")} for p in personas],
        "persona_profile": persona,
        "review_flags": flags,
        "delivery_instruction": "Use the selected Digital Presenter Engine for tone/style. If two presenters are available, alternate the teacher/interviewer to make the session interactive. Do not claim the original video is being replayed. For production lip-sync, use the render manifest with a consent-approved renderer.",
    })

# -----------------------------------------------------------------------------
# HTML presenter components
# -----------------------------------------------------------------------------
def get_presenter_visual_html(profile: Dict[str, Any], size_px: int = 220, index: Optional[int] = None) -> str:
    """Return the presenter persona visual.

    For video/URL sources this intentionally shows an extracted portrait/persona,
    not a looping copy of the original video.
    """
    person = active_presenter(profile, index)
    path = presenter_portrait_path(profile, index)
    display_name = person.get("display_name") or profile.get("display_name", "ASHU Persona")
    badge = person.get("voice_profile", "neutral") + " voice · " + (person.get("delivery_role", "presenter") or "presenter")
    if path.exists() and path.suffix.lower() in [".png", ".jpg", ".jpeg", ".svg"]:
        src = f"data:{file_mime(path)};base64,{b64_file(path)}"
        return f"""
        <div class='presenter-photo-wrap realtalk-wrap'>
          <img class='presenter-photo' src='{src}' alt='{display_name}'/>
          <div class='persona-badge'>{badge}</div>
        </div>
        """
    src = f"data:image/svg+xml;base64,{b64_file(DEFAULT_PRESENTER_SVG)}"
    return f"<div class='presenter-photo-wrap realtalk-wrap'><img class='presenter-photo' src='{src}' alt='ASHU Persona'/><div class='persona-badge'>built-in synthetic persona</div></div>"


def speaking_presenter_html(text_to_speak: str, title: str, subtitle: str = "", button_label: str = "Speak") -> str:
    profile = st.session_state.presenter_profile
    person = active_presenter(profile)
    visual = get_presenter_visual_html(profile)
    safe_text = json.dumps(text_to_speak)
    safe_voice = json.dumps(person.get("voice_profile", "neutral"))
    safe_title = title.replace("<", "&lt;").replace(">", "&gt;")
    safe_sub = subtitle.replace("<", "&lt;").replace(">", "&gt;")
    html = f"""
<!doctype html>
<html>
<head>
<style>
body {{margin:0;font-family:Arial, sans-serif;background:transparent;}}
.panel {{background:linear-gradient(135deg,#071A3D,#0B5FFF);border-radius:22px;color:white;padding:22px;box-shadow:0 16px 38px rgba(7,26,61,.18);}}
.row {{display:flex;gap:22px;align-items:center;}}
.presenter-photo-wrap {{width:170px;height:170px;border-radius:28px;overflow:hidden;background:#071A3D;display:flex;align-items:center;justify-content:center;}}
.presenter-photo {{width:170px;height:170px;object-fit:cover;border-radius:28px;border:3px solid rgba(255,255,255,.25);}}
.presenter-video {{width:240px;height:170px;object-fit:cover;border-radius:22px;border:3px solid rgba(255,255,255,.25);background:#000;}}
.presenter-photo-wrap {{position:relative;width:170px;}}
.persona-badge {{position:absolute;left:8px;right:8px;bottom:8px;background:rgba(7,26,61,.76);color:#BFEFFF;border-radius:10px;padding:4px 6px;font-size:10px;line-height:1.15;}}
.talk-mouth {{position:absolute;left:50%;top:61%;transform:translateX(-50%);width:38px;height:9px;background:#071A3D;border-radius:0 0 28px 28px;border:2px solid rgba(255,255,255,.55);opacity:.0;box-shadow:0 0 12px rgba(53,214,255,.45);}}
.face-mesh-canvas {{position:absolute;inset:0;width:100%;height:100%;pointer-events:none;opacity:.86;mix-blend-mode:screen;}}
.presenter-speaking .face-mesh-canvas {{opacity:1;}}
.presenter-speaking .talk-mouth {{opacity:.92;animation:talk .16s infinite alternate;}}
.presenter-speaking .presenter-photo, .presenter-speaking .presenter-video {{animation:pulse .75s infinite alternate; box-shadow:0 0 26px #35D6FF;}}
@keyframes talk {{from {{height:7px;width:32px;top:61%;}} to {{height:24px;width:42px;top:59%;}}}}
@keyframes pulse {{from {{transform:scale(1)}} to {{transform:scale(1.035)}}}}
.btn {{border:0;border-radius:12px;padding:12px 18px;font-weight:800;margin:6px;cursor:pointer;}}
.primary {{background:#35D6FF;color:#001b35;}}
.secondary {{background:#fff;color:#071A3D;}}
.danger {{background:#ff4b4b;color:#fff;}}
.textbox {{background:rgba(255,255,255,.09);border-radius:16px;padding:16px;margin-top:16px;line-height:1.5;}}
.status {{font-size:13px;opacity:.9;margin-top:8px;}}
</style>
</head>
<body>
<div class='panel' id='panel'>
  <div class='row'>
    <div id='visual'>{visual}</div>
    <div style='flex:1'>
      <div style='font-size:13px;letter-spacing:.08em;text-transform:uppercase;color:#BFEFFF'>Digital Presenter</div>
      <h2 style='margin:6px 0 4px 0'>{safe_title}</h2>
      <div style='opacity:.9'>{safe_sub}</div>
      <button class='btn primary' onclick='speakNow()'>▶ {button_label}</button>
      <button class='btn secondary' onclick='pauseNow()'>⏸ Pause</button>
      <button class='btn secondary' onclick='resumeNow()'>▶ Resume</button>
      <button class='btn danger' onclick='stopNow()'>■ Stop</button>
      <div style='margin-top:6px;font-size:12px;color:#BFEFFF'>Voice: <select id='voiceSelect' style='max-width:360px;border-radius:8px;padding:6px'></select></div>
      <div id='status' class='status'>Ready. Choose a female/male voice above if available, then click Speak.</div>
    </div>
  </div>
  <div class='textbox'>{text_to_speak}</div>
</div>
<script>
const text = {safe_text};
const voicePref = {safe_voice};
let utterance = null;

let meshRAF = null;
let meshTick = 0;
function fitCanvas(c) {{
  const r = c.getBoundingClientRect();
  const scale = window.devicePixelRatio || 1;
  const w = Math.max(1, Math.round(r.width * scale));
  const h = Math.max(1, Math.round(r.height * scale));
  if (c.width !== w || c.height !== h) {{ c.width = w; c.height = h; }}
  const ctx = c.getContext('2d');
  ctx.setTransform(scale,0,0,scale,0,0);
  return {{ctx, w:r.width, h:r.height}};
}}
function drawMeshFrame(isSpeaking) {{
  document.querySelectorAll('.face-mesh-canvas').forEach(c => {{
    const box = fitCanvas(c); const ctx = box.ctx, w = box.w, h = box.h;
    ctx.clearRect(0,0,w,h);
    const amp = isSpeaking ? (0.5 + 0.5*Math.sin(meshTick*0.42)) : 0.08;
    const jaw = amp * 12;
    const pts = [
      [0.50,0.18],[0.35,0.28],[0.65,0.28],[0.28,0.43],[0.72,0.43],
      [0.32,0.62],[0.68,0.62],[0.43,0.50],[0.57,0.50],[0.43,0.60+jaw/h],[0.57,0.60+jaw/h],
      [0.50,0.68+jaw/h],[0.50,0.82+jaw/h*.55],[0.24,0.72],[0.76,0.72]
    ].map(p=>[p[0]*w,p[1]*h]);
    const tri = [[0,1,2],[1,3,7],[2,8,4],[3,5,9],[4,10,6],[7,8,9],[8,10,9],[9,10,11],[5,13,12],[6,12,14],[5,9,12],[6,10,12],[1,7,0],[2,0,8]];
    ctx.lineWidth = isSpeaking ? 1.45 : 0.75;
    ctx.strokeStyle = isSpeaking ? 'rgba(53,214,255,.85)' : 'rgba(53,214,255,.35)';
    tri.forEach(t => {{ ctx.beginPath(); ctx.moveTo(pts[t[0]][0],pts[t[0]][1]); ctx.lineTo(pts[t[1]][0],pts[t[1]][1]); ctx.lineTo(pts[t[2]][0],pts[t[2]][1]); ctx.closePath(); ctx.stroke(); }});
    ctx.fillStyle = isSpeaking ? 'rgba(53,214,255,.95)' : 'rgba(53,214,255,.55)';
    pts.forEach((p,i)=>{{ if(i<13){{ ctx.beginPath(); ctx.arc(p[0],p[1], i===11?3.2:2.1,0,Math.PI*2); ctx.fill(); }} }});
    ctx.fillStyle = 'rgba(7,26,61,.88)';
    ctx.strokeStyle = 'rgba(255,255,255,.75)';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.ellipse(w*.50, h*(0.63 + jaw/h*.45), 22+amp*6, 5+amp*12, 0, 0, Math.PI*2);
    ctx.fill(); ctx.stroke();
  }});
}}
function startMeshAnim() {{ if(meshRAF) cancelAnimationFrame(meshRAF); const loop=()=>{{meshTick++; drawMeshFrame(true); meshRAF=requestAnimationFrame(loop);}}; loop(); }}
function stopMeshAnim() {{ if(meshRAF) cancelAnimationFrame(meshRAF); meshRAF=null; drawMeshFrame(false); }}
window.addEventListener('resize', ()=>drawMeshFrame(false));
setTimeout(()=>{{drawMeshFrame(false); setupGeneratedVideoControls();}}, 350);


let cachedVoices = [];
function populateVoiceSelect() {{
  cachedVoices = window.speechSynthesis && speechSynthesis.getVoices ? speechSynthesis.getVoices() : [];
  const sel = document.getElementById('voiceSelect');
  if(!sel) return;
  const saved = localStorage.getItem('ashuPreferredVoice') || '';
  sel.innerHTML = '';
  const opt0 = document.createElement('option'); opt0.value=''; opt0.textContent = voicePref + ' auto voice'; sel.appendChild(opt0);
  cachedVoices.forEach((v, i) => {{ const o=document.createElement('option'); o.value=String(i); o.textContent=v.name + ' [' + (v.lang || 'voice') + ']'; sel.appendChild(o); }});
  if(saved) sel.value = saved;
  sel.onchange = () => localStorage.setItem('ashuPreferredVoice', sel.value);
}}
function chooseBestVoice(u) {{
  populateVoiceSelect();
  const saved = localStorage.getItem('ashuPreferredVoice') || '';
  if(saved !== '' && cachedVoices[Number(saved)]) {{ u.voice = cachedVoices[Number(saved)]; return; }}
  const femaleTokens = ['female','woman','zira','jenny','aria','natasha','samantha','karen','moira','susan','victoria','tessa','veena','heera','neha','sunita','swara','hazel','linda','helena','serena','salli','joanna'];
  const maleTokens = ['male','man','david','mark','daniel','alex','fred','tom','ravi','guy','brian','roger'];
  const tokens = voicePref === 'female' ? femaleTokens : (voicePref === 'male' ? maleTokens : []);
  const exact = cachedVoices.find(v => tokens.some(t => (v.name + ' ' + v.voiceURI + ' ' + v.lang).toLowerCase().includes(t)));
  if(exact) {{ u.voice = exact; return; }}
  const english = cachedVoices.find(v => (v.lang || '').toLowerCase().startsWith('en'));
  if(english) u.voice = english;
}}
if(window.speechSynthesis && speechSynthesis.onvoiceschanged !== undefined) speechSynthesis.onvoiceschanged = populateVoiceSelect;
setTimeout(populateVoiceSelect, 250);

function setStatus(s) {{ document.getElementById('status').innerText = s; }}
function startAnim() {{ document.getElementById('panel').classList.add('presenter-speaking'); startMeshAnim(); }}
function stopAnim() {{ document.getElementById('panel').classList.remove('presenter-speaking'); stopMeshAnim(); }}
function speakNow() {{
  try {{
    window.speechSynthesis.cancel();
    utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 0.93; utterance.pitch = voicePref === 'female' ? 1.08 : (voicePref === 'male' ? 0.92 : 1.0);
    chooseBestVoice(utterance);
    utterance.onstart = () => {{ startAnim(); setStatus('Presenter is speaking...'); }};
    utterance.onend = () => {{ stopAnim(); setStatus('Completed.'); }};
    utterance.onerror = () => {{ stopAnim(); setStatus('Speech playback failed. Click once inside the app, allow sound, and choose an installed browser voice.'); }};
    window.speechSynthesis.speak(utterance);
  }} catch(e) {{ setStatus('Speech error: ' + e); }}
}}
function pauseNow() {{ window.speechSynthesis.pause(); setStatus('Paused.'); }}
function resumeNow() {{ window.speechSynthesis.resume(); startAnim(); setStatus('Resumed.'); }}
function stopNow() {{ window.speechSynthesis.cancel(); stopAnim(); setStatus('Stopped.'); }}
</script>
</body>
</html>
"""
    st.components.v1.html(html, height=420, scrolling=False)


def training_presenter_html(training: Dict[str, Any], segment_index: int = 0, generated_audio_path: str = "", generated_video_path: str = "") -> None:
    segments = training.get("segments", []) or []
    if not segments:
        st.info("Generate training first.")
        return
    st.session_state.active_presenter_index = segment_index % max(1, len(get_presenter_personas(st.session_state.presenter_profile)))
    person = active_presenter(st.session_state.presenter_profile)
    visual = get_presenter_visual_html(st.session_state.presenter_profile)
    safe_segments = json.dumps(segments)
    safe_title = json.dumps(training.get("title", "ASHU Training"))
    safe_voice = json.dumps(person.get("voice_profile", "neutral"))
    display_name = st.session_state.presenter_profile.get("display_name", "ASHU Presenter")
    generated_video_controls_html = ""
    if generated_video_path:
        try:
            gv = Path(generated_video_path)
            if gv.exists() and gv.stat().st_size > 1000:
                gv = ensure_browser_compatible_mp4(gv)
                video_b64 = base64.b64encode(gv.read_bytes()).decode("ascii")
                visual = f"""
   <div class='yt-card'>
     <video id='generatedAssistantVideo' class='presenter-video yt-video' preload='metadata' playsinline controls src='data:video/mp4;base64,{video_b64}'></video>
     <div class='yt-mini-controls'>
       <button class='yt-btn' onclick='playGeneratedVideo()'>▶</button>
       <button class='yt-btn' onclick='pauseNow()'>⏸</button>
       <button class='yt-btn' onclick='jumpGeneratedVideo(-10)'>↺10</button>
       <button class='yt-btn' onclick='jumpGeneratedVideo(10)'>10↻</button>
       <span id='generatedVideoTime' class='yt-time'>0:00 / 0:00</span>
     </div>
     <input id='generatedVideoSeek' class='yt-range' type='range' min='0' max='100' value='0' step='0.1' oninput='seekGeneratedVideo(this.value)' />
     <div class='yt-mini-controls'>
       <label class='yt-label'>Speed <select id='generatedVideoSpeed' onchange='setGeneratedVideoSpeed(this.value)'><option value='0.75'>0.75x</option><option value='1' selected>1x</option><option value='1.25'>1.25x</option><option value='1.5'>1.5x</option></select></label>
       <label class='yt-label'>Volume <input id='generatedVideoVolume' type='range' min='0' max='1' step='0.05' value='1' oninput='setGeneratedVideoVolume(this.value)' /></label>
     </div>
   </div>
   <div class='micro'>Generated lecture video is loaded like a streaming player. Use play, seek, speed, and volume controls.</div>
"""
                generated_video_controls_html = """
   <button class='btn primary' onclick='playGeneratedVideo()'>▶ Play generated video in assistant</button><br/>
   <button class='btn secondary' onclick='pauseNow()'>⏸ Pause video</button><button class='btn secondary' onclick='resumeNow()'>▶ Resume video</button><br/>
   <button class='btn danger' onclick='stopNow()'>■ Stop video</button><br/>
"""
        except Exception:
            generated_video_controls_html = ""
    generated_audio_html = ""
    if generated_audio_path:
        try:
            ga = Path(generated_audio_path)
            if ga.exists() and ga.stat().st_size > 1000:
                audio_b64 = base64.b64encode(ga.read_bytes()).decode("ascii")
                generated_audio_html = f"""
   <button class='btn primary' onclick='playGeneratedVoice()'>▶ Play generated XTTS voice in assistant</button><br/>
   <button class='btn secondary' onclick='pauseNow()'>⏸ Pause generated voice</button><button class='btn secondary' onclick='resumeNow()'>▶ Resume generated voice</button><br/>
   <button class='btn danger' onclick='stopNow()'>■ Stop generated voice</button><br/>
   <audio id='generatedVoiceAudio' preload='auto' src='data:audio/wav;base64,{audio_b64}'></audio>
   <div class='micro'>Generated voice audio is available for this slide. This uses your XTTS/SadTalker pipeline audio, not browser speech.</div>
"""
        except Exception:
            generated_audio_html = ""
    html = f"""
<!doctype html><html><head><style>
body{{margin:0;font-family:Inter,Arial,sans-serif;background:transparent;}}
.stage{{border-radius:26px;padding:22px;color:white;background:linear-gradient(135deg,#071A3D 0%,#0B5FFF 68%,#35D6FF 125%);box-shadow:0 18px 42px rgba(7,26,61,.20)}}
.top{{display:flex;align-items:center;gap:12px;justify-content:space-between;margin-bottom:14px}}
.badge{{font-size:12px;letter-spacing:.1em;text-transform:uppercase;color:#BFEFFF;font-weight:800}}
.progress{{height:8px;background:rgba(255,255,255,.16);border-radius:99px;overflow:hidden;margin:8px 0 16px}}
.bar{{height:100%;width:0%;background:linear-gradient(90deg,#35D6FF,#fff);transition:.3s}}
.grid{{display:grid;grid-template-columns:315px 1fr;gap:20px;align-items:stretch;}}
.left{{background:rgba(255,255,255,.09);border-radius:20px;padding:16px;text-align:center}}
.right{{background:rgba(255,255,255,.10);border-radius:20px;padding:18px;}}
.presenter-photo{{width:190px;height:190px;object-fit:cover;border-radius:30px;border:3px solid rgba(255,255,255,.28)}}
.presenter-video{{width:260px;height:190px;object-fit:cover;border-radius:22px;border:3px solid rgba(255,255,255,.28);background:#000}}
.yt-card{{background:#020817;border-radius:18px;padding:8px;border:1px solid rgba(255,255,255,.22);box-shadow:0 0 22px rgba(53,214,255,.28)}}
.yt-video{{width:100%;height:190px;object-fit:contain;border-radius:14px;border:0;background:#000;display:block}}
.yt-mini-controls{{display:flex;align-items:center;justify-content:center;gap:6px;margin-top:7px;flex-wrap:wrap}}
.yt-btn{{border:0;border-radius:999px;background:#ffffff;color:#071A3D;font-weight:900;padding:6px 9px;cursor:pointer;min-width:34px}}
.yt-btn:hover{{filter:brightness(.92)}}
.yt-range{{width:100%;accent-color:#35D6FF;margin-top:8px}}
.yt-time{{font-size:12px;color:#BFEFFF;font-weight:800;min-width:88px;text-align:center}}
.yt-label{{font-size:11px;color:#BFEFFF;font-weight:800;display:flex;align-items:center;gap:5px}}
.yt-label select{{border-radius:8px;padding:4px;border:0}}
.yt-label input{{accent-color:#35D6FF;width:76px}}
.presenter-photo-wrap{{position:relative;margin:auto;width:190px}}
.persona-badge{{position:absolute;left:8px;right:8px;bottom:8px;background:rgba(7,26,61,.78);color:#BFEFFF;border-radius:10px;padding:4px 6px;font-size:10px;line-height:1.15}}
.talk-mouth{{position:absolute;left:50%;top:61%;transform:translateX(-50%);width:38px;height:9px;background:#071A3D;border-radius:0 0 28px 28px;border:2px solid rgba(255,255,255,.55);opacity:0;box-shadow:0 0 14px rgba(53,214,255,.5)}}
.face-mesh-canvas{{position:absolute;inset:0;width:100%;height:100%;pointer-events:none;opacity:.86;mix-blend-mode:screen}}
.speaking .face-mesh-canvas{{opacity:1}}
.speaking .talk-mouth{{opacity:.94;animation:talk .16s infinite alternate}}
.speaking .presenter-photo,.speaking .presenter-video{{animation:pulse .75s infinite alternate;box-shadow:0 0 28px #35D6FF}}
@keyframes talk{{from{{height:7px;width:32px;top:61%;}}to{{height:24px;width:42px;top:59%;}}}}
@keyframes pulse{{from{{transform:scale(1)}}to{{transform:scale(1.045)}}}}
.btn{{border:0;border-radius:12px;padding:11px 14px;font-weight:900;margin:4px;cursor:pointer}}
.primary{{background:#35D6FF;color:#001b35}}.secondary{{background:#fff;color:#071A3D}}.danger{{background:#ff4b4b;color:#fff}}
.slide{{background:linear-gradient(180deg,#F7FBFF,#EAF4FF);color:#071A3D;border-radius:20px;padding:22px;min-height:335px;border:1px solid rgba(255,255,255,.5)}}
.slide h2{{margin:0 0 10px 0;color:#071A3D;font-size:25px}}
.kicker{{color:#0B5FFF;font-weight:900;letter-spacing:.08em;text-transform:uppercase;font-size:12px}}
.bullets{{display:grid;grid-template-columns:1fr 1fr;gap:9px;margin-top:12px}}
.bullet{{background:#fff;border:1px solid #dbeafe;border-radius:14px;padding:10px;font-size:15px;line-height:1.35}}
.visual{{background:#071A3D;color:#fff;border-radius:16px;padding:14px;margin-top:14px;min-height:72px}}
.check{{background:#FFF7E8;color:#071A3D;border-left:5px solid #ff8a00;border-radius:12px;padding:12px;margin-top:14px}}
.caption{{background:rgba(255,255,255,.10);border-radius:16px;padding:12px;margin-top:14px;color:#fff;line-height:1.5;max-height:120px;overflow:auto}}
.status{{font-size:13px;opacity:.9;margin-top:8px;min-height:18px}}
.micro{{font-size:12px;opacity:.82;margin-top:10px;line-height:1.4}}
</style></head><body>
<div class='stage' id='stage'>
 <div class='top'>
   <div><div class='badge'>Live digital-human training presenter</div><h2 style='margin:5px 0 0 0;color:#fff' id='courseTitle'></h2></div>
   <div id='counter' style='font-weight:900;color:#BFEFFF'></div>
 </div>
 <div class='progress'><div class='bar' id='bar'></div></div>
 <div class='grid'>
  <div class='left'>
   {visual}
   <h3>{display_name}</h3>
   <button class='btn primary' onclick='startClass()'>▶ Start live spoken class</button><br/>
   <button class='btn secondary' onclick='testVoice()'>🔊 Test voice</button><br/>
   <button class='btn primary' onclick='speakCurrent(false)'>▶ Speak current slide</button><br/>
   {generated_video_controls_html}
   {generated_audio_html}
   <button class='btn secondary' onclick='prevSlide()'>← Previous</button><button class='btn secondary' onclick='nextSlide(false)'>Next →</button><br/>
   <button class='btn secondary' onclick='pauseNow()'>⏸ Pause</button><button class='btn secondary' onclick='resumeNow()'>▶ Resume</button><br/>
   <button class='btn secondary' onclick='repeatSentence()'>↻ Repeat line</button><button class='btn danger' onclick='stopNow()'>■ Stop</button>
   <div id='status' class='status'>Ready. Click Start class to hear the trainer.</div>
   <div class='micro'>Browser speech needs one click. If audio fails, allow site sound and click Start class again.</div>
  </div>
  <div class='right'>
    <div class='slide'>
      <div class='kicker' id='kicker'></div>
      <h2 id='slideTitle'></h2>
      <div class='bullets' id='bullets'></div>
      <div class='visual'><b>Visual:</b> <span id='visualText'></span></div>
      <div class='check'><b>Checkpoint:</b> <span id='checkText'></span></div>
    </div>
  </div>
 </div>
 <div class='caption' id='caption'>Trainer transcript will appear here.</div>
</div>
<script>
const segments = {safe_segments};
const title = {safe_title};
const voicePref = {safe_voice};
let idx = {int(segment_index)};
let autoMode = false;
let lastSentence = '';
let currentText = '';
document.getElementById('courseTitle').innerText = title;

let meshRAF = null;
let meshTick = 0;
function fitCanvas(c) {{
  const r = c.getBoundingClientRect();
  const scale = window.devicePixelRatio || 1;
  const w = Math.max(1, Math.round(r.width * scale));
  const h = Math.max(1, Math.round(r.height * scale));
  if (c.width !== w || c.height !== h) {{ c.width = w; c.height = h; }}
  const ctx = c.getContext('2d');
  ctx.setTransform(scale,0,0,scale,0,0);
  return {{ctx, w:r.width, h:r.height}};
}}
function drawMeshFrame(isSpeaking) {{
  document.querySelectorAll('.face-mesh-canvas').forEach(c => {{
    const box = fitCanvas(c); const ctx = box.ctx, w = box.w, h = box.h;
    ctx.clearRect(0,0,w,h);
    const amp = isSpeaking ? (0.5 + 0.5*Math.sin(meshTick*0.42)) : 0.08;
    const jaw = amp * 12;
    const pts = [
      [0.50,0.18],[0.35,0.28],[0.65,0.28],[0.28,0.43],[0.72,0.43],
      [0.32,0.62],[0.68,0.62],[0.43,0.50],[0.57,0.50],[0.43,0.60+jaw/h],[0.57,0.60+jaw/h],
      [0.50,0.68+jaw/h],[0.50,0.82+jaw/h*.55],[0.24,0.72],[0.76,0.72]
    ].map(p=>[p[0]*w,p[1]*h]);
    const tri = [[0,1,2],[1,3,7],[2,8,4],[3,5,9],[4,10,6],[7,8,9],[8,10,9],[9,10,11],[5,13,12],[6,12,14],[5,9,12],[6,10,12],[1,7,0],[2,0,8]];
    ctx.lineWidth = isSpeaking ? 1.45 : 0.75;
    ctx.strokeStyle = isSpeaking ? 'rgba(53,214,255,.85)' : 'rgba(53,214,255,.35)';
    tri.forEach(t => {{ ctx.beginPath(); ctx.moveTo(pts[t[0]][0],pts[t[0]][1]); ctx.lineTo(pts[t[1]][0],pts[t[1]][1]); ctx.lineTo(pts[t[2]][0],pts[t[2]][1]); ctx.closePath(); ctx.stroke(); }});
    ctx.fillStyle = isSpeaking ? 'rgba(53,214,255,.95)' : 'rgba(53,214,255,.55)';
    pts.forEach((p,i)=>{{ if(i<13){{ ctx.beginPath(); ctx.arc(p[0],p[1], i===11?3.2:2.1,0,Math.PI*2); ctx.fill(); }} }});
    ctx.fillStyle = 'rgba(7,26,61,.88)';
    ctx.strokeStyle = 'rgba(255,255,255,.75)';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.ellipse(w*.50, h*(0.63 + jaw/h*.45), 22+amp*6, 5+amp*12, 0, 0, Math.PI*2);
    ctx.fill(); ctx.stroke();
  }});
}}
function startMeshAnim() {{ if(meshRAF) cancelAnimationFrame(meshRAF); const loop=()=>{{meshTick++; drawMeshFrame(true); meshRAF=requestAnimationFrame(loop);}}; loop(); }}
function stopMeshAnim() {{ if(meshRAF) cancelAnimationFrame(meshRAF); meshRAF=null; drawMeshFrame(false); }}
window.addEventListener('resize', ()=>drawMeshFrame(false));
setTimeout(()=>drawMeshFrame(false), 350);


let cachedVoices = [];
function populateVoiceSelect() {{
  cachedVoices = window.speechSynthesis && speechSynthesis.getVoices ? speechSynthesis.getVoices() : [];
  const sel = document.getElementById('voiceSelect');
  if(!sel) return;
  const saved = localStorage.getItem('ashuPreferredVoice') || '';
  sel.innerHTML = '';
  const opt0 = document.createElement('option'); opt0.value=''; opt0.textContent = voicePref + ' auto voice'; sel.appendChild(opt0);
  cachedVoices.forEach((v, i) => {{ const o=document.createElement('option'); o.value=String(i); o.textContent=v.name + ' [' + (v.lang || 'voice') + ']'; sel.appendChild(o); }});
  if(saved) sel.value = saved;
  sel.onchange = () => localStorage.setItem('ashuPreferredVoice', sel.value);
}}
function chooseBestVoice(u) {{
  populateVoiceSelect();
  const saved = localStorage.getItem('ashuPreferredVoice') || '';
  if(saved !== '' && cachedVoices[Number(saved)]) {{ u.voice = cachedVoices[Number(saved)]; return; }}
  const femaleTokens = ['female','woman','zira','jenny','aria','natasha','samantha','karen','moira','susan','victoria','tessa','veena','heera','neha','sunita','swara','hazel','linda','helena','serena','salli','joanna'];
  const maleTokens = ['male','man','david','mark','daniel','alex','fred','tom','ravi','guy','brian','roger'];
  const tokens = voicePref === 'female' ? femaleTokens : (voicePref === 'male' ? maleTokens : []);
  const exact = cachedVoices.find(v => tokens.some(t => (v.name + ' ' + v.voiceURI + ' ' + v.lang).toLowerCase().includes(t)));
  if(exact) {{ u.voice = exact; return; }}
  const english = cachedVoices.find(v => (v.lang || '').toLowerCase().startsWith('en'));
  if(english) u.voice = english;
}}
if(window.speechSynthesis && speechSynthesis.onvoiceschanged !== undefined) speechSynthesis.onvoiceschanged = populateVoiceSelect;
setTimeout(populateVoiceSelect, 250);

function esc(s){{return String(s||'').replace(/[&<>]/g,c=>({{'&':'&amp;','<':'&lt;','>':'&gt;'}}[c]));}}
function setStatus(s){{document.getElementById('status').innerText=s}}
function startAnim(){{document.getElementById('stage').classList.add('speaking'); startMeshAnim();}}
function stopAnim(){{document.getElementById('stage').classList.remove('speaking'); stopMeshAnim();}}
function render(){{
 const s=segments[idx]||{{}};
 document.getElementById('counter').innerText = `Slide ${{idx+1}} of ${{segments.length}}`;
 document.getElementById('bar').style.width = `${{((idx+1)/segments.length)*100}}%`;
 document.getElementById('kicker').innerText = s.subtopic || s.level || 'Interactive training slide';
 document.getElementById('slideTitle').innerText = s.title || `Segment ${{idx+1}}`;
 let bullets=(s.slide_bullets||[]).slice(0,8).map(b=>`<div class='bullet'>${{esc(b)}}</div>`).join('');
 document.getElementById('bullets').innerHTML = bullets || '<div class="bullet">Concept</div><div class="bullet">Example</div>';
 document.getElementById('visualText').innerText = s.visual_description || 'Presenter-led explanation with conceptual diagram and examples.';
 document.getElementById('checkText').innerText = s.checkpoint_question || 'Explain the key idea in your own words.';
 currentText = `${{s.title||''}}. ${{s.script||''}}. Checkpoint question: ${{s.checkpoint_question||''}}`;
 lastSentence = (s.script||currentText).split(/[.!?]/).filter(Boolean)[0] || currentText;
 document.getElementById('caption').innerText = currentText;
}}
function selectVoice(u){{
 let voices=speechSynthesis.getVoices?speechSynthesis.getVoices():[];
 let ft=['female','woman','zira','samantha','karen','moira','susan','victoria','tessa','veena'];
 let mt=['male','man','david','mark','daniel','alex','fred','tom','ravi'];
 let toks=voicePref==='female'?ft:(voicePref==='male'?mt:[]);
 let m=voices.find(v=>toks.some(t=>(v.name+' '+v.voiceURI).toLowerCase().includes(t)));
 if(m)u.voice=m;
}}
function speakText(text,onDone){{
 try{{speechSynthesis.cancel();let u=new SpeechSynthesisUtterance(text);u.rate=.9;u.pitch=voicePref==='female'?1.08:(voicePref==='male'?0.92:1.0);selectVoice(u);u.onstart=()=>{{startAnim();setStatus('Speaking...')}};u.onend=()=>{{stopAnim();setStatus('Completed.'); if(onDone)onDone();}};u.onerror=(e)=>{{stopAnim();setStatus('Speech playback failed. Click once inside the app, allow sound, and choose an installed browser voice.');}};speechSynthesis.speak(u)}}catch(e){{setStatus('Speech error '+e)}}
}}
function speakCurrent(nextAfter){{render();speakText(currentText,()=>{{if(nextAfter && autoMode)nextSlide(true)}})}}
function testVoice(){{speakText('Hello, I am your digital trainer. I will teach this topic slide by slide and repeat the words aloud.', null)}}
function startClass(){{autoMode=true;render();speakCurrent(true)}}
function nextSlide(andSpeak){{if(idx<segments.length-1){{idx++;render(); if(andSpeak) speakCurrent(true);}} else {{autoMode=false;setStatus('Class finished.')}}}}
function prevSlide(){{if(idx>0){{idx--;render();}}}}
function formatVideoTime(sec){{
  if(!isFinite(sec) || sec < 0) return '0:00';
  const m = Math.floor(sec/60); const s = Math.floor(sec%60).toString().padStart(2,'0');
  return m + ':' + s;
}}
function setupGeneratedVideoControls(){{
  const v = document.getElementById('generatedAssistantVideo');
  const seek = document.getElementById('generatedVideoSeek');
  const time = document.getElementById('generatedVideoTime');
  if(!v || !seek || !time) return;
  const update = () => {{
    const dur = v.duration || 0;
    const cur = v.currentTime || 0;
    seek.value = dur ? (cur/dur)*100 : 0;
    time.innerText = formatVideoTime(cur) + ' / ' + formatVideoTime(dur);
  }};
  v.addEventListener('timeupdate', update);
  v.addEventListener('loadedmetadata', update);
  v.addEventListener('play', () => {{ startAnim(); setStatus('Streaming generated lecture video.'); }});
  v.addEventListener('pause', () => {{ stopAnim(); setStatus('Video paused.'); }});
  v.addEventListener('ended', () => {{ stopAnim(); setStatus('Generated video completed.'); }});
  update();
}}
function seekGeneratedVideo(val){{
  const v = document.getElementById('generatedAssistantVideo'); if(!v || !v.duration) return;
  v.currentTime = (parseFloat(val)/100) * v.duration;
}}
function jumpGeneratedVideo(delta){{
  const v = document.getElementById('generatedAssistantVideo'); if(!v) return;
  v.currentTime = Math.max(0, Math.min((v.duration||0), (v.currentTime||0) + delta));
}}
function setGeneratedVideoSpeed(val){{ const v = document.getElementById('generatedAssistantVideo'); if(v) v.playbackRate = parseFloat(val)||1; }}
function setGeneratedVideoVolume(val){{ const v = document.getElementById('generatedAssistantVideo'); if(v) v.volume = parseFloat(val); }}
function playGeneratedVideo(){{
  const v = document.getElementById('generatedAssistantVideo');
  if(!v){{ setStatus('No generated video found yet. Run lip-sync render first.'); return; }}
  try{{
    autoMode=false;
    speechSynthesis.cancel();
    const a = document.getElementById('generatedVoiceAudio'); if(a){{ a.pause(); a.currentTime=0; }}
    v.pause(); v.currentTime = 0;
    startAnim();
    setStatus('Playing generated lecture video in teaching assistant.');
    v.onended = () => {{ stopAnim(); setStatus('Generated video completed.'); }};
    v.onerror = () => {{ stopAnim(); setStatus('Generated video playback failed. Try the video player above.'); }};
    const p = v.play();
    if(p && p.catch) p.catch(err => {{ stopAnim(); setStatus('Browser blocked video/audio. Click once in the app and try again.'); }});
  }}catch(e){{ stopAnim(); setStatus('Generated video error: '+e); }}
}}
function playGeneratedVoice(){{
  const a = document.getElementById('generatedVoiceAudio');
  if(!a){{ setStatus('No generated XTTS voice audio found yet. Generate voice audio first.'); return; }}
  try{{
    autoMode=false;
    speechSynthesis.cancel();
    a.pause(); a.currentTime = 0;
    startAnim();
    setStatus('Playing generated XTTS voice in teaching assistant.');
    a.onended = () => {{ stopAnim(); setStatus('Generated voice completed.'); }};
    a.onerror = () => {{ stopAnim(); setStatus('Generated audio playback failed. Try the video/audio player above.'); }};
    const p = a.play();
    if(p && p.catch) p.catch(err => {{ stopAnim(); setStatus('Browser blocked audio. Click once in the app and try again.'); }});
  }}catch(e){{ stopAnim(); setStatus('Generated voice error: '+e); }}
}}
function pauseNow(){{
  const v = document.getElementById('generatedAssistantVideo'); if(v) v.pause();
  const a = document.getElementById('generatedVoiceAudio'); if(a) a.pause();
  speechSynthesis.pause();setStatus('Paused')
}}
function resumeNow(){{
  const v = document.getElementById('generatedAssistantVideo'); if(v && v.currentTime>0 && v.paused){{v.play(); startAnim(); setStatus('Resumed generated video'); return;}}
  const a = document.getElementById('generatedVoiceAudio'); if(a && a.currentTime>0 && a.paused){{a.play(); startAnim(); setStatus('Resumed generated voice'); return;}}
  speechSynthesis.resume();startAnim();setStatus('Resumed')
}}
function stopNow(){{
  const v = document.getElementById('generatedAssistantVideo'); if(v){{v.pause(); v.currentTime=0;}}
  const a = document.getElementById('generatedVoiceAudio'); if(a){{a.pause(); a.currentTime=0;}}
  autoMode=false;speechSynthesis.cancel();stopAnim();setStatus('Stopped')
}}
function repeatSentence(){{speakText(lastSentence,null)}}
if(speechSynthesis.onvoiceschanged!==undefined) speechSynthesis.onvoiceschanged=()=>{{}};
try{{ speechSynthesis.getVoices(); }}catch(e){{}}
render();
</script>
</body></html>
"""
    st.components.v1.html(html, height=1040, scrolling=True)


# -----------------------------------------------------------------------------
# Runtime dependency helpers
# -----------------------------------------------------------------------------
def _module_available(module_name: str) -> bool:
    try:
        return importlib.util.find_spec(module_name) is not None
    except Exception:
        return False


def ensure_python_package(module_name: str, package_name: Optional[str] = None, timeout: int = 240) -> Tuple[bool, str]:
    """Ensure an optional Python package is importable.

    This is used for demo runtime convenience. It installs into the currently
    running Python environment, so after first success the package remains
    available for future runs.
    """
    if _module_available(module_name):
        return True, f"{module_name} already installed"
    pkg = package_name or module_name
    try:
        proc = subprocess.run(
            [sys.executable, "-m", "pip", "install", pkg],
            text=True,
            capture_output=True,
            timeout=timeout,
        )
        if proc.returncode == 0 and _module_available(module_name):
            return True, f"Installed {pkg}"
        msg = (proc.stderr or proc.stdout or "").strip()
        return False, f"Could not install {pkg}. {msg[-800:]}"
    except Exception as exc:
        return False, f"Could not install {pkg}: {exc}"


# -----------------------------------------------------------------------------
# Consent-based production lip-sync / talking-avatar renderer adapters
# -----------------------------------------------------------------------------
def create_server_tts_audio(text: str, output_wav: Path, voice_profile: str = "neutral", voice_sample_path: str = "") -> Tuple[bool, str]:
    """Create an audio file for real lip-sync renderer input.

    Priority order:
    1. Edge Neural TTS when `edge-tts` is installed. This gives much better
       female/male voices than browser speech or pyttsx3.
    2. Local pyttsx3 fallback if Edge TTS is unavailable.

    The generated audio is saved as WAV because SadTalker/Wav2Lip pipelines
    handle WAV reliably.
    """
    clean = re.sub(r"\s+", " ", text or "").strip()
    if not clean:
        return False, "No text available for TTS."
    output_wav.parent.mkdir(parents=True, exist_ok=True)

    # Optional consent-based voice cloning path.
    # IMPORTANT: voice cloning runs in a separate conda env (default: ashu_voice)
    # so it cannot break the working Streamlit/SadTalker/Wav2Lip environment.
    voice_clone_msg = ""
    sample = Path(voice_sample_path).expanduser() if voice_sample_path else None
    if sample and sample.exists() and sample.stat().st_size > 1000:
        try:
            voice_env = os.environ.get("ASHU_VOICE_ENV", "ashu_voice")
            conda_exe = os.environ.get("CONDA_EXE") or shutil.which("conda") or "/home/anubhaparashar/anaconda3/bin/conda"
            voice_script = BASE_DIR / "tools" / "voice_clone_xtts.py"
            if not Path(conda_exe).exists() and shutil.which("conda") is None:
                raise RuntimeError("conda executable not found. Set ASHU_VOICE_ENV or CONDA_EXE.")
            if not voice_script.exists():
                raise RuntimeError(f"Voice clone helper not found: {voice_script}")

            text_file = output_wav.with_suffix(".script.txt")
            text_file.write_text(clean, encoding="utf-8")
            cmd = [
                conda_exe,
                "run",
                "-n",
                voice_env,
                "python",
                str(voice_script),
                "--text-file",
                str(text_file),
                "--speaker",
                str(sample),
                "--out",
                str(output_wav),
            ]
            proc = subprocess.run(cmd, text=True, capture_output=True, timeout=900)
            if proc.returncode == 0 and output_wav.exists() and output_wav.stat().st_size > 1000:
                return True, str(output_wav)
            voice_clone_msg = (proc.stderr or proc.stdout or "").strip()[-2000:] or "Voice env did not create audio."
            return False, f"Your authorized voice sample was selected, but XTTS/{voice_env} failed. ASHU did not fall back to a fake/neutral voice. Fix the voice env and try again. Details: {voice_clone_msg}"
        except Exception as e:
            voice_clone_msg = f"Authorized voice sample selected, but separate voice env is not ready: {e}"
            return False, "Your authorized voice sample was selected, but ASHU could not run the selected voice env. ASHU did not fall back to a fake/neutral voice. Details: " + voice_clone_msg

    target = (voice_profile or "neutral").lower()
    edge_voice = {
        "female": "en-US-JennyNeural",
        "male": "en-US-GuyNeural",
        "neutral": "en-US-AriaNeural",
    }.get(target, "en-US-AriaNeural")

    # Better TTS path: Edge Neural voices. Requires internet but produces a real audio file.
    edge_ok, edge_install_msg = ensure_python_package("edge_tts", "edge-tts")
    try:
        if not edge_ok:
            raise RuntimeError(edge_install_msg)
        import asyncio  # local import for Streamlit startup speed
        import edge_tts  # type: ignore
        mp3_path = output_wav.with_suffix(".mp3")

        async def _edge_save() -> None:
            communicate = edge_tts.Communicate(clean, edge_voice, rate="-4%")
            await communicate.save(str(mp3_path))

        asyncio.run(_edge_save())
        if mp3_path.exists() and mp3_path.stat().st_size > 1000:
            if imageio_ffmpeg is not None:
                ffmpeg = imageio_ffmpeg.get_ffmpeg_exe()
                cmd = [
                    ffmpeg, "-y", "-i", str(mp3_path),
                    "-ac", "1", "-ar", "16000", "-sample_fmt", "s16",
                    str(output_wav),
                ]
                proc = subprocess.run(cmd, text=True, capture_output=True, timeout=120)
                if proc.returncode == 0 and output_wav.exists() and output_wav.stat().st_size > 1000:
                    return True, str(output_wav)
                return True, str(mp3_path)
            return True, str(mp3_path)
    except Exception as e:
        edge_msg = str(e)
    else:
        edge_msg = "Edge TTS did not create a usable file."

    # Local fallback path. Quality depends on OS-installed voices.
    pyttsx_ok, pyttsx_install_msg = ensure_python_package("pyttsx3", "pyttsx3")
    try:
        if not pyttsx_ok:
            raise RuntimeError(pyttsx_install_msg)
        import pyttsx3  # type: ignore
        engine = pyttsx3.init()
        voices = engine.getProperty("voices") or []
        chosen = None
        female_tokens = ["female", "zira", "jenny", "samantha", "karen", "victoria", "tessa", "veena", "hazel"]
        male_tokens = ["male", "guy", "david", "mark", "daniel", "alex", "fred", "ravi"]
        toks = female_tokens if target == "female" else male_tokens if target == "male" else []
        for v in voices:
            name = (getattr(v, "name", "") + " " + getattr(v, "id", "")).lower()
            if any(t in name for t in toks):
                chosen = v.id
                break
        if chosen:
            engine.setProperty("voice", chosen)
        engine.setProperty("rate", 150)
        engine.setProperty("volume", 1.0)
        engine.save_to_file(clean, str(output_wav))
        engine.runAndWait()
        if output_wav.exists() and output_wav.stat().st_size > 1000:
            return True, str(output_wav)
        return False, "TTS failed. Edge TTS error: " + edge_msg + " | pyttsx3 did not create valid WAV. On Linux/WSL install espeak-ng, or use Edge TTS with internet."
    except Exception as e:
        return False, "TTS audio creation failed. " + ((voice_clone_msg + " | ") if voice_clone_msg else "") + "Edge TTS error: " + edge_msg + " | pyttsx3 error: " + str(e) + " | Fix: run `pip install edge-tts pyttsx3 imageio-ffmpeg` and restart Streamlit."

def lipsync_source_media(profile: Dict[str, Any], prefer_video: bool = False) -> Path:
    """Return authorized presenter source for renderer.

    SadTalker/LivePortrait usually use a portrait image. Wav2Lip can use a video if available.
    """
    if prefer_video:
        src = profile.get("source_path") or ""
        if src and Path(src).exists() and Path(src).suffix.lower() in [".mp4", ".mov", ".avi", ".webm", ".mkv", ".mpeg", ".mpg"]:
            return Path(src)
    return presenter_portrait_path(profile)


def auto_renderer_for_presenter(profile: Dict[str, Any]) -> str:
    """Choose the safest renderer route from the authorized presenter source.

    ASHU production rule:
    - Uploaded face photo -> SadTalker
    - Uploaded/URL presenter video -> Wav2Lip
    - Built-in presenter -> SadTalker preview/package
    """
    source_type = str(profile.get("source_type", "built_in")).lower()
    source_path = str(profile.get("source_path", ""))
    suffix = Path(source_path).suffix.lower() if source_path else ""
    if source_type == "photo" or suffix in [".png", ".jpg", ".jpeg", ".webp"]:
        return "SadTalker"
    if source_type in ["video", "url_video"] or suffix in [".mp4", ".mov", ".avi", ".webm", ".mkv", ".mpeg", ".mpg"]:
        return "Wav2Lip"
    return "SadTalker"




def create_delaunay_facetalk_preview(
    presenter_image: Path,
    audio_path: Path,
    output_video: Path,
    duration_s: float = 6.0,
    fps: int = 24,
) -> Tuple[bool, str]:
    """Create a lightweight local geometric talking-face preview video.

    This is not a neural deepfake. It is an immediate Delaunay/landmark-inspired
    face-points animation for demos when SadTalker/Wav2Lip checkpoints are not
    installed yet. It uses the authorized presenter portrait, synthetic face
    control points, animated jaw/mouth points, and optional audio muxing.
    """
    if cv2 is None:
        return False, "OpenCV is not available."
    try:
        img = cv2.imread(str(presenter_image))
        if img is None:
            return False, f"Could not read presenter image: {presenter_image}"
        h, w = img.shape[:2]
        max_w = 720
        if w > max_w:
            scale = max_w / w
            img = cv2.resize(img, (int(w*scale), int(h*scale)))
            h, w = img.shape[:2]
        output_video.parent.mkdir(parents=True, exist_ok=True)
        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        tmp_video = output_video.with_name(output_video.stem + "_silent.mp4")
        writer = cv2.VideoWriter(str(tmp_video), fourcc, fps, (w, h))
        if not writer.isOpened():
            return False, "Could not create preview video writer."
        # Try face box; fallback to center portrait.
        fx, fy, fw, fh = int(w*.22), int(h*.12), int(w*.56), int(h*.72)
        try:
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
            faces = cascade.detectMultiScale(gray, 1.1, 4)
            if len(faces):
                fx, fy, fw, fh = sorted(faces, key=lambda b: b[2]*b[3], reverse=True)[0]
                fy = max(0, fy - int(.12*fh)); fh = min(h-fy, int(fh*1.45))
        except Exception:
            pass
        pts_norm = [(0.50,0.13),(0.33,0.25),(0.67,0.25),(0.26,0.43),(0.74,0.43),(0.33,0.63),(0.67,0.63),(0.43,0.50),(0.57,0.50),(0.43,0.61),(0.57,0.61),(0.50,0.69),(0.50,0.84),(0.25,0.76),(0.75,0.76)]
        tri = [(0,1,2),(1,3,7),(2,8,4),(3,5,9),(4,10,6),(7,8,9),(8,10,9),(9,10,11),(5,13,12),(6,12,14),(5,9,12),(6,10,12),(1,7,0),(2,0,8)]
        total_frames = max(1, int(duration_s * fps))
        for k in range(total_frames):
            frame = img.copy()
            amp = 0.5 + 0.5 * math.sin(k * 0.65)
            pts = []
            for x,y in pts_norm:
                extra = amp*.045 if y > .58 else 0
                pts.append((int(fx + x*fw), int(fy + (y+extra)*fh)))
            overlay = frame.copy()
            for a,b,c in tri:
                cv2.polylines(overlay, [np.array([pts[a],pts[b],pts[c]], dtype=np.int32)], True, (255, 210, 40), 1, cv2.LINE_AA)
            for i,(x,y) in enumerate(pts[:13]):
                cv2.circle(overlay, (x,y), 2 if i!=11 else 3, (255, 230, 60), -1, cv2.LINE_AA)
            mx = int(fx + .50*fw); my = int(fy + (.64 + amp*.045)*fh)
            cv2.ellipse(overlay, (mx,my), (int(.14*fw), int((.025+amp*.045)*fh)), 0, 0, 360, (10, 20, 45), -1, cv2.LINE_AA)
            cv2.ellipse(overlay, (mx,my), (int(.14*fw), int((.025+amp*.045)*fh)), 0, 0, 360, (255,255,255), 1, cv2.LINE_AA)
            frame = cv2.addWeighted(overlay, 0.72, frame, 0.28, 0)
            writer.write(frame)
        writer.release()
        # Mux audio when ffmpeg available.
        if audio_path.exists() and imageio_ffmpeg is not None:
            ffmpeg = imageio_ffmpeg.get_ffmpeg_exe()
            cmd = [ffmpeg, "-y", "-i", str(tmp_video), "-i", str(audio_path), "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest", str(output_video)]
            proc = subprocess.run(cmd, text=True, capture_output=True, timeout=120)
            if proc.returncode == 0 and output_video.exists():
                return True, str(output_video)
        shutil.copy2(tmp_video, output_video)
        return True, str(output_video)
    except Exception as e:
        return False, f"Delaunay FaceTalk preview failed: {e}"

def build_lipsync_manifest(
    *,
    text: str,
    context_label: str,
    renderer: str,
    voice_profile: str,
    audio_path: Optional[Path],
    output_video: Path,
) -> Dict[str, Any]:
    profile = st.session_state.presenter_profile
    prefer_video = renderer.lower() == "wav2lip"
    source_media = lipsync_source_media(profile, prefer_video=prefer_video)
    manifest = {
        "created_at": dt.datetime.now().isoformat(),
        "ashu_feature": "Consent-based production lip-sync renderer",
        "context_label": context_label,
        "renderer": renderer,
        "authorization": {
            "consent_confirmed": bool(profile.get("consent_confirmed", False)),
            "release_id": profile.get("release_id", ""),
            "display_name": profile.get("display_name", "ASHU Presenter"),
            "source_type": profile.get("source_type", "built_in"),
        },
        "inputs": {
            "script_text": text,
            "voice_profile": voice_profile,
            "presenter_source_media": str(source_media),
            "tts_audio": str(audio_path) if audio_path else "",
        },
        "outputs": {
            "target_video": str(output_video),
            "output_directory": str(output_video.parent),
        },
        "safety": {
            "allowed_use": "Only with written authorization for presenter face/video/voice.",
            "blocked_use": "Non-consensual YouTube/person cloning or deceptive impersonation.",
            "candidate_recording_is_separate": True,
        },
    }
    return manifest


def renderer_command(renderer: str, repo_dir: Path, manifest: Dict[str, Any], checkpoint_path: str = "") -> List[str]:
    """Build best-effort commands for common renderer repos.

    Repos change their CLI over time, so the app also exports the manifest for manual/production use.
    """
    r = renderer.lower()
    source = manifest["inputs"]["presenter_source_media"]
    audio = manifest["inputs"]["tts_audio"]
    out = manifest["outputs"]["target_video"]
    py = sys.executable
    if r == "sadtalker":
        return [py, str(repo_dir / "inference.py"), "--driven_audio", audio, "--source_image", source, "--result_dir", str(Path(out).parent), "--still", "--preprocess", "full"]
    if r == "wav2lip":
        ckpt = checkpoint_path or str(repo_dir / "checkpoints" / "wav2lip_gan.pth")
        return [py, str(repo_dir / "inference.py"), "--checkpoint_path", ckpt, "--face", source, "--audio", audio, "--outfile", out]
    if r == "musetalk":
        # MuseTalk setups vary. Export manifest and give a command placeholder that users can adapt.
        return [py, str(repo_dir / "scripts" / "inference.py"), "--inference_config", str(Path(out).parent / "musetalk_manifest.json")]
    if r == "liveportrait":
        return [py, str(repo_dir / "inference.py"), "-s", source, "-d", audio, "-o", str(Path(out).parent)]
    return []


def run_renderer_command(cmd: List[str], cwd: Optional[Path] = None, timeout_s: int = 900) -> Tuple[bool, str]:
    if not cmd:
        return False, "No renderer command available for this mode. Use the exported manifest with your renderer environment."
    try:
        proc = subprocess.run(cmd, cwd=str(cwd) if cwd else None, text=True, capture_output=True, timeout=timeout_s)
        output = (proc.stdout or "") + "\n" + (proc.stderr or "")
        return proc.returncode == 0, output[-6000:]
    except Exception as e:
        return False, str(e)





def process_is_running(pid: int) -> bool:
    """Return True when a background renderer process is still alive."""
    try:
        if not pid:
            return False
        os.kill(int(pid), 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except Exception:
        return False


def start_renderer_background(cmd: List[str], cwd: Optional[Path], log_path: Path) -> Dict[str, Any]:
    """Start SadTalker/Wav2Lip without blocking Streamlit UI."""
    if not cmd:
        raise RuntimeError("No renderer command available")
    log_path.parent.mkdir(parents=True, exist_ok=True)
    log_f = open(log_path, "w", encoding="utf-8", errors="ignore")
    try:
        proc = subprocess.Popen(
            cmd,
            cwd=str(cwd) if cwd else None,
            stdout=log_f,
            stderr=subprocess.STDOUT,
            text=True,
            start_new_session=True,
        )
        return {
            "pid": proc.pid,
            "cmd": cmd,
            "cwd": str(cwd) if cwd else "",
            "log_path": str(log_path),
            "started_at": dt.datetime.now().isoformat(timespec="seconds"),
        }
    finally:
        try:
            log_f.close()
        except Exception:
            pass


def start_voice_clone_background(text: str, output_wav: Path, speaker_sample: Path, log_path: Path) -> Dict[str, Any]:
    """Start XTTS voice generation without blocking Streamlit UI."""
    clean = re.sub(r"\s+", " ", text or "").strip()
    if not clean:
        raise RuntimeError("No text available for voice generation")
    if not speaker_sample.exists() or speaker_sample.stat().st_size < 1000:
        raise RuntimeError(f"Voice sample missing or too small: {speaker_sample}")
    output_wav.parent.mkdir(parents=True, exist_ok=True)
    text_file = output_wav.with_suffix(".script.txt")
    text_file.write_text(clean, encoding="utf-8")
    voice_env = os.environ.get("ASHU_VOICE_ENV", "ashu_voice")
    conda_exe = os.environ.get("CONDA_EXE") or shutil.which("conda") or "/home/anubhaparashar/anaconda3/bin/conda"
    voice_script = BASE_DIR / "tools" / "voice_clone_xtts.py"
    if not voice_script.exists():
        raise RuntimeError(f"Voice clone helper not found: {voice_script}")
    cmd = [
        conda_exe,
        "run",
        "-n",
        voice_env,
        "python",
        str(voice_script),
        "--text-file",
        str(text_file),
        "--speaker",
        str(speaker_sample),
        "--out",
        str(output_wav),
    ]
    log_path.parent.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    if env.get("COQUI_TOS_AGREED"):
        env["COQUI_TOS_AGREED"] = env.get("COQUI_TOS_AGREED", "1")
    log_f = open(log_path, "w", encoding="utf-8", errors="ignore")
    try:
        proc = subprocess.Popen(
            cmd,
            stdout=log_f,
            stderr=subprocess.STDOUT,
            text=True,
            start_new_session=True,
            env=env,
        )
        return {
            "pid": proc.pid,
            "cmd": cmd,
            "voice_env": voice_env,
            "log_path": str(log_path),
            "audio_path": str(output_wav),
            "started_at": dt.datetime.now().isoformat(timespec="seconds"),
        }
    finally:
        try:
            log_f.close()
        except Exception:
            pass


# -----------------------------------------------------------------------------
# Local lip-sync renderer health checks
# -----------------------------------------------------------------------------
def _path_from_text(value: str) -> Optional[Path]:
    if not value or not str(value).strip():
        return None
    try:
        return Path(str(value).strip()).expanduser().resolve()
    except Exception:
        return Path(str(value).strip()).expanduser()


def _safe_file_count(folder: Path, patterns: List[str], limit: int = 30) -> List[str]:
    found: List[str] = []
    if not folder.exists():
        return found
    for pat in patterns:
        try:
            for fp in folder.rglob(pat):
                if fp.is_file():
                    found.append(str(fp))
                    if len(found) >= limit:
                        return found
        except Exception:
            continue
    return found


def _common_renderer_candidates(renderer: str) -> List[Path]:
    """Candidate repo paths for locally installed renderers."""
    r = renderer.lower()
    names = {
        "sadtalker": ["SadTalker", "sadtalker", "OpenTalker-SadTalker"],
        "wav2lip": ["Wav2Lip", "wav2lip", "Wav2Lip-HD"],
    }.get(r, [])
    env_keys = {
        "sadtalker": ["SADTALKER_HOME", "SADTALKER_REPO"],
        "wav2lip": ["WAV2LIP_HOME", "WAV2LIP_REPO"],
    }.get(r, [])
    candidates: List[Path] = []
    for k in env_keys:
        v = os.environ.get(k)
        if v:
            candidates.append(Path(v).expanduser())
    base_dirs = [
        DEFAULT_RENDERER_ROOT,
        BASE_DIR / "renderers",
        BASE_DIR.parent / "renderers",
        Path.cwd(),
        Path.cwd() / "renderers",
        Path.home(),
        Path.home() / "renderers",
        Path.home() / "ashu_renderers",
        Path.home() / "Downloads",
        Path.home() / "Documents",
    ]
    for b in base_dirs:
        for n in names:
            candidates.append(b / n)
    # keep order, remove duplicates
    out: List[Path] = []
    seen = set()
    for c in candidates:
        key = str(c)
        if key not in seen:
            seen.add(key)
            out.append(c)
    return out


def detect_renderer_repo(renderer: str, user_path: str = "") -> Optional[Path]:
    explicit = _path_from_text(user_path)
    candidates = [explicit] if explicit else []
    candidates += _common_renderer_candidates(renderer)
    for c in candidates:
        if not c:
            continue
        if renderer.lower() == "sadtalker" and (c / "inference.py").exists():
            # SadTalker repos usually have examples/, src/, checkpoints/ and inference.py.
            return c
        if renderer.lower() == "wav2lip" and (c / "inference.py").exists():
            # Wav2Lip also uses inference.py, but checkpoint names differ.
            text = " ".join([x.name.lower() for x in c.iterdir()]) if c.exists() and c.is_dir() else ""
            if "wav2lip" in str(c).lower() or "wav2lip" in text or (c / "face_detection").exists():
                return c
    return None


def _python_runtime_status() -> Dict[str, Any]:
    status: Dict[str, Any] = {
        "python": sys.executable,
        "ffmpeg": bool(shutil.which("ffmpeg")) or imageio_ffmpeg is not None,
        "imageio_ffmpeg": bool(imageio_ffmpeg is not None),
        "torch": False,
        "cuda": False,
        "cuda_device": "",
    }
    try:
        import torch  # type: ignore
        status["torch"] = True
        status["cuda"] = bool(torch.cuda.is_available())
        if status["cuda"]:
            try:
                status["cuda_device"] = torch.cuda.get_device_name(0)
            except Exception:
                status["cuda_device"] = "CUDA device detected"
    except Exception as e:
        status["torch_error"] = str(e)
    return status


def check_sadtalker(repo_path: str = "") -> Dict[str, Any]:
    """Check whether SadTalker is locally installed and likely runnable.

    SadTalker is a command-line renderer, not a daemon/server. So "running" here means
    the repo, inference script, checkpoints, Python deps, and ffmpeg are present enough
    for ASHU to launch it on demand.
    """
    repo = detect_renderer_repo("sadtalker", repo_path)
    rt = _python_runtime_status()
    result: Dict[str, Any] = {
        "renderer": "SadTalker",
        "route": "authorized face photo → SadTalker",
        "repo_found": bool(repo),
        "repo_path": str(repo) if repo else repo_path,
        "ready": False,
        "runnable_on_demand": False,
        "missing": [],
        "checkpoints": [],
        "runtime": rt,
        "message": "",
    }
    if not repo:
        result["missing"].append("SadTalker repo not found. Set SADTALKER_HOME or paste local repo path.")
        result["message"] = "SadTalker not installed/detected."
        return result
    if not (repo / "inference.py").exists():
        result["missing"].append("inference.py not found in SadTalker repo")
    ckpts = _safe_file_count(repo, ["*.pth", "*.safetensors", "*.onnx", "*.ckpt"], limit=50)
    result["checkpoints"] = ckpts[:10]
    if len(ckpts) < 2:
        result["missing"].append("SadTalker checkpoints/weights not detected")
    for dep, ok in [("ffmpeg", rt.get("ffmpeg")), ("torch", rt.get("torch"))]:
        if not ok:
            result["missing"].append(f"{dep} not available in current Python/system environment")
    result["ready"] = len(result["missing"]) == 0
    result["runnable_on_demand"] = result["ready"]
    result["message"] = "SadTalker ready for local rendering." if result["ready"] else "SadTalker detected but not fully ready."
    return result


def check_wav2lip(repo_path: str = "") -> Dict[str, Any]:
    """Check whether Wav2Lip is locally installed and likely runnable."""
    repo = detect_renderer_repo("wav2lip", repo_path)
    rt = _python_runtime_status()
    result: Dict[str, Any] = {
        "renderer": "Wav2Lip",
        "route": "authorized presenter video/URL → Wav2Lip",
        "repo_found": bool(repo),
        "repo_path": str(repo) if repo else repo_path,
        "ready": False,
        "runnable_on_demand": False,
        "missing": [],
        "checkpoints": [],
        "runtime": rt,
        "message": "",
    }
    if not repo:
        result["missing"].append("Wav2Lip repo not found. Set WAV2LIP_HOME or paste local repo path.")
        result["message"] = "Wav2Lip not installed/detected."
        return result
    if not (repo / "inference.py").exists():
        result["missing"].append("inference.py not found in Wav2Lip repo")
    ckpts = _safe_file_count(repo, ["*wav2lip*.pth", "*.pth", "*.safetensors", "*.ckpt"], limit=50)
    result["checkpoints"] = ckpts[:10]
    if not any("wav2lip" in Path(c).name.lower() for c in ckpts):
        result["missing"].append("Wav2Lip checkpoint not detected, e.g. wav2lip_gan.pth or wav2lip.pth")
    for dep, ok in [("ffmpeg", rt.get("ffmpeg")), ("torch", rt.get("torch"))]:
        if not ok:
            result["missing"].append(f"{dep} not available in current Python/system environment")
    result["ready"] = len(result["missing"]) == 0
    result["runnable_on_demand"] = result["ready"]
    result["message"] = "Wav2Lip ready for local rendering." if result["ready"] else "Wav2Lip detected but not fully ready."
    return result


def check_lipsync_renderers(sadtalker_path: str = "", wav2lip_path: str = "") -> Dict[str, Any]:
    status = {
        "SadTalker": check_sadtalker(sadtalker_path),
        "Wav2Lip": check_wav2lip(wav2lip_path),
        "checked_at": dt.datetime.now().isoformat(timespec="seconds"),
    }
    status["any_ready"] = bool(status["SadTalker"].get("ready") or status["Wav2Lip"].get("ready"))
    status["all_ready"] = bool(status["SadTalker"].get("ready") and status["Wav2Lip"].get("ready"))
    return status


def renderer_status_card(name: str, status: Dict[str, Any]) -> None:
    """Show renderer health without nested expanders.

    This function is intentionally expander-free because the runtime check panel is
    often placed inside a Streamlit expander. Nested expanders raise
    StreamlitAPIException.
    """
    ready = bool(status.get("ready"))
    label = "Ready" if ready else "Needs setup"
    if ready:
        st.success(f"{name}: {label}")
    else:
        st.warning(f"{name}: {label}")
    repo = status.get("repo_path") or "Not detected"
    st.caption(f"Repo: {repo}")
    if status.get("checkpoints"):
        st.caption(f"Weights detected: {len(status.get('checkpoints', []))} sample file(s)")
    missing = status.get("missing") or []
    if missing:
        st.markdown("**Missing items:**")
        for item in missing:
            st.markdown(f"- {item}")
    if st.checkbox(f"Show {name} technical health JSON", value=False, key=f"show_{name.lower()}_health_json"):
        st.json(status)


def run_setup_command(cmd: List[str], cwd: Optional[Path] = None, timeout_s: int = 1800) -> Tuple[bool, str]:
    """Run a setup command and return safe captured logs."""
    try:
        proc = subprocess.run(
            cmd,
            cwd=str(cwd) if cwd else None,
            capture_output=True,
            text=True,
            timeout=timeout_s,
            check=False,
        )
        out = (proc.stdout or "") + (proc.stderr or "")
        return proc.returncode == 0, out[-12000:]
    except subprocess.TimeoutExpired as exc:
        return False, f"Command timed out after {timeout_s}s: {' '.join(cmd)}\n{str(exc)}"
    except Exception as exc:
        return False, f"Command failed: {' '.join(cmd)}\n{type(exc).__name__}: {exc}"


def clone_repo_if_missing(url: str, target: Path) -> Tuple[bool, str]:
    if target.exists() and any(target.iterdir()):
        return True, f"Already exists: {target}"
    target.parent.mkdir(parents=True, exist_ok=True)
    return run_setup_command(["git", "clone", "--depth", "1", url, str(target)], timeout_s=1800)


def pip_install_requirements(repo: Path) -> Tuple[bool, str]:
    req = repo / "requirements.txt"
    if not req.exists():
        return True, f"No requirements.txt found in {repo}; skipped."
    return run_setup_command([sys.executable, "-m", "pip", "install", "-r", str(req)], cwd=repo, timeout_s=1800)


def setup_sadtalker_once(root: Path, install_deps: bool = True, download_models: bool = True) -> Tuple[Path, str]:
    repo = root / "SadTalker"
    logs = []
    ok, out = clone_repo_if_missing("https://github.com/OpenTalker/SadTalker.git", repo)
    logs.append(f"$ clone SadTalker\n{out}")
    if ok and install_deps:
        ok2, out2 = pip_install_requirements(repo)
        logs.append(f"$ pip install SadTalker requirements\n{out2}")
    if download_models and repo.exists():
        script = repo / "scripts" / "download_models.sh"
        if script.exists():
            ok3, out3 = run_setup_command(["bash", str(script)], cwd=repo, timeout_s=3600)
            logs.append(f"$ SadTalker download_models.sh\n{out3}")
        else:
            logs.append("SadTalker download_models.sh not found; download checkpoints manually from the SadTalker project instructions.")
    return repo, "\n\n".join(logs)


def setup_wav2lip_once(root: Path, install_deps: bool = True, download_checkpoint: bool = True) -> Tuple[Path, str]:
    """One-time Wav2Lip setup with Python 3.10-friendly dependencies.

    The original Wav2Lip requirements pin very old numpy/librosa versions. Those
    often fail on Python 3.10, so ASHU writes and installs a patched dependency
    file instead. It also tries to fetch wav2lip_gan.pth automatically.
    """
    repo = root / "Wav2Lip"
    logs: List[str] = []
    ok, out = clone_repo_if_missing("https://github.com/Rudrabha/Wav2Lip.git", repo)
    logs.append(f"$ clone Wav2Lip\n{out}")
    if ok and install_deps:
        req_py310 = repo / "requirements_py310_ashu.txt"
        req_py310.write_text(
            "numpy==1.23.5\n"
            "scipy==1.10.1\n"
            "scikit-learn==1.2.2\n"
            "librosa==0.9.2\n"
            "numba==0.57.1\n"
            "llvmlite==0.40.1\n"
            "opencv-python==4.8.1.78\n"
            "opencv-contrib-python==4.8.1.78\n"
            "face-alignment==1.3.5\n"
            "tqdm\n"
            "matplotlib\n"
            "requests\n",
            encoding="utf-8",
        )
        ok2, out2 = run_setup_command([sys.executable, "-m", "pip", "install", "-r", str(req_py310)], cwd=repo, timeout_s=2400)
        logs.append(f"$ pip install Wav2Lip Python 3.10 requirements\n{out2}")
        # librosa needs pkg_resources in several environments. Pin setuptools to a compatible release.
        ok3, out3 = run_setup_command([sys.executable, "-m", "pip", "install", "setuptools==80.8.0", "wheel==0.45.1"], cwd=repo, timeout_s=600)
        logs.append(f"$ ensure setuptools/pkg_resources compatibility\n{out3}")
    ckpt_dir = repo / "checkpoints"
    ckpt_dir.mkdir(parents=True, exist_ok=True)
    ckpt = ckpt_dir / "wav2lip_gan.pth"
    if download_checkpoint and not ckpt.exists():
        # Use the Python API instead of huggingface-cli because some versions moved CLI entry points.
        py_code = """
from pathlib import Path
import shutil
from huggingface_hub import hf_hub_download
target = Path(r'__TARGET__')
target.parent.mkdir(parents=True, exist_ok=True)
downloaded = hf_hub_download(repo_id='rippertnt/wav2lip', filename='checkpoints/wav2lip_gan.pth')
shutil.copy2(downloaded, target)
print('Downloaded checkpoint to:', target)
print('Size MB:', round(target.stat().st_size/(1024*1024), 2))
""".replace("__TARGET__", str(ckpt))
        ok_hf, out_hf = run_setup_command([sys.executable, "-m", "pip", "install", "huggingface_hub==0.25.2"], cwd=repo, timeout_s=900)
        logs.append(f"$ install huggingface_hub for checkpoint download\n{out_hf}")
        ok_dl, out_dl = run_setup_command([sys.executable, "-c", py_code], cwd=repo, timeout_s=3600)
        logs.append(f"$ download wav2lip_gan.pth\n{out_dl}")
    else:
        logs.append(f"Wav2Lip checkpoint already present or download skipped: {ckpt}")
    logs.append(f"Wav2Lip repo path: {repo}\nWav2Lip checkpoint path: {ckpt}")
    return repo, "\n\n".join(logs)

def renderer_one_time_setup_panel() -> None:
    st.markdown("### One-time lip-sync setup")
    st.caption("Run this once. ASHU will create a local renderers folder, clone SadTalker/Wav2Lip, install Python requirements, try to download SadTalker checkpoints, and save paths for future runs.")
    root_text = st.text_input(
        "Install folder",
        value=st.session_state.get("renderer_install_root", str(DEFAULT_RENDERER_ROOT)),
        key="renderer_install_root_input",
        help="Recommended shared path: ~/ashu_renderers. ASHU auto-detects SadTalker/Wav2Lip from here.",
    )
    st.session_state.renderer_install_root = root_text
    install_deps = st.checkbox("Install renderer Python requirements", value=True, key="setup_renderer_deps")
    download_sadtalker_models = st.checkbox("Try to download SadTalker checkpoints automatically", value=True, key="setup_sadtalker_models")
    download_wav2lip_checkpoint = st.checkbox("Try to download Wav2Lip checkpoint automatically", value=True, key="setup_wav2lip_checkpoint")
    c1, c2, c3 = st.columns(3)
    with c1:
        run_all = st.button("Run one-time setup", type="primary", key="run_lipsync_one_time_setup")
    with c2:
        run_sad = st.button("Setup SadTalker only", key="run_sadtalker_only_setup")
    with c3:
        run_wav = st.button("Setup Wav2Lip only", key="run_wav2lip_only_setup")

    if run_all or run_sad or run_wav:
        root = Path(root_text).expanduser().resolve()
        root.mkdir(parents=True, exist_ok=True)
        logs = []
        with st.spinner("Setting up local lip-sync renderers. First run can take several minutes..."):
            if run_all or run_sad:
                sad_repo, sad_log = setup_sadtalker_once(root, install_deps=install_deps, download_models=download_sadtalker_models)
                st.session_state.sadtalker_repo_path = str(sad_repo)
                logs.append(sad_log)
            if run_all or run_wav:
                wav_repo, wav_log = setup_wav2lip_once(root, install_deps=install_deps, download_checkpoint=download_wav2lip_checkpoint)
                st.session_state.wav2lip_repo_path = str(wav_repo)
                logs.append(wav_log)
            st.session_state.renderer_setup_log = "\n\n".join(logs)
            st.session_state.renderer_health = check_lipsync_renderers(st.session_state.sadtalker_repo_path, st.session_state.wav2lip_repo_path)
        st.success("One-time setup finished. Review health status below.")

    # Wav2Lip checkpoint upload, because official checkpoints are often distributed separately.
    wav_repo_path = Path(st.session_state.get("wav2lip_repo_path") or Path(root_text).expanduser().resolve() / "Wav2Lip")
    uploaded_ckpt = st.file_uploader(
        "Optional: upload Wav2Lip checkpoint once (.pth)",
        type=["pth"],
        key="wav2lip_checkpoint_upload_once",
        help="Save wav2lip_gan.pth or wav2lip.pth into Wav2Lip/checkpoints so ASHU can render video presenters.",
    )
    if uploaded_ckpt is not None:
        ckpt_dir = wav_repo_path / "checkpoints"
        ckpt_dir.mkdir(parents=True, exist_ok=True)
        save_name = uploaded_ckpt.name if uploaded_ckpt.name.endswith(".pth") else "wav2lip_gan.pth"
        out_path = ckpt_dir / save_name
        out_path.write_bytes(uploaded_ckpt.getvalue())
        st.success(f"Saved checkpoint: {out_path}")
        st.session_state.renderer_health = check_lipsync_renderers(st.session_state.sadtalker_repo_path, st.session_state.wav2lip_repo_path)

    if st.session_state.get("renderer_setup_log"):
        st.text_area("Setup log", value=st.session_state.renderer_setup_log, height=260)


def lipsync_runtime_health_panel() -> None:
    auto_fill_renderer_paths()
    st.markdown("### Local lip-sync runtime")
    st.caption("ASHU can set this up once and then check it like Ollama. SadTalker is used for face photos; Wav2Lip is used for presenter videos/URLs.")

    renderer_one_time_setup_panel()
    st.markdown("---")
    st.markdown("### Runtime health check")
    colp1, colp2 = st.columns(2)
    with colp1:
        st.session_state.sadtalker_repo_path = st.text_input(
            "SadTalker local repo path",
            value=st.session_state.get("sadtalker_repo_path", str(DEFAULT_SADTALKER_REPO)),
            placeholder=str(DEFAULT_SADTALKER_REPO),
            key="global_sadtalker_path",
        )
    with colp2:
        st.session_state.wav2lip_repo_path = st.text_input(
            "Wav2Lip local repo path",
            value=st.session_state.get("wav2lip_repo_path", str(DEFAULT_WAV2LIP_REPO)),
            placeholder=str(DEFAULT_WAV2LIP_REPO),
            key="global_wav2lip_path",
        )
    c1, c2 = st.columns([0.35, 0.65])
    with c1:
        if st.button("Check renderers now", type="primary", key="check_lipsync_renderers_now"):
            st.session_state.renderer_health = check_lipsync_renderers(st.session_state.sadtalker_repo_path, st.session_state.wav2lip_repo_path)
    with c2:
        st.info("Auto route: uploaded face photo → SadTalker. Uploaded/URL presenter video → Wav2Lip.")
    if not st.session_state.get("renderer_health"):
        st.session_state.renderer_health = check_lipsync_renderers(st.session_state.sadtalker_repo_path, st.session_state.wav2lip_repo_path)
    hc1, hc2 = st.columns(2)
    with hc1:
        renderer_status_card("SadTalker", st.session_state.renderer_health.get("SadTalker", {}))
    with hc2:
        renderer_status_card("Wav2Lip", st.session_state.renderer_health.get("Wav2Lip", {}))
    st.markdown("**Expected folder layout**")
    st.code("""renderers/
  SadTalker/
    inference.py
    checkpoints/ or gfpgan/weights/...
  Wav2Lip/
    inference.py
    checkpoints/wav2lip_gan.pth
""", language="text")


def renderer_checkpoint_path_for(renderer: str) -> str:
    if renderer.lower() == "wav2lip":
        ckpt = DEFAULT_WAV2LIP_CHECKPOINT
        if ckpt.exists():
            return str(ckpt)
        health = st.session_state.get("renderer_health", {}).get("Wav2Lip", {})
        for fp in health.get("checkpoints", []) or []:
            if str(fp).endswith(".pth"):
                return str(fp)
        return str(ckpt)
    return ""


def auto_fill_renderer_paths() -> None:
    """Keep renderer fields filled from the default shared folder."""
    if not st.session_state.get("sadtalker_repo_path"):
        st.session_state.sadtalker_repo_path = str(DEFAULT_SADTALKER_REPO)
    if not st.session_state.get("wav2lip_repo_path"):
        st.session_state.wav2lip_repo_path = str(DEFAULT_WAV2LIP_REPO)
    if not st.session_state.get("renderer_install_root"):
        st.session_state.renderer_install_root = str(DEFAULT_RENDERER_ROOT)


def renderer_repo_path_for(renderer: str) -> str:
    if renderer.lower() == "sadtalker":
        health = st.session_state.get("renderer_health", {}).get("SadTalker", {})
        return st.session_state.get("sadtalker_repo_path") or health.get("repo_path", "") or str(DEFAULT_SADTALKER_REPO)
    if renderer.lower() == "wav2lip":
        health = st.session_state.get("renderer_health", {}).get("Wav2Lip", {})
        return st.session_state.get("wav2lip_repo_path") or health.get("repo_path", "") or str(DEFAULT_WAV2LIP_REPO)
    return ""


def renderer_health_for(renderer: str) -> Dict[str, Any]:
    key = "SadTalker" if renderer.lower() == "sadtalker" else "Wav2Lip"
    health = st.session_state.get("renderer_health", {}).get(key)
    if not health:
        st.session_state.renderer_health = check_lipsync_renderers(st.session_state.get("sadtalker_repo_path", ""), st.session_state.get("wav2lip_repo_path", ""))
        health = st.session_state.renderer_health.get(key, {})
    return health or {}



def safe_streamlit_audio(audio_file: Path) -> bool:
    """Play audio robustly in Streamlit by loading bytes instead of giving a path.

    This avoids MediaFileStorageError when generated audio lives in a Windows/OneDrive/WSL
    path with spaces, and it also supports Edge TTS MP3 fallback when WAV conversion is
    unavailable.
    """
    try:
        if not audio_file or not Path(audio_file).exists():
            st.warning(f"Audio file not found: {audio_file}")
            return False
        audio_file = Path(audio_file)
        suffix = audio_file.suffix.lower()
        fmt = "audio/wav" if suffix == ".wav" else "audio/mpeg" if suffix == ".mp3" else "audio/mp4"
        st.audio(audio_file.read_bytes(), format=fmt)
        return True
    except Exception as exc:
        st.warning(f"Audio was generated, but preview could not be opened in Streamlit: {exc}")
        st.caption(str(audio_file))
        return False



def save_authorized_voice_sample(uploaded_obj: Any, key_prefix: str, source: str = "upload") -> str:
    """Save a consented presenter voice sample for optional local voice cloning."""
    try:
        if uploaded_obj is None:
            return ""
        raw = uploaded_obj.getvalue() if hasattr(uploaded_obj, "getvalue") else uploaded_obj.read()
        if not raw:
            return ""
        original_name = getattr(uploaded_obj, "name", "voice_sample.webm") or "voice_sample.webm"
        suffix = Path(original_name).suffix.lower() or ".webm"
        safe = safe_filename(f"authorized_voice_{source}_{now_id()}") + suffix
        out = VOICE_SAMPLE_DIR / safe
        out.write_bytes(raw)
        persist_authorized_voice_sample(str(out), source=source)
        st.session_state.authorized_voice_sample_path = str(out)
        st.session_state.authorized_voice_sample_notice = "Authorized voice sample saved and set as default. It will be prefetched automatically next time you open the app. For best cloning, use 30-90 seconds of clear speech with low noise."
        return str(out)
    except Exception as exc:
        st.warning(f"Could not save voice sample: {exc}")
        return ""


def latest_video_in_folder(folder: Path) -> Optional[Path]:
    """Find renderer output even when SadTalker ignores the requested output filename."""
    try:
        videos = [p for p in folder.rglob("*.mp4") if p.is_file() and p.stat().st_size > 1000]
        if not videos:
            return None
        return max(videos, key=lambda p: p.stat().st_mtime)
    except Exception:
        return None


def safe_streamlit_video(video_file: Path) -> bool:
    """Preview generated MP4 inside Streamlit and provide its path."""
    try:
        if not video_file or not Path(video_file).exists():
            return False
        video_file = Path(video_file)
        preview_file = ensure_browser_compatible_mp4(video_file)
        st.video(preview_file.read_bytes(), format="video/mp4")
        st.caption(f"Generated video: {preview_file}")
        return True
    except Exception as exc:
        st.warning(f"Video was generated, but preview could not be opened in Streamlit: {exc}")
        st.code(str(video_file))
        return False


def ensure_browser_compatible_mp4(video_file: Path) -> Path:
    """Create an H.264/yuv420p/AAC MP4 preview copy for Chrome/Streamlit if needed.

    Some renderer outputs can play audio but show a black video area in browser iframe players.
    This makes a browser-safe copy once and reuses it.
    """
    try:
        video_file = Path(video_file)
        if not video_file.exists():
            return video_file
        out = video_file.with_name(video_file.stem + "_browser.mp4")
        if out.exists() and out.stat().st_size > 1000 and out.stat().st_mtime >= video_file.stat().st_mtime:
            return out
        ffmpeg = None
        if imageio_ffmpeg is not None:
            ffmpeg = imageio_ffmpeg.get_ffmpeg_exe()
        if not ffmpeg:
            ffmpeg = shutil.which("ffmpeg")
        if not ffmpeg:
            return video_file
        cmd = [
            ffmpeg, "-y", "-i", str(video_file),
            "-c:v", "libx264", "-pix_fmt", "yuv420p", "-profile:v", "baseline", "-level", "3.0",
            "-movflags", "+faststart",
            "-c:a", "aac", "-b:a", "128k",
            str(out),
        ]
        proc = subprocess.run(cmd, text=True, capture_output=True, timeout=300)
        if proc.returncode == 0 and out.exists() and out.stat().st_size > 1000:
            return out
    except Exception:
        pass
    return Path(video_file)

def lipsync_renderer_panel(text_to_render: str, context_label: str, key_prefix: str) -> None:
    """UI panel for real production lip-sync model integration.

    This panel intentionally uses a container instead of an expander, because Streamlit
    throws `Expanders may not be nested` when the training/interview UI is rendered
    inside any other expandable section.
    """
    with st.container(border=True):
        st.markdown("#### Real lip-sync renderer: SadTalker for photos, Wav2Lip for videos")
        st.markdown(
            """
<div class='warn-box'><b>Consent-based only:</b> This creates a real SadTalker/Wav2Lip lip-sync package for an authorized presenter. It does not support non-consensual cloning or deceptive impersonation. Candidate video remains separate.</div>
            """,
            unsafe_allow_html=True,
        )
        recommended_renderer = auto_renderer_for_presenter(st.session_state.presenter_profile)
        source_type = str(st.session_state.presenter_profile.get("source_type", "built_in"))
        renderer_choice = st.selectbox(
            "Renderer route",
            ["Auto route", "SadTalker", "Wav2Lip"],
            key=f"{key_prefix}_renderer",
            help="Auto route uses SadTalker for an uploaded face photo and Wav2Lip for an uploaded/URL presenter video.",
        )
        renderer = recommended_renderer if renderer_choice == "Auto route" else renderer_choice
        st.caption(f"Selected route: **{renderer}**  | Presenter source: `{source_type}`  | Real render rule: photo → SadTalker, video/URL → Wav2Lip")
        if source_type == "photo" and renderer != "SadTalker":
            st.warning("For uploaded face photo, SadTalker is the recommended route. Wav2Lip needs a presenter video.")
        if source_type in ["video", "url_video"] and renderer != "Wav2Lip":
            st.warning("For uploaded presenter video/URL, Wav2Lip is the recommended route. SadTalker will use only an extracted portrait frame.")
        person = active_presenter(st.session_state.presenter_profile)
        voice_profile = st.selectbox(
            "Voice profile for TTS/audio",
            ["neutral", "female", "male"],
            index=["neutral", "female", "male"].index(person.get("voice_profile", "neutral") if person.get("voice_profile") in ["neutral", "female", "male"] else "neutral"),
            key=f"{key_prefix}_voice",
        )
        # Optional authorized voice sample capture. The sample is stored locally and
        # used only when the user explicitly enables it.
        with st.container(border=True):
            st.markdown("##### Optional: use my authorized 30–90 sec voice sample")
            st.caption("Record or upload your own voice only. This is consent-based and is stored locally in the app folder.")
            use_authorized_voice = st.checkbox(
                "Use my authorized voice sample for this presenter voice",
                value=False,
                key=f"{key_prefix}_use_authorized_voice",
            )
            accept_xtts_terms = st.checkbox(
                "I accept the Coqui/XTTS model terms and allow first-time model download",
                value=False,
                key=f"{key_prefix}_accept_xtts_terms",
                help="Required only the first time XTTS downloads the voice-cloning model. Without this, Coqui TTS asks in the terminal and fails inside Streamlit.",
            )
            sample_cols = st.columns(2)
            with sample_cols[0]:
                voice_upload = st.file_uploader(
                    "Upload 30-90 sec voice sample",
                    type=["wav", "mp3", "m4a", "webm", "ogg"],
                    key=f"{key_prefix}_voice_upload",
                )
                if voice_upload is not None:
                    saved_sample = save_authorized_voice_sample(voice_upload, key_prefix, source="upload")
                    if saved_sample:
                        st.success("Voice sample saved")
            with sample_cols[1]:
                audio_input_fn = getattr(st, "audio_input", None)
                if audio_input_fn is not None:
                    recorded_voice = audio_input_fn("Record sample in browser", key=f"{key_prefix}_voice_record")
                    if recorded_voice is not None:
                        saved_sample = save_authorized_voice_sample(recorded_voice, key_prefix, source="recording")
                        if saved_sample:
                            st.success("Recorded voice sample saved")
                else:
                    st.info("Your Streamlit version does not support browser audio recording. Upload a WAV/MP3/WebM sample instead.")
            tool_cols = st.columns(3)
            with tool_cols[0]:
                if st.button("Prefetch latest saved voice sample", key=f"{key_prefix}_prefetch_voice"):
                    latest_saved_voice = find_latest_authorized_voice_sample()
                    if latest_saved_voice:
                        st.session_state.authorized_voice_sample_path = latest_saved_voice
                        st.session_state.authorized_voice_sample_notice = "Latest saved authorized voice sample prefetched."
                        st.success("Latest saved voice sample loaded")
                    else:
                        st.warning("No saved voice sample found yet. Record or upload one first.")
            with tool_cols[1]:
                if st.button("Set current as default", key=f"{key_prefix}_set_default_voice"):
                    current_voice = st.session_state.get("authorized_voice_sample_path", "")
                    if current_voice and Path(current_voice).exists():
                        persist_authorized_voice_sample(current_voice, source="manual_default")
                        st.success("Current sample will be prefetched next time.")
                    else:
                        st.warning("No current sample selected.")
            with tool_cols[2]:
                if st.button("Clear selected sample", key=f"{key_prefix}_clear_voice"):
                    st.session_state.authorized_voice_sample_path = ""
                    st.session_state.authorized_voice_sample_notice = "Selected voice sample cleared. Saved files remain in voice_samples/."
                    st.info("Selection cleared")
            if st.session_state.get("authorized_voice_sample_notice"):
                st.caption(st.session_state.authorized_voice_sample_notice)
            if st.session_state.get("authorized_voice_sample_path"):
                st.markdown("**Prefetched / selected authorized voice sample**")
                st.code(st.session_state.authorized_voice_sample_path)
                try:
                    safe_streamlit_audio(Path(st.session_state.authorized_voice_sample_path))
                except Exception:
                    pass
            if use_authorized_voice:
                if st.session_state.get("authorized_voice_sample_path"):
                    st.info("ASHU will call the voice conda env configured by `ASHU_VOICE_ENV` for XTTS/Coqui voice cloning. Tick the XTTS terms checkbox before first model download. If XTTS fails, ASHU will stop and ask before using automated voice fallback.")
                else:
                    st.warning("Please record or upload your own voice sample first.")

        renderer_health = renderer_health_for(renderer)
        if renderer_health.get("ready"):
            st.success(f"{renderer} runtime ready locally")
        else:
            st.warning(f"{renderer} is not ready locally yet. Open Digital Presenter → Local lip-sync runtime check to see missing repo/weights/dependencies.")
        default_repo_path = renderer_repo_path_for(renderer)
        default_checkpoint_path = renderer_checkpoint_path_for(renderer)
        st.caption("Renderer paths are auto-filled from `~/ashu_renderers`. You normally do not need to edit them.")
        st.caption("Advanced path override is available below if auto-fill is wrong.")
        with st.container(border=True):
            repo_dir_txt = st.text_input(
                "Local renderer repo path",
                value=default_repo_path,
                placeholder="Example: /home/user/SadTalker or /home/user/Wav2Lip",
                key=f"{key_prefix}_repo",
            )
            checkpoint_txt = st.text_input(
                "Checkpoint path (auto-filled for Wav2Lip)",
                value=default_checkpoint_path,
                key=f"{key_prefix}_ckpt",
            )
        if renderer == "Wav2Lip" and not checkpoint_txt.strip():
            checkpoint_txt = str(DEFAULT_WAV2LIP_CHECKPOINT)
        render_dir_key = f"{key_prefix}_lipsync_out_dir"
        if not st.session_state.get(render_dir_key):
            rid = safe_filename(context_label) + "_" + now_id()
            st.session_state[render_dir_key] = str(LIPSYNC_DIR / rid)
        out_dir = Path(st.session_state[render_dir_key])
        out_dir.mkdir(parents=True, exist_ok=True)
        audio_path = out_dir / "tts_audio.wav"
        tts_state_key = f"{key_prefix}_tts_audio_path"
        bg_job_key = f"{key_prefix}_background_render_job"
        voice_job_key = f"{key_prefix}_background_voice_job"
        output_video = out_dir / "talking_presenter_output.mp4"
        manifest = build_lipsync_manifest(
            text=text_to_render,
            context_label=context_label,
            renderer=renderer,
            voice_profile=voice_profile,
            audio_path=audio_path,
            output_video=output_video,
        )
        if st.session_state.get(f"{key_prefix}_use_authorized_voice") and st.session_state.get("authorized_voice_sample_path"):
            manifest["authorization"]["voice_consent_confirmed"] = True
            manifest["inputs"]["authorized_voice_sample"] = st.session_state.get("authorized_voice_sample_path", "")
            manifest["inputs"]["voice_generation_mode"] = "authorized_voice_sample_xtts_if_available"
        st.caption("Source selected for renderer:")
        st.code(manifest["inputs"]["presenter_source_media"])

        with st.container(border=True):
            st.markdown("#### One-click background lecture pipeline")
            st.caption("Prefetches the latest generated lecture when available. If no cached output exists, it starts voice generation in the background.")

            cached_audio = None
            cached_video = None
            cached_dir = None
            cache_prefix = safe_filename(context_label) + "_"
            cached_dirs = sorted(
                [d for d in LIPSYNC_DIR.glob(cache_prefix + "*") if d.is_dir()],
                key=lambda d: d.stat().st_mtime,
                reverse=True,
            )
            for d in cached_dirs:
                pa = d / "tts_audio.wav"
                pv = d / "talking_presenter_output.mp4"
                pv_browser = d / "talking_presenter_output_browser.mp4"
                if pa.exists() and pa.stat().st_size > 1000 and not cached_audio:
                    cached_audio = pa
                if pv_browser.exists() and pv_browser.stat().st_size > 1000:
                    cached_video = pv_browser
                elif pv.exists() and pv.stat().st_size > 1000:
                    cached_video = pv
                elif latest_video_in_folder(d):
                    cached_video = latest_video_in_folder(d)
                if cached_audio or cached_video:
                    cached_dir = d
                    break

            if cached_audio or cached_video:
                st.info(f"Cached lecture output found: {cached_dir}")
            force_regenerate = st.checkbox("Force regenerate instead of using cached output", value=False, key=f"{key_prefix}_force_regenerate")

            cache_cols = st.columns(2)
            with cache_cols[0]:
                if st.button("Prefetch latest generated audio/video", key=f"{key_prefix}_prefetch_cached"):
                    if cached_dir:
                        st.session_state[render_dir_key] = str(cached_dir)
                    if cached_audio:
                        st.session_state[tts_state_key] = str(cached_audio)
                        st.success("Latest generated voice audio prefetched.")
                        safe_streamlit_audio(cached_audio)
                    if cached_video:
                        browser_video = ensure_browser_compatible_mp4(Path(cached_video))
                        st.session_state.last_lipsync_video = str(browser_video)
                        st.success("Latest generated lecture video prefetched.")
                        safe_streamlit_video(browser_video)
                    if not cached_audio and not cached_video:
                        st.warning("No cached audio/video found for this segment yet. Start the background pipeline once.")
            with cache_cols[1]:
                if st.button("Start full background pipeline: voice + video", key=f"{key_prefix}_full_bg_pipeline"):
                    if cached_dir and not force_regenerate:
                        st.session_state[render_dir_key] = str(cached_dir)
                        if cached_audio:
                            st.session_state[tts_state_key] = str(cached_audio)
                        if cached_video:
                            st.session_state.last_lipsync_video = str(ensure_browser_compatible_mp4(Path(cached_video)))
                        st.success("Using latest cached lecture output. Tick Force regenerate if you want to create a new one.")
                    else:
                        voice_sample_for_tts = st.session_state.get("authorized_voice_sample_path", "") if st.session_state.get(f"{key_prefix}_use_authorized_voice") else ""
                        if not voice_sample_for_tts:
                            st.error("Select/tick your authorized voice sample first. For automated voice, use the normal Generate voice audio button.")
                        elif not st.session_state.get(f"{key_prefix}_accept_xtts_terms"):
                            st.error("Tick the Coqui/XTTS terms checkbox before first-time XTTS model download.")
                        else:
                            os.environ["COQUI_TOS_AGREED"] = "1"
                            st.session_state.pop(f"{key_prefix}_voice_generation_error", None)
                            try:
                                vjob = start_voice_clone_background(text_to_render, audio_path, Path(voice_sample_for_tts), out_dir / "voice_generation_run.log")
                                st.session_state[voice_job_key] = vjob
                                st.session_state.pop(bg_job_key, None)
                                st.info("Voice generation started in background. Click Refresh pipeline status after some time.")
                            except Exception as exc:
                                st.error(f"Could not start background voice generation: {exc}")

        col1, col2, col3 = st.columns(3)
        with col1:
            if st.button("1. Generate voice audio", key=f"{key_prefix}_tts"):
                st.session_state.pop(f"{key_prefix}_voice_generation_error", None)
                voice_sample_for_tts = st.session_state.get("authorized_voice_sample_path", "") if st.session_state.get(f"{key_prefix}_use_authorized_voice") else ""
                if voice_sample_for_tts:
                    if st.session_state.get(f"{key_prefix}_accept_xtts_terms"):
                        os.environ["COQUI_TOS_AGREED"] = "1"
                    else:
                        st.warning("XTTS first-time model download may fail until you tick the Coqui/XTTS terms checkbox above.")
                ok, msg = create_server_tts_audio(text_to_render, audio_path, voice_profile, voice_sample_for_tts)
                if ok:
                    actual_audio = Path(msg) if msg else audio_path
                    if not actual_audio.exists() and audio_path.exists():
                        actual_audio = audio_path
                    st.session_state[tts_state_key] = str(actual_audio)
                    st.success(f"Voice audio generated: {actual_audio.name}")
                    safe_streamlit_audio(actual_audio)
                else:
                    st.session_state[f"{key_prefix}_voice_generation_error"] = msg
                    st.error(msg)
                    st.info("Your voice was not used. To keep the app going, approve the automated voice fallback shown below.")
        with col2:
            if st.button("2. Create lip-sync package", key=f"{key_prefix}_pack"):
                actual_audio = Path(st.session_state.get(tts_state_key, str(audio_path)))
                if actual_audio.exists():
                    manifest["inputs"]["tts_audio"] = str(actual_audio)
                (out_dir / "script.txt").write_text(text_to_render, encoding="utf-8")
                (out_dir / "manifest.json").write_text(json_dumps(manifest), encoding="utf-8")
                if actual_audio.exists():
                    try:
                        shutil.copy2(actual_audio, out_dir / ("tts_audio" + actual_audio.suffix.lower()))
                    except Exception:
                        pass
                source = Path(manifest["inputs"]["presenter_source_media"])
                if source.exists() and source.is_file():
                    try:
                        shutil.copy2(source, out_dir / ("presenter_source" + source.suffix.lower()))
                    except Exception:
                        pass
                # Keep the renderer package internal for a clean demo UI.
                # The local renderer reads script.txt, manifest.json, presenter media, and TTS audio
                # directly from out_dir, so a visible ZIP download button is not needed.
                st.session_state.lipsync_artifacts.append(manifest)
                st.success("Lip-sync package prepared for local rendering.")
                st.caption(f"Internal package folder: {out_dir}")
        with col3:
            if st.button("3. Start background lip-sync render", key=f"{key_prefix}_run"):
                actual_audio = Path(st.session_state.get(tts_state_key, str(audio_path)))
                if actual_audio.exists():
                    manifest["inputs"]["tts_audio"] = str(actual_audio)
                repo_dir = Path(repo_dir_txt).expanduser() if repo_dir_txt.strip() else Path("")
                latest_health = check_sadtalker(str(repo_dir)) if renderer == "SadTalker" else check_wav2lip(str(repo_dir))
                if not latest_health.get("ready"):
                    st.error(f"{renderer} is not ready. Fix repo/checkpoint/dependency issues first.")
                    st.json(latest_health)
                elif not repo_dir_txt.strip() or not repo_dir.exists():
                    st.error("Provide a valid local renderer repo path first.")
                elif not actual_audio.exists():
                    st.error("Generate TTS audio first, or place an audio file at the expected path.")
                else:
                    (out_dir / "manifest.json").write_text(json_dumps(manifest), encoding="utf-8")
                    cmd = renderer_command(renderer, repo_dir, manifest, checkpoint_txt)
                    (out_dir / "renderer_command.txt").write_text(" ".join(cmd), encoding="utf-8")
                    try:
                        job = start_renderer_background(cmd, cwd=repo_dir, log_path=(out_dir / "renderer_run.log"))
                        st.session_state[bg_job_key] = job
                        st.info("Background render started. You can keep using the app while SadTalker/Wav2Lip creates the MP4.")
                        st.code(str(out_dir))
                    except Exception as exc:
                        st.error(f"Could not start background renderer: {exc}")
        voice_job = st.session_state.get(voice_job_key)
        if voice_job:
            with st.container(border=True):
                st.markdown("#### Background voice + video pipeline status")
                voice_audio_path = Path(voice_job.get("audio_path", str(audio_path)))
                voice_running = process_is_running(int(voice_job.get("pid", 0)))
                existing_video = output_video if output_video.exists() and output_video.stat().st_size > 1000 else latest_video_in_folder(out_dir)
                current_render_job = st.session_state.get(bg_job_key)
                render_running = process_is_running(int(current_render_job.get("pid", 0))) if current_render_job else False
                if existing_video and existing_video.exists():
                    st.progress(100, text="Completed: final lecture video is ready")
                elif current_render_job and render_running:
                    st.progress(82, text="Rendering video in background")
                elif voice_audio_path.exists() and voice_audio_path.stat().st_size > 1000:
                    st.progress(62, text="Voice audio ready; starting/continuing lip-sync render")
                elif voice_running:
                    st.progress(35, text="Generating voice audio in background")
                else:
                    st.progress(10, text="Pipeline started; waiting for background output or error")

                if voice_audio_path.exists() and voice_audio_path.stat().st_size > 1000:
                    st.success("Voice audio is ready. Starting/continuing background lip-sync render.")
                    st.session_state[tts_state_key] = str(voice_audio_path)
                    safe_streamlit_audio(voice_audio_path)
                    if not st.session_state.get(bg_job_key):
                        manifest["inputs"]["tts_audio"] = str(voice_audio_path)
                        (out_dir / "script.txt").write_text(text_to_render, encoding="utf-8")
                        (out_dir / "manifest.json").write_text(json_dumps(manifest), encoding="utf-8")
                        source = Path(manifest["inputs"].get("presenter_source_media", ""))
                        if source.exists() and source.is_file():
                            try:
                                shutil.copy2(source, out_dir / ("presenter_source" + source.suffix.lower()))
                            except Exception:
                                pass
                        repo_dir_for_auto = Path(repo_dir_txt).expanduser() if repo_dir_txt.strip() else Path("")
                        if repo_dir_for_auto.exists():
                            cmd = renderer_command(renderer, repo_dir_for_auto, manifest, checkpoint_txt)
                            (out_dir / "renderer_command.txt").write_text(" ".join(cmd), encoding="utf-8")
                            try:
                                rjob = start_renderer_background(cmd, cwd=repo_dir_for_auto, log_path=(out_dir / "renderer_run.log"))
                                st.session_state[bg_job_key] = rjob
                                st.info("Lip-sync render started automatically in background.")
                            except Exception as exc:
                                st.error(f"Voice completed, but auto lip-sync start failed: {exc}")
                        else:
                            st.warning("Voice completed, but renderer repo path is invalid. Fix renderer path and start background lip-sync render.")
                elif voice_running:
                    st.info(f"Voice generation is still running in background. PID: {voice_job.get('pid')}.")
                else:
                    st.error("Background voice generation stopped but no audio was produced.")
                    log_path = Path(voice_job.get("log_path", ""))
                    if log_path.exists():
                        st.code(log_path.read_text(errors="ignore")[-4000:])
                if st.button("Refresh pipeline status", key=f"{key_prefix}_refresh_full_pipeline"):
                    st.rerun()

        voice_error = st.session_state.get(f"{key_prefix}_voice_generation_error")
        if voice_error:
            with st.container(border=True):
                st.markdown("#### Voice-clone failed — choose next step")
                st.warning("ASHU could not use the authorized voice sample for this lecture segment. The app is paused so it does not silently fake your voice.")
                with st.expander("Show voice-clone error", expanded=False):
                    st.code(str(voice_error))
                fb_cols = st.columns(2)
                with fb_cols[0]:
                    if st.button("Use automated voice and continue", key=f"{key_prefix}_approve_auto_voice"):
                        ok2, msg2 = create_server_tts_audio(text_to_render, audio_path, voice_profile, "")
                        if ok2:
                            actual_audio = Path(msg2) if msg2 else audio_path
                            if not actual_audio.exists() and audio_path.exists():
                                actual_audio = audio_path
                            st.session_state[tts_state_key] = str(actual_audio)
                            st.session_state.pop(f"{key_prefix}_voice_generation_error", None)
                            st.success("Automated voice generated. You can now create package and start background render.")
                            safe_streamlit_audio(actual_audio)
                        else:
                            st.error("Automated voice fallback also failed: " + str(msg2))
                with fb_cols[1]:
                    if st.button("Keep stopped — I will fix my voice env/sample", key=f"{key_prefix}_keep_stopped"):
                        st.info("No fallback audio generated. Fix the voice env/sample and click Generate voice audio again.")

        current_audio_preview = Path(st.session_state.get(tts_state_key, "")) if st.session_state.get(tts_state_key) else None
        if current_audio_preview and current_audio_preview.exists():
            with st.container(border=True):
                st.markdown("#### Start teaching immediately with generated voice audio")
                st.caption("This audio can play while the real lip-sync video continues rendering in the background.")
                safe_streamlit_audio(current_audio_preview)

        bg_job = st.session_state.get(bg_job_key)
        if bg_job:
            with st.container(border=True):
                st.markdown("#### Background render status")
                running = process_is_running(int(bg_job.get("pid", 0)))
                rendered_video = output_video if output_video.exists() and output_video.stat().st_size > 1000 else latest_video_in_folder(out_dir)
                if rendered_video and rendered_video.exists():
                    st.progress(100, text="Completed: final lecture video is ready")
                elif running:
                    st.progress(78, text="Video rendering is running in background")
                else:
                    st.progress(25, text="Renderer stopped or waiting for output check")
                if rendered_video and rendered_video.exists():
                    if rendered_video != output_video:
                        try:
                            shutil.copy2(rendered_video, output_video)
                            rendered_video = output_video
                        except Exception:
                            pass
                    st.success("Background render completed. Final lecture video is ready.")
                    safe_streamlit_video(rendered_video)
                    st.session_state.last_lipsync_video = str(rendered_video)
                    with open(rendered_video, "rb") as vf:
                        st.download_button("Download final lecture video + my audio (MP4)", vf.read(), file_name=rendered_video.name, mime="video/mp4", key=f"{key_prefix}_download_final_video")
                elif running:
                    st.info(f"Renderer is still running in background. PID: {bg_job.get('pid')}. Click Refresh status after a minute.")
                    if st.button("Refresh render status", key=f"{key_prefix}_refresh_bg"):
                        st.rerun()
                else:
                    st.warning("Background renderer stopped, but no MP4 was found yet. Check the renderer log below.")
                log_path = Path(bg_job.get("log_path", ""))
                if log_path.exists():
                    try:
                        st.code(log_path.read_text(errors="ignore")[-4000:])
                    except Exception:
                        st.caption(str(log_path))

        if st.session_state.get("last_lipsync_video") and Path(st.session_state.last_lipsync_video).exists():
            with st.container(border=True):
                st.markdown("#### Latest generated lecture video")
                safe_streamlit_video(Path(st.session_state.last_lipsync_video))
                with open(Path(st.session_state.last_lipsync_video), "rb") as vf:
                    st.download_button("Download latest lecture video + audio", vf.read(), file_name=Path(st.session_state.last_lipsync_video).name, mime="video/mp4", key=f"{key_prefix}_download_latest_video")
        if st.checkbox("Show renderer manifest", value=False, key=f"{key_prefix}_show_manifest"):
            st.json(manifest)
        st.markdown("This panel generates real TTS audio and starts the production lip-sync renderer in the background. Audio can play immediately while the MP4 is rendering. Face photo routes to SadTalker; presenter video/URL routes to Wav2Lip. No fake mouth preview is used for the final video.")

# -----------------------------------------------------------------------------
# Candidate recording / proctoring panel
# -----------------------------------------------------------------------------
def candidate_recording_panel() -> None:
    st.markdown("### Candidate recording panel")
    st.markdown(
        """
<div class='info-box'><b>Candidate pipeline:</b> this is only for candidate performance/proctoring evidence. It is never used as the presenter/interviewer avatar.</div>
        """,
        unsafe_allow_html=True,
    )
    html = """
<!doctype html><html><head><style>
body{font-family:Arial,sans-serif;margin:0;background:transparent;color:#071A3D}.wrap{border:1px solid #d9e8ff;border-radius:18px;padding:18px;background:#f7fbff}.grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}.box{background:#000;border-radius:18px;min-height:280px;display:flex;align-items:center;justify-content:center;overflow:hidden}video{width:100%;height:280px;object-fit:cover}.btn{border:0;border-radius:12px;padding:11px 16px;font-weight:800;margin:5px;cursor:pointer}.primary{background:#0B5FFF;color:#fff}.danger{background:#ff4b4b;color:#fff}.secondary{background:#fff;color:#071A3D;border:1px solid #bdd5ff}.pill{display:inline-block;background:#eaf4ff;border:1px solid #cde4ff;border-radius:100px;padding:6px 10px;margin:4px}.log{height:130px;overflow:auto;background:#fff;border:1px solid #d9e8ff;border-radius:12px;padding:10px;font-size:13px}textarea{width:100%;height:115px;border:1px solid #d9e8ff;border-radius:12px;padding:10px}.small{font-size:13px;color:#607089}</style></head><body>
<div class="wrap">
 <div class="grid">
   <div><div class="box"><video id="cam" autoplay muted playsinline></video></div><div class="small">Candidate camera preview and recording source.</div></div>
   <div><div class="box"><video id="screen" autoplay muted playsinline></video></div><div class="small">Optional screen-share preview for screenshot evidence.</div></div>
 </div>
 <button class="btn primary" onclick="startRecording()">Start candidate camera + mic recording</button>
 <button class="btn secondary" onclick="startScreen()">Start optional screen share</button>
 <button class="btn secondary" onclick="manualShot()">Manual screenshot</button>
 <button class="btn danger" onclick="stopRecording()">Stop recording</button>
 <button class="btn secondary" onclick="downloadArtifacts()">Download recording + proctoring JSON</button>
 <div>
  <span class="pill">Status: <span id="status">idle</span></span>
  <span class="pill">Duration: <span id="duration">0</span>s</span>
  <span class="pill">Tab hidden: <span id="hiddenCount">0</span></span>
  <span class="pill">Blur: <span id="blurCount">0</span></span>
  <span class="pill">Screenshots: <span id="shotCount">0</span></span>
  <span class="pill">Copy/Paste/Cut: <span id="copyCount">0</span></span>
 </div>
 <p class="small"><b>Speech transcript:</b> Browser speech recognition is experimental. Typed answers in Streamlit remain official.</p>
 <textarea id="transcript" placeholder="Browser speech transcript will appear here if supported..."></textarea>
 <p class="small"><b>Event log:</b></p><div id="log" class="log"></div>
</div>
<script>
let camStream=null, screenStream=null, recorder=null, chunks=[], startTs=null, timer=null;
let events=[], screenshots=[], hiddenCount=0, blurCount=0, copyCount=0;
let recognition=null;
function log(msg){let e={time:new Date().toISOString(),event:msg}; events.push(e); document.getElementById('log').innerHTML += e.time+' - '+msg+'<br>'; document.getElementById('log').scrollTop=999999;}
function setStatus(s){document.getElementById('status').innerText=s}
function update(){ if(startTs){document.getElementById('duration').innerText=Math.floor((Date.now()-startTs)/1000)} document.getElementById('hiddenCount').innerText=hiddenCount; document.getElementById('blurCount').innerText=blurCount; document.getElementById('shotCount').innerText=screenshots.length; document.getElementById('copyCount').innerText=copyCount; }
async function startRecording(){ try{ camStream=await navigator.mediaDevices.getUserMedia({video:true,audio:true}); document.getElementById('cam').srcObject=camStream; chunks=[]; recorder=new MediaRecorder(camStream,{mimeType:'video/webm'}); recorder.ondataavailable=e=>{if(e.data.size>0)chunks.push(e.data)}; recorder.onstop=()=>{setStatus('stopped'); log('recording stopped; click Download recording + proctoring JSON');}; recorder.start(1000); startTs=Date.now(); timer=setInterval(update,500); setStatus('recording'); log('candidate camera+mic recording started'); startSpeech(); }catch(e){setStatus('camera error'); log('camera/mic error: '+e);} }
async function startScreen(){ try{ screenStream=await navigator.mediaDevices.getDisplayMedia({video:true,audio:false}); document.getElementById('screen').srcObject=screenStream; log('optional screen share started'); }catch(e){log('screen share denied/unavailable: '+e);} }
function stopRecording(){ try{ if(recorder && recorder.state!='inactive')recorder.stop(); if(timer)clearInterval(timer); if(camStream)camStream.getTracks().forEach(t=>t.stop()); if(screenStream)screenStream.getTracks().forEach(t=>t.stop()); stopSpeech(); update(); }catch(e){log('stop error '+e)} }
function captureVideo(videoId,label){ try{let v=document.getElementById(videoId); if(!v || !v.videoWidth)return; let c=document.createElement('canvas'); c.width=v.videoWidth; c.height=v.videoHeight; let ctx=c.getContext('2d'); ctx.drawImage(v,0,0,c.width,c.height); let data=c.toDataURL('image/jpeg',0.72); screenshots.push({time:new Date().toISOString(),label:label,data_url:data}); log('screenshot captured: '+label);}catch(e){log('screenshot failed '+e)} update(); }
function manualShot(){ captureVideo('cam','manual_webcam'); captureVideo('screen','manual_screen'); }
document.addEventListener('visibilitychange',()=>{ if(document.hidden){hiddenCount++; log('tab hidden / switched'); captureVideo('cam','tab_hidden_webcam'); captureVideo('screen','tab_hidden_screen'); update();} });
window.addEventListener('blur',()=>{blurCount++; log('window blur'); captureVideo('cam','window_blur_webcam'); update();});
['copy','paste','cut'].forEach(ev=>document.addEventListener(ev,()=>{copyCount++; log(ev+' event'); update();}));
function startSpeech(){ try{ let SR=window.SpeechRecognition||window.webkitSpeechRecognition; if(!SR){log('speech recognition unsupported');return;} recognition=new SR(); recognition.continuous=true; recognition.interimResults=true; recognition.lang='en-US'; recognition.onresult=(event)=>{let txt=''; for(let i=0;i<event.results.length;i++){txt+=event.results[i][0].transcript+' ';} document.getElementById('transcript').value=txt;}; recognition.onerror=e=>log('speech recognition error '+e.error); recognition.start(); log('speech transcript helper started'); }catch(e){log('speech recognition start failed '+e)} }
function stopSpeech(){try{if(recognition)recognition.stop()}catch(e){}}
function downloadArtifacts(){ try{ let blob=new Blob(chunks,{type:'video/webm'}); let videoName='candidate_face_to_face_recording_'+new Date().toISOString().replace(/[:.]/g,'-')+'.webm'; let a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download=videoName; a.click(); let payload={created_at:new Date().toISOString(),duration_seconds:document.getElementById('duration').innerText,events:events,screenshots:screenshots,transcript:document.getElementById('transcript').value,counts:{tab_hidden:hiddenCount,window_blur:blurCount,copy_paste_cut:copyCount,screenshots:screenshots.length}}; let jb=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'}); let j=document.createElement('a'); j.href=URL.createObjectURL(jb); j.download='candidate_proctoring_artifacts_'+new Date().toISOString().replace(/[:.]/g,'-')+'.json'; j.click(); log('download triggered for recording and proctoring JSON'); }catch(e){log('download failed '+e)} }
</script>
</body></html>
"""
    st.components.v1.html(html, height=840, scrolling=True)
    with st.expander("Advanced: attach browser-recorded evidence to final ZIP", expanded=False):
        st.caption(
            "Only use this if you want the browser-recorded video and proctoring JSON inside the downloadable report bundle. "
            "Streamlit cannot directly read a browser MediaRecorder blob, so the browser downloads the files first; uploading them here re-attaches them to the final ZIP."
        )
        col1, col2 = st.columns(2)
        with col1:
            rec = st.file_uploader(
                "Attach candidate recording file (.webm/.mp4)",
                type=["webm", "mp4"],
                key="candidate_recording_upload",
            )
            if rec:
                pobj = save_uploaded_file(rec, RECORDINGS_DIR)
                st.session_state.candidate_artifacts["candidate_face_to_face_recording"] = str(pobj)
                st.success(f"Candidate recording attached: {pobj.name}")
        with col2:
            ev = st.file_uploader(
                "Attach proctoring evidence JSON",
                type=["json"],
                key="candidate_proctor_json_upload",
            )
            if ev:
                pobj = save_uploaded_file(ev, PROCTOR_DIR)
                st.session_state.candidate_artifacts["candidate_proctoring_json"] = str(pobj)
                try:
                    data = json.loads(pobj.read_text(encoding="utf-8"))
                    st.session_state.candidate_proctor_events = data.get("events", [])
                    shots_dir = PROCTOR_DIR / f"tab_switch_screenshots_{now_id()}"
                    shots_dir.mkdir(exist_ok=True)
                    shot_files = []
                    for idx, shot in enumerate(data.get("screenshots", []), 1):
                        data_url = shot.get("data_url", "")
                        if "," in data_url:
                            raw = base64.b64decode(data_url.split(",", 1)[1])
                            img_path = shots_dir / f"screenshot_{idx:03d}_{safe_filename(shot.get('label','event'))}.jpg"
                            img_path.write_bytes(raw)
                            shot_files.append(str(img_path))
                    st.session_state.candidate_artifacts["tab_switch_screenshots_dir"] = str(shots_dir)
                    st.session_state.candidate_artifacts["tab_switch_screenshot_files"] = shot_files
                    st.session_state.candidate_artifacts["candidate_browser_transcript"] = data.get("transcript", "")
                    st.success(f"Proctoring evidence attached. Screenshots extracted: {len(shot_files)}")
                except Exception as exc:
                    st.warning(f"JSON saved but could not parse screenshots: {exc}")


# -----------------------------------------------------------------------------
# Live human-led session recording panel
# -----------------------------------------------------------------------------
def live_human_session_panel() -> None:
    st.markdown("### Live Human-Led Training / Interview Capture")
    st.markdown(
        """
<div class='info-box'><b>Purpose:</b> Use this when a real trainer/interviewer wants to conduct a live class or interview. The session is recorded for demo, audit, reuse, and training showcase material. This is different from AI avatar delivery and candidate proctoring.</div>
        """,
        unsafe_allow_html=True,
    )
    col1, col2 = st.columns([1, 1])
    with col1:
        session_type = st.selectbox("Live session type", ["Human-led training", "Human-led interview", "Human-led mentoring / doubt clearing"], key="live_session_type")
        session_title = st.text_input("Session title", value=st.session_state.live_session_artifacts.get("session_title", "Live REST API Security Training"), key="live_session_title")
        trainer_name = st.text_input("Trainer / interviewer name", value=st.session_state.live_session_artifacts.get("trainer_name", "Trainer"), key="live_trainer_name")
    with col2:
        target_audience = st.text_input("Participants / candidate / batch", value=st.session_state.live_session_artifacts.get("participants", "Candidate / learner batch"), key="live_participants")
        session_topic = st.text_input("Topic / interview focus", value=st.session_state.live_session_artifacts.get("topic", st.session_state.get("selected_training_topic", "")), key="live_session_topic")
        allow_reuse = st.checkbox("I confirm this live session can be recorded and reused for demo/training evidence", value=True, key="live_session_reuse_consent")

    st.session_state.live_session_artifacts.update({
        "session_type": session_type,
        "session_title": session_title,
        "trainer_name": trainer_name,
        "participants": target_audience,
        "topic": session_topic,
        "reuse_consent": allow_reuse,
        "created_at": dt.datetime.now().isoformat(timespec="seconds"),
    })

    if not allow_reuse:
        st.warning("Recording reuse consent is required before recording a live human-led session.")
        return

    html = """
<!doctype html><html><head><style>
body{font-family:Arial,sans-serif;margin:0;background:transparent;color:#071A3D}.wrap{border:1px solid #d9e8ff;border-radius:18px;padding:18px;background:#f7fbff}.grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}.box{background:#000;border-radius:18px;min-height:300px;display:flex;align-items:center;justify-content:center;overflow:hidden}video{width:100%;height:300px;object-fit:cover}.btn{border:0;border-radius:12px;padding:11px 16px;font-weight:800;margin:5px;cursor:pointer}.primary{background:#0B5FFF;color:#fff}.danger{background:#ff4b4b;color:#fff}.success{background:#0bbf70;color:#fff}.secondary{background:#fff;color:#071A3D;border:1px solid #bdd5ff}.pill{display:inline-block;background:#eaf4ff;border:1px solid #cde4ff;border-radius:100px;padding:6px 10px;margin:4px}.log{height:130px;overflow:auto;background:#fff;border:1px solid #d9e8ff;border-radius:12px;padding:10px;font-size:13px}textarea{width:100%;height:115px;border:1px solid #d9e8ff;border-radius:12px;padding:10px}.small{font-size:13px;color:#607089}.title{font-size:18px;font-weight:800;margin-bottom:8px}</style></head><body>
<div class="wrap">
 <div class="title">Live Human Session Recorder</div>
 <div class="grid">
   <div><div class="box"><video id="cam" autoplay muted playsinline></video></div><div class="small">Trainer/interviewer/candidate camera recording source.</div></div>
   <div><div class="box"><video id="screen" autoplay muted playsinline></video></div><div class="small">Optional screen/presentation recording source.</div></div>
 </div>
 <button class="btn primary" onclick="startCameraRecording()">Start camera + mic recording</button>
 <button class="btn secondary" onclick="startScreen()">Add screen / PPT share</button>
 <button class="btn success" onclick="markMoment('important_moment')">Mark important moment</button>
 <button class="btn secondary" onclick="manualShot()">Screenshot</button>
 <button class="btn danger" onclick="stopRecording()">Stop session</button>
 <button class="btn secondary" onclick="downloadArtifacts()">Download live session recording + notes JSON</button>
 <div>
  <span class="pill">Status: <span id="status">idle</span></span>
  <span class="pill">Duration: <span id="duration">0</span>s</span>
  <span class="pill">Moments: <span id="momentCount">0</span></span>
  <span class="pill">Screenshots: <span id="shotCount">0</span></span>
  <span class="pill">Tab hidden: <span id="hiddenCount">0</span></span>
 </div>
 <p class="small"><b>Live transcript helper:</b> Browser speech recognition is experimental. It creates a rough searchable transcript for the session.</p>
 <textarea id="transcript" placeholder="Live transcript appears here if Chrome speech recognition is supported..."></textarea>
 <p class="small"><b>Session notes / marked events:</b></p><div id="log" class="log"></div>
</div>
<script>
let camStream=null, screenStream=null, recorder=null, chunks=[], startTs=null, timer=null;
let events=[], screenshots=[], hiddenCount=0, moments=0, recognition=null;
function log(msg){let e={time:new Date().toISOString(),event:msg}; events.push(e); document.getElementById('log').innerHTML += e.time+' - '+msg+'<br>'; document.getElementById('log').scrollTop=999999;}
function setStatus(s){document.getElementById('status').innerText=s}
function update(){ if(startTs){document.getElementById('duration').innerText=Math.floor((Date.now()-startTs)/1000)} document.getElementById('hiddenCount').innerText=hiddenCount; document.getElementById('shotCount').innerText=screenshots.length; document.getElementById('momentCount').innerText=moments; }
async function startCameraRecording(){ try{ camStream=await navigator.mediaDevices.getUserMedia({video:true,audio:true}); document.getElementById('cam').srcObject=camStream; chunks=[]; recorder=new MediaRecorder(camStream,{mimeType:'video/webm'}); recorder.ondataavailable=e=>{if(e.data.size>0)chunks.push(e.data)}; recorder.onstop=()=>{setStatus('stopped'); log('live session recording stopped; click download artifacts');}; recorder.start(1000); startTs=Date.now(); timer=setInterval(update,500); setStatus('recording'); log('live human-led session camera+mic recording started'); startSpeech(); }catch(e){setStatus('camera error'); log('camera/mic error: '+e);} }
async function startScreen(){ try{ screenStream=await navigator.mediaDevices.getDisplayMedia({video:true,audio:true}); document.getElementById('screen').srcObject=screenStream; log('screen/PPT share started'); }catch(e){log('screen share denied/unavailable: '+e);} }
function stopRecording(){ try{ if(recorder && recorder.state!='inactive')recorder.stop(); if(timer)clearInterval(timer); if(camStream)camStream.getTracks().forEach(t=>t.stop()); if(screenStream)screenStream.getTracks().forEach(t=>t.stop()); stopSpeech(); update(); }catch(e){log('stop error '+e)} }
function captureVideo(videoId,label){ try{let v=document.getElementById(videoId); if(!v || !v.videoWidth)return; let c=document.createElement('canvas'); c.width=v.videoWidth; c.height=v.videoHeight; let ctx=c.getContext('2d'); ctx.drawImage(v,0,0,c.width,c.height); let data=c.toDataURL('image/jpeg',0.76); screenshots.push({time:new Date().toISOString(),label:label,data_url:data}); log('screenshot captured: '+label);}catch(e){log('screenshot failed '+e)} update(); }
function manualShot(){ captureVideo('cam','manual_camera'); captureVideo('screen','manual_screen'); }
function markMoment(label){ moments++; log('marked moment: '+label); captureVideo('cam','moment_camera_'+moments); captureVideo('screen','moment_screen_'+moments); update(); }
document.addEventListener('visibilitychange',()=>{ if(document.hidden){hiddenCount++; log('tab hidden during live session'); captureVideo('cam','live_tab_hidden_camera'); captureVideo('screen','live_tab_hidden_screen'); update();} });
function startSpeech(){ try{ let SR=window.SpeechRecognition||window.webkitSpeechRecognition; if(!SR){log('speech recognition unsupported');return;} recognition=new SR(); recognition.continuous=true; recognition.interimResults=true; recognition.lang='en-US'; recognition.onresult=(event)=>{let txt=''; for(let i=0;i<event.results.length;i++){txt+=event.results[i][0].transcript+' ';} document.getElementById('transcript').value=txt;}; recognition.onerror=e=>log('speech recognition error '+e.error); recognition.start(); log('live transcript helper started'); }catch(e){log('speech recognition start failed '+e)} }
function stopSpeech(){try{if(recognition)recognition.stop()}catch(e){}}
function downloadArtifacts(){ try{ let blob=new Blob(chunks,{type:'video/webm'}); let videoName='live_human_session_recording_'+new Date().toISOString().replace(/[:.]/g,'-')+'.webm'; let a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download=videoName; a.click(); let payload={created_at:new Date().toISOString(),duration_seconds:document.getElementById('duration').innerText,events:events,screenshots:screenshots,transcript:document.getElementById('transcript').value,counts:{tab_hidden:hiddenCount,moments:moments,screenshots:screenshots.length}}; let jb=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'}); let j=document.createElement('a'); j.href=URL.createObjectURL(jb); j.download='live_human_session_artifacts_'+new Date().toISOString().replace(/[:.]/g,'-')+'.json'; j.click(); log('download triggered for live session recording and JSON'); }catch(e){log('download failed '+e)} }
</script></body></html>
"""
    st.components.v1.html(html, height=875, scrolling=True)

    with st.expander("Advanced: attach live human-led session evidence to final ZIP", expanded=False):
        st.caption("After downloading the browser recording/JSON, attach them here so ASHU can include them in the final report bundle for later demo, audit, or training showcase use.")
        c1, c2 = st.columns(2)
        with c1:
            rec = st.file_uploader("Attach live session recording (.webm/.mp4)", type=["webm", "mp4"], key="live_session_recording_upload")
            if rec:
                pobj = save_uploaded_file(rec, RECORDINGS_DIR)
                st.session_state.live_session_artifacts["live_session_recording"] = str(pobj)
                st.success(f"Live session recording attached: {pobj.name}")
        with c2:
            ev = st.file_uploader("Attach live session notes/proctoring JSON", type=["json"], key="live_session_json_upload")
            if ev:
                pobj = save_uploaded_file(ev, PROCTOR_DIR)
                st.session_state.live_session_artifacts["live_session_json"] = str(pobj)
                try:
                    data = json.loads(pobj.read_text(encoding="utf-8"))
                    st.session_state.live_session_artifacts["live_session_transcript"] = data.get("transcript", "")
                    shots_dir = PROCTOR_DIR / f"live_session_screenshots_{now_id()}"
                    shots_dir.mkdir(exist_ok=True)
                    shot_files = []
                    for idx, shot in enumerate(data.get("screenshots", []), 1):
                        data_url = shot.get("data_url", "")
                        if "," in data_url:
                            raw = base64.b64decode(data_url.split(",", 1)[1])
                            img_path = shots_dir / f"live_session_screenshot_{idx:03d}_{safe_filename(shot.get('label','event'))}.jpg"
                            img_path.write_bytes(raw)
                            shot_files.append(str(img_path))
                    st.session_state.live_session_artifacts["live_session_screenshot_files"] = shot_files
                    st.success(f"Live session evidence attached. Screenshots extracted: {len(shot_files)}")
                except Exception as exc:
                    st.warning(f"JSON saved but could not parse screenshots: {exc}")
        st.json(st.session_state.live_session_artifacts)

# -----------------------------------------------------------------------------
# Report bundle
# -----------------------------------------------------------------------------
def flatten_score_rows() -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for round_name, hist in [
        ("resume_interview", st.session_state.resume_history),
        ("face_to_face", st.session_state.face_history),
        ("coding", st.session_state.coding_history),
    ]:
        for i, item in enumerate(hist, 1):
            evaluation = item.get("evaluation", {})
            rubric = evaluation.get("rubric", {}) if isinstance(evaluation, dict) else {}
            row = {
                "round": round_name,
                "question_no": i,
                "question": item.get("question"),
                "answer": item.get("answer") or item.get("code") or "",
                "overall_score": evaluation.get("overall_score") if isinstance(evaluation, dict) else None,
                "score_band": evaluation.get("score_band") if isinstance(evaluation, dict) else None,
            }
            row.update({f"rubric_{k}": v for k, v in rubric.items()})
            rows.append(row)
    return rows


def build_final_report() -> str:
    rows = flatten_score_rows()
    avg = round(sum(r.get("overall_score") or 0 for r in rows) / len(rows), 2) if rows else 0
    transcript = st.session_state.candidate_artifacts.get("candidate_browser_transcript", "")
    lines = [
        "# ASHU Mentor AI Candidate Final Report",
        "",
        f"Generated: {dt.datetime.now().isoformat(timespec='seconds')}",
        f"Role: {st.session_state.role_title}",
        f"Presenter: {st.session_state.presenter_profile.get('display_name')}",
        f"Overall average score: {avg}/100",
        "",
        "## Pipeline Separation",
        "- Candidate video/photo/camera is used only for candidate performance, transcript, and proctoring evidence.",
        "- Presenter photo/video/URL is used only as the authorized interviewer/trainer avatar source.",
        "- Live human-led session recording is used only when a real trainer/interviewer conducts an actual class or interview and wants reusable evidence.",
        "",
        "## Candidate Artifacts",
        f"- Recording attached: {bool(st.session_state.candidate_artifacts.get('candidate_face_to_face_recording'))}",
        f"- Proctoring JSON attached: {bool(st.session_state.candidate_artifacts.get('candidate_proctoring_json'))}",
        f"- Tab-switch screenshots: {len(st.session_state.candidate_artifacts.get('tab_switch_screenshot_files', []))}",
        "",
        "## Digital Presenter Profile",
        "```json",
        json_dumps(st.session_state.presenter_profile),
        "```",
        "",
        "## Score Summary",
    ]
    for r in rows:
        lines += [
            f"### {r['round']} Q{r['question_no']} — {r.get('overall_score')}/100",
            f"**Question:** {r.get('question')}",
            f"**Answer/Code:** {str(r.get('answer',''))[:1200]}",
            "",
        ]
    if transcript:
        lines += ["## Browser Speech Transcript", transcript[:8000], ""]
    if st.session_state.adaptive_recommendations:
        lines += ["## Recommended Learning Topics"]
        for rec in st.session_state.adaptive_recommendations:
            lines.append(f"- {rec.get('topic')} — {rec.get('reason')}")
    lines += [
        "## Human Review Notice",
        "ASHU provides assessment and proctoring indicators only. It must not be used as sole basis for hiring, rejection, cheating accusation, or identity decision.",
    ]
    return "\n".join(lines)


def make_report_bundle() -> Path:
    bundle_id = now_id()
    out_zip = REPORT_DIR / f"complete_candidate_report_bundle_{bundle_id}.zip"
    report_md = build_final_report()
    rows = flatten_score_rows()
    score_csv = io.StringIO()
    if rows:
        writer = csv.DictWriter(score_csv, fieldnames=sorted({k for r in rows for k in r.keys()}))
        writer.writeheader()
        writer.writerows(rows)
    audit = {
        "created_at": dt.datetime.now().isoformat(),
        "candidate_pipeline": st.session_state.candidate_artifacts,
        "presenter_avatar_pipeline": st.session_state.presenter_profile,
        "resume_interview_count": len(st.session_state.resume_history),
        "face_to_face_count": len(st.session_state.face_history),
        "coding_count": len(st.session_state.coding_history),
        "adaptive_recommendations": st.session_state.adaptive_recommendations,
        "lipsync_renderer_artifacts": st.session_state.lipsync_artifacts,
        "last_lipsync_video": st.session_state.last_lipsync_video,
        "live_human_session": st.session_state.live_session_artifacts,
        "human_review_required": True,
    }
    with zipfile.ZipFile(out_zip, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("candidate_final_report.md", report_md)
        z.writestr("candidate_scorecard_all_values.csv", score_csv.getvalue())
        z.writestr("candidate_interview_transcript.txt", st.session_state.candidate_artifacts.get("candidate_browser_transcript", ""))
        z.writestr("candidate_audit_evidence.json", json_dumps(audit))
        z.writestr("candidate_coding_round.json", json_dumps(st.session_state.coding_history))
        z.writestr("presenter_avatar_profile.json", json_dumps(st.session_state.presenter_profile))
        z.writestr("training_content.json", json_dumps(st.session_state.training_content))
        if st.session_state.training_content:
            z.writestr("training_notes.md", training_notes_markdown(st.session_state.training_content, st.session_state.get("selected_training_topic", "")))
            z.writestr("training_notes.pdf", training_notes_pdf_bytes(st.session_state.training_content, st.session_state.get("selected_training_topic", "")))
        z.writestr("adaptive_learning_recommendations.json", json_dumps(st.session_state.adaptive_recommendations))
        z.writestr("live_human_session_metadata.json", json_dumps(st.session_state.live_session_artifacts))
        live_transcript = st.session_state.live_session_artifacts.get("live_session_transcript", "")
        if live_transcript:
            z.writestr("live_human_session_transcript.txt", live_transcript)
        z.writestr("lipsync_renderer_artifacts.json", json_dumps(st.session_state.lipsync_artifacts))
        last_lip = st.session_state.get("last_lipsync_video", "")
        if last_lip and Path(last_lip).exists():
            z.write(last_lip, "rendered_talking_presenter_video" + Path(last_lip).suffix)
        # Attach renderer package directories if small/local manifests exist
        for mf in st.session_state.lipsync_artifacts:
            out_dir = Path((mf.get("outputs") or {}).get("output_directory", ""))
            if out_dir.exists():
                for fp in out_dir.glob("*"):
                    if fp.is_file() and fp.stat().st_size < 50 * 1024 * 1024:
                        z.write(fp, f"lipsync_renderer_packages/{out_dir.name}/{fp.name}")
        # Attach candidate video + proctoring JSON/screenshots
        rec_path = st.session_state.candidate_artifacts.get("candidate_face_to_face_recording")
        if rec_path and Path(rec_path).exists():
            z.write(rec_path, "candidate_face_to_face_recording" + Path(rec_path).suffix)
        ev_path = st.session_state.candidate_artifacts.get("candidate_proctoring_json")
        if ev_path and Path(ev_path).exists():
            z.write(ev_path, "proctoring_events.json")
        for shot in st.session_state.candidate_artifacts.get("tab_switch_screenshot_files", []):
            if Path(shot).exists():
                z.write(shot, f"tab_switch_screenshots/{Path(shot).name}")
        # Attach live human-led trainer/interviewer session evidence
        live_rec = st.session_state.live_session_artifacts.get("live_session_recording")
        if live_rec and Path(live_rec).exists():
            z.write(live_rec, "live_human_session/live_session_recording" + Path(live_rec).suffix)
        live_json = st.session_state.live_session_artifacts.get("live_session_json")
        if live_json and Path(live_json).exists():
            z.write(live_json, "live_human_session/live_session_artifacts.json")
        for shot in st.session_state.live_session_artifacts.get("live_session_screenshot_files", []):
            if Path(shot).exists():
                z.write(shot, f"live_human_session/screenshots/{Path(shot).name}")
        # Attach presenter source if local
        ps = st.session_state.presenter_profile.get("source_path")
        if ps and Path(ps).exists():
            z.write(ps, f"presenter_source/{Path(ps).name}")
    return out_zip

# -----------------------------------------------------------------------------
# UI: sidebar / header
# -----------------------------------------------------------------------------
with st.sidebar:
    if LOGO_SVG.exists():
        st.image(str(LOGO_SVG), use_container_width=True)

    # Keep the sidebar clean during demos. Detailed runtime and consent controls are
    # available, but collapsed by default once the system is ready.
    model_name = "qwen2.5:7b"
    auto_start = True
    auto_pull = True
    global_consent = True
    candidate_consent = True
    presenter_consent_default = True

    if auto_start:
        start_ollama_if_possible()
    ollama_status = check_ollama(model_name)
    st.session_state.ollama_ready = bool(ollama_status["server"] and ollama_status["model_present"])
    if ollama_status["server"] and not ollama_status["model_present"] and auto_pull:
        pull_model_if_possible(model_name)

    if not st.session_state.get("renderer_health"):
        st.session_state.renderer_health = check_lipsync_renderers(st.session_state.get("sadtalker_repo_path", ""), st.session_state.get("wav2lip_repo_path", ""))
    sad_ready = bool(st.session_state.renderer_health.get("SadTalker", {}).get("ready"))
    wav_ready = bool(st.session_state.renderer_health.get("Wav2Lip", {}).get("ready"))

    sidebar_training_hub()

    with st.expander("Advanced runtime, renderer & consent settings", expanded=False):
        model_name = st.text_input("Local Ollama model", value=model_name)
        auto_start = st.checkbox("Auto-start Ollama if installed", value=True)
        auto_pull = st.checkbox("Auto-pull model if missing", value=True)
        st.json({"server": ollama_status.get("server"), "model_present": ollama_status.get("model_present"), "model": model_name})
        if st.button("Refresh lip-sync renderer checks", key="sidebar_refresh_renderers"):
            st.session_state.renderer_health = check_lipsync_renderers(st.session_state.get("sadtalker_repo_path", ""), st.session_state.get("wav2lip_repo_path", ""))
        st.json({
            "SadTalker_ready": st.session_state.renderer_health.get("SadTalker", {}).get("ready"),
            "Wav2Lip_ready": st.session_state.renderer_health.get("Wav2Lip", {}).get("ready"),
        })
        global_consent = st.checkbox("I understand recording/avatar workflows require consent", value=True)
        candidate_consent = st.checkbox("Candidate recording consent", value=True)
        presenter_consent_default = st.checkbox("Presenter avatar authorization confirmed", value=True)
        st.caption("For production, keep explicit candidate and presenter release forms.")

    st.markdown("---")
    st.markdown("### System status")
    if st.session_state.ollama_ready:
        st.success("Local LLM ready")
    elif ollama_status["server"]:
        st.info("Ollama running; model pull may still be in progress")
    else:
        st.warning("Local LLM offline; fallback mode active")

    if sad_ready and wav_ready:
        st.success("Lip-sync renderers ready")
    elif sad_ready or wav_ready:
        st.info("One lip-sync renderer ready")
    else:
        st.warning("Lip-sync renderers need setup")

st.markdown(
    """
<div class='hero'>
  <h1>ASHU Mentor AI Studio</h1>
  <h3>AI-Powered Interview, Evaluation & Adaptive Training Platform</h3>
  <p>JD-aware and resume-aware interviews, candidate insight capture, digital presenter avatars, coding evaluation, and domain-specific adaptive training in one intelligent workflow.</p>
</div>
""",
    unsafe_allow_html=True,
)
st.write("")

if not global_consent:
    st.error("Please confirm consent before using recording/avatar workflows.")

# -----------------------------------------------------------------------------
# Tabs
# -----------------------------------------------------------------------------
tabs = st.tabs([
    "0. Candidate Insight",
    "1. Digital Presenter",
    "2. Resume & Role",
    "3. 40Q / Unlimited Interview",
    "4. Face-to-Face Round",
    "5. Coding Round",
    "6. Adaptive Training",
    "7. Live Session Capture",
    "8. Evaluation Report",
    "9. Technical Architecture",
])

# -----------------------------------------------------------------------------
# Tab 0: Candidate Recording
# -----------------------------------------------------------------------------
with tabs[0]:
    st.header("Candidate Insight & Capture")
    if candidate_consent:
        candidate_recording_panel()
    else:
        st.warning("Candidate recording consent is required for this panel.")

    st.markdown("---")
    with st.expander("Candidate Performance & Integrity Capture purpose", expanded=False):
        st.markdown(
            """
<div class='warn-box'><b>Purpose:</b> This camera, microphone, and screen evidence are used for candidate performance review, transcript support, focus-change events, screenshots, and audit evidence. This capture stream stays separate from the digital presenter.</div>
            """,
            unsafe_allow_html=True,
        )

# -----------------------------------------------------------------------------
# Tab 1: Presenter Avatar Setup
# -----------------------------------------------------------------------------
with tabs[1]:
    st.header("Digital Presenter Studio")
    st.markdown(
        """
<div class='info-box'><b>Digital Presenter Studio:</b> Configure the authorized digital presenter who will deliver interview questions and training. ASHU extracts presenter portraits, visual style, readiness signals, and multi-presenter cues from approved photo/video/URL sources.</div>
        """,
        unsafe_allow_html=True,
    )
    with st.expander("Local lip-sync runtime check", expanded=False):
        lipsync_runtime_health_panel()

    col_a, col_b = st.columns([1.1, 0.9], gap="large")
    with col_a:
        source_mode = st.radio(
            "Who should appear as interviewer/trainer?",
            ["Use built-in ASHU synthetic presenter", "Upload authorized presenter photo", "Upload authorized presenter video", "Use authorized YouTube/direct video URL"],
            index=0,
        )
        display_name = st.text_input("Presenter display name", value=st.session_state.presenter_profile.get("display_name", "ASHU Synthetic Presenter"))
        release_id = st.text_input("Consent reference / release ID", value=st.session_state.presenter_profile.get("release_id", "BUILT-IN-SYNTHETIC"))
        presenter_role = st.multiselect("Presenter role", ["Interviewer", "Trainer"], default=["Interviewer", "Trainer"])
        presenter_consent = st.checkbox("I have written authorization to use this presenter's face/video/voice for AI interviewer/trainer avatar generation.", value=presenter_consent_default)
        source_path: Optional[Path] = None
        features: Dict[str, Any] = {}
        source_meta: Dict[str, Any] = {"source_mode": source_mode}
        if source_mode == "Upload authorized presenter photo":
            up = st.file_uploader("Upload authorized presenter face photo", type=["png", "jpg", "jpeg"], key="presenter_photo")
            if up and st.button("Analyze presenter photo"):
                source_path = save_uploaded_file(up, PRESENTER_DIR)
                features = analyze_photo(source_path)
                st.session_state.presenter_profile = {
                    "source_type": "photo",
                    "display_name": display_name,
                    "consent_confirmed": presenter_consent,
                    "release_id": release_id,
                    "presenter_role": presenter_role,
                    "source_path": str(source_path),
                    "features": features,
                    "source_metadata": source_meta,
                }
                st.success("Presenter photo analyzed and selected.")
        elif source_mode == "Upload authorized presenter video":
            up = st.file_uploader("Upload authorized presenter video", type=["mp4", "mov", "webm", "mkv", "avi", "mpeg", "mpg"], key="presenter_video")
            if up and st.button("Analyze presenter video"):
                source_path = save_uploaded_file(up, PRESENTER_DIR)
                features = analyze_video(source_path)
                st.session_state.presenter_profile = {
                    "source_type": "video",
                    "display_name": display_name,
                    "consent_confirmed": presenter_consent,
                    "release_id": release_id,
                    "presenter_role": presenter_role,
                    "source_path": str(source_path),
                    "features": features,
                    "source_metadata": source_meta,
                }
                st.success("Presenter video analyzed and selected.")
        elif source_mode == "Use authorized YouTube/direct video URL":
            url = st.text_input("Authorized presenter video URL")
            max_mb = st.slider("Max download size MB", 50, 500, 200)
            if st.button("Download and analyze authorized presenter URL"):
                if not presenter_consent:
                    st.error("Authorization consent is required before downloading/using a person as presenter avatar.")
                elif not url:
                    st.error("Enter a URL first.")
                else:
                    with st.spinner("Downloading authorized presenter video..."):
                        source_path, meta = download_presenter_url(url, max_mb=max_mb)
                    if source_path:
                        features = analyze_video(source_path)
                        st.session_state.presenter_profile = {
                            "source_type": "url_video",
                            "display_name": display_name,
                            "consent_confirmed": presenter_consent,
                            "release_id": release_id,
                            "presenter_role": presenter_role,
                            "source_path": str(source_path),
                            "features": features,
                            "source_metadata": meta,
                        }
                        st.success("Authorized presenter URL downloaded, analyzed, and selected.")
                    else:
                        st.error(f"URL download failed: {meta}")
        else:
            if st.button("Use built-in ASHU presenter"):
                st.session_state.presenter_profile = {
                    "source_type": "built_in",
                    "display_name": display_name or "ASHU Synthetic Presenter",
                    "consent_confirmed": True,
                    "release_id": "BUILT-IN-SYNTHETIC",
                    "presenter_role": presenter_role or ["Interviewer", "Trainer"],
                    "source_path": str(DEFAULT_PRESENTER_SVG),
                    "features": {"readiness_score": 100, "note": "Built-in synthetic presenter."},
                    "source_metadata": {"source_mode": source_mode},
                }
                st.success("Built-in ASHU synthetic presenter selected.")
    with col_b:
        st.subheader("Current presenter persona")
        prof = st.session_state.presenter_profile
        source_path = Path(prof.get("source_path", "")) if prof.get("source_path") else None
        personas = get_presenter_personas(prof)
        if len(personas) > 1:
            st.success(f"{len(personas)} presenters detected. ASHU will alternate them during interview/training.")
        cols = st.columns(min(2, max(1, len(personas))))
        for i, person in enumerate(personas[:2]):
            with cols[i % len(cols)]:
                pp = Path(person.get("portrait_path", "")) if person.get("portrait_path") else presenter_portrait_path(prof, i)
                if pp.exists():
                    st.image(str(pp), width=220, caption=f"{person.get('display_name','Presenter')} · {person.get('voice_profile','neutral')} voice")
                voice_options = ["female", "male", "neutral"]
                current_voice = person.get("voice_profile", _voice_profile_for_index(i))
                try:
                    default_idx = voice_options.index(current_voice)
                except ValueError:
                    default_idx = 2
                new_voice = st.selectbox(f"Voice profile for presenter {i+1}", voice_options, index=default_idx, key=f"voice_profile_{i}")
                if "presenter_personas" in st.session_state.presenter_profile.get("features", {}):
                    st.session_state.presenter_profile["features"]["presenter_personas"][i]["voice_profile"] = new_voice
        if source_path and source_path.exists() and source_path.suffix.lower() in [".mp4", ".webm", ".mov", ".mkv", ".avi"]:
            st.caption(f"Reference video saved for audit/features only: {source_path.name}. ASHU uses extracted persona features, not raw replay.")
        with st.expander("Advanced presenter feature profile", expanded=False):
            st.json(prof)

# -----------------------------------------------------------------------------
# Tab 2: Resume & Role
# -----------------------------------------------------------------------------
with tabs[2]:
    st.header("Resume, Role & Optional JD Domain Setup")
    st.markdown(
        "Upload the candidate resume and optionally paste/upload a **Job Description (JD)**. "
        "When a JD is provided, ASHU generates interview, coding, and training content from **Resume + JD/domain fit**."
    )
    col1, col2 = st.columns([0.95, 1.05])
    with col1:
        resume = st.file_uploader("Upload candidate resume", type=["pdf", "docx", "txt"], key="resume_upload")
        role = st.text_input("Target role", value=st.session_state.role_title)
        st.markdown("#### Optional JD / domain focus")
        jd_file = st.file_uploader("Upload JD file", type=["pdf", "docx", "txt"], key="jd_upload")
        jd_file_text = extract_resume_text(jd_file) if jd_file else ""
        jd_default = jd_file_text if jd_file_text else st.session_state.job_description
        jd = st.text_area(
            "Paste JD or interview domain focus",
            value=jd_default,
            height=180,
            placeholder="Optional. Example: Backend Developer role requiring Java, Spring Boot, REST APIs, JWT, MySQL, Docker, CI/CD, cloud deployment...",
        )
        basis = "Resume + JD/domain" if jd.strip() else "Resume-only"
        st.info(f"Interview basis: **{basis}**")
        if st.button("Extract resume + JD profile", type="primary"):
            text = extract_resume_text(resume) if resume else ""
            st.session_state.resume_text = text
            st.session_state.role_title = role
            st.session_state.job_description = jd
            st.session_state.interview_basis = basis
            st.session_state.jd_profile = extract_jd_profile(jd, role, model_name) if jd.strip() else {}
            prompt = f"""
Return ONLY valid JSON. Extract a concise candidate profile from resume and map it against the optional JD/domain.
Role: {role}
Interview basis: {basis}
JD/domain profile: {json_dumps(st.session_state.jd_profile)[:3000]}
JD/domain text: {jd[:4000]}
Resume: {text[:7000]}
Schema: {{
 "candidate_name":"",
 "skills":[],
 "projects":[],
 "experience_summary":"",
 "resume_strengths_for_jd":[],
 "resume_jd_gaps":[],
 "possible_weak_areas":[],
 "question_focus":[],
 "recommended_training_domains":[]
}}
""".strip()
            raw = ollama_generate(prompt, model=model_name, temperature=0.1)
            parsed = try_parse_json(raw)
            if not isinstance(parsed, dict):
                toks = list(dict.fromkeys(tokenize(text + " " + jd)))[:80]
                parsed = {"candidate_name": "Candidate", "skills": toks[:25], "projects": [], "experience_summary": text[:1000], "resume_strengths_for_jd": [], "resume_jd_gaps": toks[25:40], "possible_weak_areas": [], "question_focus": toks[:15], "recommended_training_domains": toks[:10], "llm_fallback_used": True}
            st.session_state.candidate_profile = parsed
            st.success("Resume + JD/domain profile ready.")
    with col2:
        st.subheader("Interview targeting profile")
        st.json(jd_match_summary())
        st.subheader("Parsed candidate profile")
        st.json(st.session_state.candidate_profile)
        if st.session_state.jd_profile:
            with st.expander("JD/domain profile", expanded=False):
                st.json(st.session_state.jd_profile)
        with st.expander("Resume text excerpt", expanded=False):
            st.write(st.session_state.resume_text[:5000])
        if st.session_state.job_description:
            with st.expander("JD/domain text excerpt", expanded=False):
                st.write(st.session_state.job_description[:5000])

# -----------------------------------------------------------------------------
# Tab 3: Resume-aware interview
# -----------------------------------------------------------------------------
with tabs[3]:
    st.header("Resume + JD-Aware Interview: Fixed 40 Questions or Unlimited")
    if st.session_state.get("job_description", "").strip():
        st.success("This interview is using both the candidate resume and the optional JD/domain focus.")
        with st.expander("JD/domain focus used for this interview", expanded=False):
            st.json(jd_match_summary())
    else:
        st.info("No JD/domain focus provided. ASHU is using resume + target role only.")
    mode = st.radio("Interview mode", ["Fixed 40 questions", "Unlimited questions"], horizontal=True, index=0)
    st.session_state.interview_mode = mode
    answered = len(st.session_state.resume_history)
    total = 40 if mode == "Fixed 40 questions" else None
    st.progress(min(answered / 40, 1.0) if total else 0.0, text=f"Resume interview answered {answered}{' of 40' if total else ' (unlimited)'}")
    colq1, colq2, colq3 = st.columns([0.8, 0.8, 1.2])
    with colq1:
        ask_disabled = bool(total and answered >= 40)
        if st.button("Ask next resume-aware question", disabled=ask_disabled):
            qnum = answered + 1
            cat = question_category_for_index(qnum)
            q = generate_resume_question(st.session_state.role_title, st.session_state.resume_text, st.session_state.job_description, st.session_state.resume_history, cat, qnum, model_name)
            st.session_state.resume_current_question = q
    with colq2:
        if st.button("Reset resume interview"):
            st.session_state.resume_history = []
            st.session_state.resume_current_question = None
    with colq3:
        st.caption("Question mix: resume projects, technical depth, system design, debugging, role-specific, behavioral, adaptive follow-up.")
    q = st.session_state.resume_current_question
    if q:
        qno = answered + 1 if mode == "Fixed 40 questions" else answered + 1
        st.subheader(f"Question {qno}{' of 40' if mode == 'Fixed 40 questions' else ''}")
        st.session_state.active_presenter_index = (qno - 1) % max(1, len(get_presenter_personas(st.session_state.presenter_profile)))
        speaking_presenter_html(q.get("question", ""), title=f"Interview Question {qno}", subtitle=q.get("category", "resume-aware"), button_label="Ask question like presenter")
        with st.expander("Why this question and expected evidence"):
            st.json(q)
        ans = st.text_area("Candidate answer", height=170, key=f"resume_answer_{qno}_{len(st.session_state.resume_history)}")
        if st.button("Evaluate resume answer"):
            if not ans.strip():
                st.error("Enter candidate answer first.")
            else:
                evaluation = llm_evaluate(q.get("question", ""), ans, st.session_state.role_title, "; ".join(q.get("expected_evidence", [])), model_name)
                st.session_state.resume_history.append({"question": q.get("question"), "category": q.get("category"), "answer": ans, "question_meta": q, "evaluation": evaluation})
                st.session_state.resume_current_question = None
                st.success(f"Evaluated. Score: {evaluation.get('overall_score')}/100")
                st.json(evaluation)
    else:
        st.info("Click Ask next resume-aware question.")

# -----------------------------------------------------------------------------
# Tab 4: Face-to-face round
# -----------------------------------------------------------------------------
with tabs[4]:
    st.header("Live Persona Interview Round")
    st.markdown("This uses the **selected Digital Presenter Engine** to ask serious probing questions. The reference video is not simply replayed; ASHU extracts the presenter portrait/style/readiness features and uses that digital presenter profile for delivery. Candidate recording/proctoring remains separate in Tab 0.")
    answered = len(st.session_state.face_history)
    st.progress(min(answered / 10, 1.0), text=f"Face-to-face answered {answered} of 10")
    c1, c2 = st.columns([1, 1])
    with c1:
        if st.button("Ask next face-to-face question", disabled=answered >= 10):
            qnum = answered + 1
            prompt = f"""
Return ONLY valid JSON.
Create one serious face-to-face integrity probing question to test if candidate really understands their resume/project claims. Do not accuse. Human review required.
Role: {st.session_state.role_title}
Interview basis and JD/domain context: {jd_domain_context()[:4500]}
Candidate profile: {json_dumps(st.session_state.candidate_profile)[:4000]}
Previous answers: {json_dumps(st.session_state.resume_history[-5:])[:4000]}
Presenter persona extracted features: {presenter_persona_context(st.session_state.presenter_profile)[:2500]}
Question number: {qnum}/10
Schema: {{"question":"", "probe_type":"project ownership|technical depth|debugging|security|system design|consistency|JD fit", "jd_requirement_tested":"", "expected_evidence":[], "red_flags":[], "human_review_note":""}}
""".strip()
            raw = ollama_generate(prompt, model=model_name, temperature=0.25)
            q = try_parse_json(raw)
            if not isinstance(q, dict) or not q.get("question"):
                q = {
                    "question": "Walk me through one project you claimed on your resume. Explain your exact contribution, architecture, technical challenge, and how you verified it worked.",
                    "probe_type": "project ownership",
                    "expected_evidence": ["exact contribution", "architecture", "debugging", "verification", "trade-offs"],
                    "red_flags": ["generic claims", "cannot explain implementation"],
                    "human_review_note": "Fallback question used because LLM JSON was invalid.",
                }
            st.session_state.face_current_question = q
    with c2:
        if st.button("Reset face-to-face round"):
            st.session_state.face_history = []
            st.session_state.face_current_question = None
    q = st.session_state.face_current_question
    if q:
        qno = answered + 1
        st.subheader(f"Face-to-Face Question {qno} of 10")
        st.session_state.active_presenter_index = (qno - 1) % max(1, len(get_presenter_personas(st.session_state.presenter_profile)))
        speaking_presenter_html(q.get("question", ""), title=f"Face-to-Face Question {qno}", subtitle=q.get("probe_type", "integrity probe"), button_label="Start persona asking question")
        lipsync_renderer_panel(q.get("question", ""), f"face_to_face_question_{qno}", f"face_q_{qno}")
        with st.expander("Expected evidence / integrity probe"):
            st.json(q)
        ans = st.text_area("Candidate face-to-face answer", height=170, key=f"face_answer_{qno}_{answered}")
        if st.button("Evaluate face-to-face answer"):
            if not ans.strip():
                st.error("Enter candidate answer first.")
            else:
                evaluation = llm_evaluate(q.get("question", ""), ans, st.session_state.role_title, "; ".join(q.get("expected_evidence", [])), model_name)
                st.session_state.face_history.append({"question": q.get("question"), "answer": ans, "question_meta": q, "evaluation": evaluation})
                st.session_state.face_current_question = None
                st.success(f"Face-to-face answer evaluated: {evaluation.get('overall_score')}/100")
                st.json(evaluation)
    else:
        st.info("Click Ask next face-to-face question.")

# -----------------------------------------------------------------------------
# Tab 5: Coding Round
# -----------------------------------------------------------------------------
with tabs[5]:
    st.header("Coding Round — 5 Questions")
    answered = len(st.session_state.coding_history)
    st.progress(min(answered / 5, 1.0), text=f"Coding answered {answered} of 5")
    if st.button("Generate coding question", disabled=answered >= 5):
        qnum = answered + 1
        prompt = f"""
Return ONLY valid JSON. Generate coding question {qnum}/5 for role {st.session_state.role_title}.
If a JD/domain focus is available, make the coding task relevant to that JD domain and required skills. Otherwise use resume/role context.
Schema: {{"problem_title":"", "question":"", "difficulty":"easy|medium|hard", "input_output_format":"", "examples":[], "constraints":[], "evaluation_focus":["correctness","complexity","edge cases","code quality","security"]}}
Resume: {st.session_state.resume_text[:3000]}
JD/domain context: {jd_domain_context()[:4500]}
""".strip()
        raw = ollama_generate(prompt, model=model_name, temperature=0.25)
        q = try_parse_json(raw)
        if not isinstance(q, dict) or not q.get("question"):
            fallback_qs = [
                "Write a function to validate a JWT-like token payload and reject expired tokens. Explain edge cases.",
                "Design an API rate limiter. Provide code or pseudocode and complexity.",
                "Given a list of API logs, find top failing endpoints and error rates.",
                "Implement LRU cache and explain time complexity.",
                "Find duplicate records in a database export and propose SQL constraints to prevent them.",
            ]
            q = {"problem_title": f"Coding Problem {qnum}", "question": fallback_qs[(qnum-1) % 5], "difficulty": "medium", "evaluation_focus": ["correctness", "complexity", "edge cases", "code quality", "security"], "llm_fallback_used": True}
        st.session_state.coding_questions.append(q)
    if st.session_state.coding_questions and answered < len(st.session_state.coding_questions):
        q = st.session_state.coding_questions[answered]
        st.subheader(f"Coding Question {answered + 1} of 5 — {q.get('problem_title','')}")
        st.info(q.get("question", ""))
        with st.expander("Problem metadata"):
            st.json(q)
        code = st.text_area("Candidate code / solution explanation", height=250, key=f"coding_{answered}")
        if st.button("Evaluate coding answer"):
            if not code.strip():
                st.error("Enter code/solution first.")
            else:
                eval_prompt = f"""
Return ONLY valid JSON. Evaluate coding answer. Human review required.
Problem: {q.get('question')}
JD/domain context: {jd_domain_context()[:3000]}
Candidate solution/code: {code}
Schema: {{"overall_score":0-100,"score_band":"Strong|Good|Needs improvement|Weak","rubric":{{"correctness":0-25,"complexity":0-20,"edge_cases":0-20,"code_quality":0-20,"security":0-15}},"strengths":[],"weaknesses":[],"bugs_or_risks":[],"improvement_advice":"","ideal_solution_outline":[],"human_review_required":true}}
""".strip()
                raw = ollama_generate(eval_prompt, model=model_name, temperature=0.1)
                evaluation = try_parse_json(raw)
                if not isinstance(evaluation, dict) or "overall_score" not in evaluation:
                    evaluation = heuristic_score(q.get("question", ""), code, "correctness complexity edge cases code quality")
                    evaluation["llm_fallback_used"] = True
                st.session_state.coding_history.append({"question": q.get("question"), "question_meta": q, "code": code, "evaluation": evaluation})
                st.success(f"Coding evaluated: {evaluation.get('overall_score')}/100")
                st.json(evaluation)
    else:
        st.info("Generate the next coding question. Exactly 5 questions are allowed.")

# -----------------------------------------------------------------------------
# Tab 6: Adaptive Training
# -----------------------------------------------------------------------------
with tabs[6]:
    st.header("Adaptive Training Studio")
    st.markdown(
        "ASHU can teach in two ways: **from interview/coding performance analysis** or from a "
        "**topic typed by the candidate**. The selected presenter persona teaches with slides, "
        "checkpoint questions, quiz, pause/resume controls, and downloadable training content."
    )

    source_mode = st.radio(
        "Choose training source",
        [
            "Use interview analysis to recommend topics",
            "Candidate enters a topic",
            "Use JD/domain training priorities",
            "Choose from training catalog",
        ],
        horizontal=True,
        index=1,
    )

    # Common delivery settings. No audience field is shown because this product is interview/training focused.
    settings_col1, settings_col2, settings_col3 = st.columns([1, 1, 1])
    with settings_col1:
        training_depth = st.selectbox(
            "Training depth",
            ["Interview-ready practical", "Beginner", "Intermediate", "Advanced", "Expert deep-dive"],
            index=0,
        )
    with settings_col2:
        language = st.selectbox("Training language", ["English", "Hindi", "English + Hindi"], index=0)
    with settings_col3:
        style = st.selectbox(
            "Presenter delivery style",
            ["Friendly mentor", "Serious interviewer", "Professor style", "Corporate trainer"],
            index=0,
        )
    duration = st.slider("Target training duration in minutes", 2, 30, 8)

    st.markdown("---")

    selected_topic_from_ui = st.session_state.selected_training_topic

    if source_mode == "Use interview analysis to recommend topics":
        st.subheader("Training from candidate performance analysis")
        st.caption(
            "ASHU reviews interview answers, face-to-face answers, and coding evaluations, then suggests what the candidate should learn next."
        )
        if st.button("Analyze performance and suggest learning topics", type="primary"):
            rows = flatten_score_rows()
            prompt = f"""
Return ONLY valid JSON array of 5-8 learning recommendations for candidate upskilling.
Use candidate scorecard, weak answers, resume profile, face-to-face performance, coding results, and the optional JD/domain profile. If JD is provided, prioritize learning topics that close resume-vs-JD gaps.
Each item schema: {{"topic":"", "reason":"", "priority":"high|medium|low", "source_round":"", "learning_outcome":"", "practice_task":""}}
Score rows: {json_dumps(rows)[:8000]}
Resume profile: {json_dumps(st.session_state.candidate_profile)[:3000]}
JD/domain context: {jd_domain_context()[:4000]}
""".strip()
            raw = ollama_generate(prompt, model=model_name, temperature=0.2)
            parsed = try_parse_json(raw)
            if not isinstance(parsed, list):
                parsed = [
                    {"topic": "REST API security and JWT authentication", "reason": "Strengthen backend security answers with concrete flow, token claims, expiry, and refresh handling.", "priority": "high", "source_round": "fallback", "learning_outcome": "Explain authentication flow, token validation, secure endpoints, and common JWT risks.", "practice_task": "Explain login, refresh-token, and protected-route flow in 90 seconds."},
                    {"topic": "Backend scalability and performance optimization", "reason": "Improve system-design answers using caching, indexing, pagination, queues, and monitoring.", "priority": "high", "source_round": "fallback", "learning_outcome": "Design a scalable backend and justify performance trade-offs.", "practice_task": "Explain how you would optimize a slow API."},
                    {"topic": "Debugging production APIs", "reason": "Build stronger root-cause analysis and incident-handling answers.", "priority": "medium", "source_round": "fallback", "learning_outcome": "Use logs, traces, metrics, reproduction steps, rollback, and prevention.", "practice_task": "Walk through a production bug from symptom to fix."},
                    {"topic": "Coding edge cases and complexity analysis", "reason": "Improve coding-round correctness, edge-case handling, and Big-O explanation.", "priority": "medium", "source_round": "fallback", "learning_outcome": "Write cleaner solutions and defend complexity.", "practice_task": "List edge cases before coding a solution."},
                ]
            st.session_state.adaptive_recommendations = parsed

        if st.session_state.adaptive_recommendations:
            st.markdown("### Recommended learning paths")
            for idx, rec in enumerate(st.session_state.adaptive_recommendations, 1):
                with st.container(border=True):
                    priority = str(rec.get("priority", "medium")).upper()
                    st.markdown(f"**{idx}. {rec.get('topic')}** · `{priority}`")
                    st.write(rec.get("reason", ""))
                    st.caption(f"Outcome: {rec.get('learning_outcome', '')}")
                    if rec.get("practice_task"):
                        st.caption(f"Practice task: {rec.get('practice_task')}")
                    if st.button(f"Use this topic for training", key=f"train_rec_{idx}"):
                        st.session_state.selected_training_topic = rec.get("topic", "")
                        selected_topic_from_ui = st.session_state.selected_training_topic
                        st.success(f"Selected training topic: {selected_topic_from_ui}")
        else:
            st.info("Click the analysis button after completing interview/coding rounds, or switch to candidate-entered topic.")

    elif source_mode == "Use JD/domain training priorities":
        st.subheader("Training from JD/domain requirements")
        if not st.session_state.get("job_description", "").strip():
            st.warning("No JD/domain focus provided yet. Add it in the Resume, Role & Optional JD Domain Setup tab, or choose another training source.")
        else:
            priorities = (st.session_state.get("jd_profile", {}) or {}).get("training_priorities", []) or (st.session_state.get("candidate_profile", {}) or {}).get("recommended_training_domains", [])
            if not priorities:
                priorities = ["Role-specific interview preparation", "Core domain skills", "System design for target role", "Coding practice for target role"]
            st.caption("ASHU will train on skills and gaps required by the uploaded/pasted JD.")
            st.json(jd_match_summary())
            cols = st.columns(2)
            for idx, topic_item in enumerate(priorities[:12]):
                with cols[idx % 2]:
                    if st.button(f"Train on JD priority: {topic_item}", key=f"jd_train_{idx}"):
                        st.session_state.selected_training_topic = str(topic_item)
                        selected_topic_from_ui = st.session_state.selected_training_topic
                        st.success(f"Selected JD training topic: {selected_topic_from_ui}")
            selected_topic_from_ui = st.text_input("Selected JD/domain training topic", value=st.session_state.selected_training_topic)
            st.session_state.selected_training_topic = selected_topic_from_ui

    elif source_mode == "Candidate enters a topic":
        st.subheader("Training from candidate-requested topic")
        st.caption("Candidate can type any topic. ASHU will generate a practical class with slides and checkpoints.")
        selected_topic_from_ui = st.text_input(
            "Topic to teach",
            value=st.session_state.selected_training_topic,
            placeholder="Example: REST API security and JWT authentication",
        )
        st.session_state.selected_training_topic = selected_topic_from_ui

    else:
        st.subheader("Choose from training catalog")
        st.caption("Select a ready-made learning path, or use the sidebar Training Hub for quick selection.")
        training_topic_gallery()
        selected_topic_from_ui = st.text_input(
            "Selected catalog topic",
            value=st.session_state.selected_training_topic,
        )
        st.session_state.selected_training_topic = selected_topic_from_ui

    st.markdown("---")
    st.subheader("Generate training session")
    topic = st.session_state.selected_training_topic.strip()
    train_disabled = not bool(topic)
    if topic:
        st.success(f"Training topic ready: {topic}")
        render_module_deep_dive(topic)
    else:
        st.warning("Select a recommended topic or enter a candidate-requested topic first.")

    cache_key = build_training_cache_key(
        topic=topic,
        source_mode=source_mode,
        language=language,
        duration=duration,
        training_depth=training_depth,
        delivery_style=style,
        presenter_profile=st.session_state.presenter_profile,
        resume_text=st.session_state.get("resume_text", ""),
        jd_text=st.session_state.get("job_description", ""),
        model_name=model_name,
        app_version="v46",
    ) if topic else ""

    cache_hit = bool(cache_key and training_cache_exists(cache_key))
    col_cache_a, col_cache_b, col_cache_c = st.columns([0.9, 0.65, 0.65])
    with col_cache_a:
        if cache_hit:
            st.success("Cached training found for this exact topic/configuration. Click generate to load instantly.")
        else:
            st.caption("No exact cache match yet. First generation will be saved for future reuse.")
    with col_cache_b:
        force_regenerate = st.checkbox("Force regenerate", value=False, disabled=train_disabled)
    with col_cache_c:
        if cache_key:
            st.caption(f"Cache key: `{cache_key}`")

    with st.expander("Previously generated training cache", expanded=False):
        matches = search_training_cache(topic)
        if not matches:
            st.caption("No saved training modules found yet.")
        else:
            for i, row in enumerate(matches[:8]):
                cols = st.columns([1.8, 0.8, 0.65])
                cols[0].markdown(f"**{row.get('topic','Untitled')}**  \
<span class='small-muted'>{row.get('generated_at','')} · {row.get('source_mode','')} · {row.get('training_depth','')}</span>", unsafe_allow_html=True)
                if cols[1].button("Load", key=f"load_training_cache_{i}_{row.get('cache_key')}"):
                    cached = load_training_cache(row.get("cache_key", ""))
                    st.session_state.training_content = cached.get("training_content", {})
                    st.session_state.training_notes_md = cached.get("training_notes_md", "")
                    st.session_state.training_pdf_path = cached.get("pdf_path", "")
                    st.session_state.last_training_cache_key = row.get("cache_key", "")
                    st.session_state.last_training_cache_source = "manual-cache-load"
                    st.success("Loaded selected cached training module.")
                    st.rerun()
                if cols[2].button("Delete", key=f"delete_training_cache_{i}_{row.get('cache_key')}"):
                    clear_training_cache_item(row.get("cache_key", ""))
                    st.warning("Cached module deleted.")
                    st.rerun()

    if st.button("Generate deep interactive training with PDF notes", type="primary", disabled=train_disabled):
        if cache_key and training_cache_exists(cache_key) and not force_regenerate:
            cached = load_training_cache(cache_key)
            st.session_state.training_content = cached.get("training_content", {})
            st.session_state.training_notes_md = cached.get("training_notes_md", "")
            st.session_state.training_pdf_path = cached.get("pdf_path", "")
            st.session_state.last_training_cache_key = cache_key
            st.session_state.last_training_cache_source = "exact-cache-hit"
            st.success("Loaded training from persistent cache. No LLM regeneration was needed.")
        else:
            prompt = f"""
Return ONLY valid JSON for an interactive digital-human training session.
Topic: {topic}
Structured module subtopics: {json_dumps(build_deep_subtopics(topic))}
Training source mode: {source_mode}
Interview/JD domain context: {jd_domain_context()[:4500]}
Training must connect the topic to the target role, JD requirements, and interview readiness when JD is provided.
Training depth: {training_depth}
Language: {language}
Duration minutes: {duration}
Presenter delivery style: {style}
Presenter persona extracted features: {presenter_persona_context(st.session_state.presenter_profile)[:2500]}
Presenter display name: {st.session_state.presenter_profile.get('display_name')}
Candidate weak areas and recommended topics: {json_dumps(st.session_state.adaptive_recommendations)[:3000]}
Candidate profile with resume-JD gaps: {json_dumps(st.session_state.candidate_profile)[:3500]}
Create content for an interview-preparation product. Make it very deep and extensive.
Requirements:
- Generate 10-14 training segments for the selected topic.
- Every segment must teach one clear subtopic.
- Each segment must include a trainer script of at least 120-180 words.
- Include practical examples, implementation details, interview framing, mistakes, edge cases, and checkpoints.
- Create PPT-style slide bullets, visual descriptions, and one activity/checkpoint per segment.
- Use the selected presenter persona naturally as the teacher.
Schema:
{{
 "title":"",
 "learning_objectives":[],
 "module_subtopics":[{{"name":"", "detail":""}}],
 "segments":[{{"title":"", "subtopic":"", "script":"", "slide_bullets":[], "visual_description":"", "example":"", "code_demo":"", "checkpoint_question":"", "expected_answer":"", "common_mistake":""}}],
 "quiz":[{{"question":"", "options":[], "answer":"", "explanation":""}}],
 "handout":"",
 "avatar_delivery_notes":[]
}}
""".strip()
            with st.spinner("Generating new deep training module with LLM. This will be cached after completion..."):
                raw = ollama_generate(prompt, model=model_name, temperature=0.25)
                training = try_parse_json(raw)
            if not isinstance(training, dict) or not training.get("segments"):
                training = {
                    "title": f"Interview-Ready Training: {topic}",
                    "learning_objectives": [
                        f"Understand {topic} clearly",
                        "Explain the concept with a real project example",
                        "Answer interview questions using a structured framework",
                    ],
                    "module_subtopics": build_deep_subtopics(topic),
                    "segments": [
                        {"title": f"Segment 1: Concept clarity for {topic}", "subtopic": "Concept clarity", "script": f"Let us start with {topic}. I will explain what it means, why interviewers ask about it, and where it appears in real projects.", "slide_bullets": ["Definition", "Why interviewers ask this", "Real project relevance"], "visual_description": "Concept overview slide", "checkpoint_question": f"Explain {topic} in your own words with one example.", "expected_answer": "A clear definition plus a practical example."},
                        {"title": "Segment 2: Implementation and trade-offs", "subtopic": "Implementation", "script": "Now we move to implementation. A strong candidate should explain architecture, flow, tools, edge cases, security, and trade-offs.", "slide_bullets": ["Architecture", "Implementation flow", "Edge cases", "Trade-offs"], "visual_description": "Implementation flow slide", "checkpoint_question": "What implementation detail would make your answer more credible?", "expected_answer": "Specific method, technology, validation step, or design trade-off."},
                        {"title": "Segment 3: Interview answer framework", "subtopic": "Interview answer framework", "script": "For interview answers, use Problem, Approach, Implementation, Result, and Learning. This converts a generic answer into an evidence-based answer.", "slide_bullets": ["Problem", "Approach", "Implementation", "Result", "Learning"], "visual_description": "Answer framework slide", "checkpoint_question": "Give a one-minute structured answer on this topic.", "expected_answer": "Problem → Approach → Implementation → Result → Learning."},
                    ],
                    "quiz": [{"question": f"What makes an answer on {topic} interview-ready?", "options": ["Concrete example and trade-offs", "Only definition", "Unrelated theory", "No implementation detail"], "answer": "Concrete example and trade-offs", "explanation": "Interviewers need evidence that the candidate actually implemented or understood the concept."}],
                    "handout": f"Study notes for {topic}: definition, architecture, implementation flow, common mistakes, examples, and interview answer structure.",
                    "avatar_delivery_notes": ["Speak naturally", "Pause after each segment", "Ask checkpoint questions", "Give feedback before moving ahead"],
                    "llm_fallback_used": True,
                }
            st.session_state.training_content = training
            st.session_state.last_training_cache_key = cache_key
            st.session_state.last_training_cache_source = "new-generation"
            save_training_cache(
                cache_key=cache_key,
                training=training,
                topic=topic,
                metadata={
                    "source_mode": source_mode,
                    "language": language,
                    "duration": duration,
                    "training_depth": training_depth,
                    "delivery_style": style,
                    "model_name": model_name,
                    "resume_hash": compute_text_hash(st.session_state.get("resume_text", "")),
                    "jd_hash": compute_text_hash(st.session_state.get("job_description", "")),
                    "presenter_id": presenter_cache_identity(st.session_state.presenter_profile),
                },
            )
            st.success("Interactive training generated and saved to persistent cache.")

    st.markdown("---")
    if st.session_state.training_content:
        training = st.session_state.training_content
        if st.session_state.get("last_training_cache_key"):
            cache_source = st.session_state.get("last_training_cache_source", "")
            st.caption(f"Training cache: {cache_source} · `{st.session_state.last_training_cache_key}`")
        st.subheader("Real recorded-voice lecture video")
        st.caption(
            "Use this production path for your saved voice sample and real SadTalker/Wav2Lip video. "
            "The browser demo below is optional and does not use your recorded voice."
        )
        idx = st.selectbox(
            "Choose training segment",
            list(range(len(training.get("segments", [])))),
            format_func=lambda i: training["segments"][i].get("title", f"Segment {i+1}"),
        )
        seg_for_render = training.get("segments", [])[int(idx)]
        render_text = f"{seg_for_render.get('title', '')}. {seg_for_render.get('script', '')}. Checkpoint question: {seg_for_render.get('checkpoint_question', '')}"
        seg_key_prefix = f"training_seg_{int(idx)}"
        lipsync_renderer_panel(render_text, f"training_segment_{int(idx)+1}_{safe_filename(st.session_state.selected_training_topic or 'topic')}", seg_key_prefix)
        generated_audio_for_assistant = st.session_state.get(f"{seg_key_prefix}_tts_audio_path", "")
        out_dir_for_assistant = st.session_state.get(f"{seg_key_prefix}_lipsync_out_dir", "")
        if not generated_audio_for_assistant:
            possible_audio = Path(out_dir_for_assistant) / "tts_audio.wav" if out_dir_for_assistant else None
            if possible_audio and possible_audio.exists():
                generated_audio_for_assistant = str(possible_audio)
        # Restore assistant audio/video after page refresh by scanning latest render folders for this segment.
        segment_render_prefix = f"training_segment_{int(idx)+1}_"
        latest_segment_dirs = sorted(
            [d for d in LIPSYNC_DIR.glob(segment_render_prefix + "*") if d.is_dir()],
            key=lambda d: d.stat().st_mtime,
            reverse=True,
        )
        if not generated_audio_for_assistant:
            for d in latest_segment_dirs:
                p_audio = d / "tts_audio.wav"
                if p_audio.exists() and p_audio.stat().st_size > 1000:
                    generated_audio_for_assistant = str(p_audio)
                    break
        st.subheader("Teaching assistant preview")
        generated_video_for_assistant = ""
        possible_video_for_assistant = None
        if out_dir_for_assistant:
            possible_video_for_assistant = Path(out_dir_for_assistant) / "talking_presenter_output.mp4"
        if possible_video_for_assistant and possible_video_for_assistant.exists():
            generated_video_for_assistant = str(possible_video_for_assistant)
        elif st.session_state.get("last_lipsync_video") and Path(st.session_state.last_lipsync_video).exists():
            generated_video_for_assistant = st.session_state.last_lipsync_video
        if not generated_video_for_assistant:
            for d in latest_segment_dirs:
                p_video = d / "talking_presenter_output.mp4"
                if p_video.exists() and p_video.stat().st_size > 1000:
                    generated_video_for_assistant = str(p_video)
                    break
                found_video = latest_video_in_folder(d)
                if found_video and found_video.exists():
                    generated_video_for_assistant = str(found_video)
                    break

        if generated_video_for_assistant and Path(generated_video_for_assistant).exists():
            st.success("Generated lecture video is available inside the teaching assistant. Use: Play generated video in assistant.")
        elif generated_audio_for_assistant and Path(generated_audio_for_assistant).exists():
            st.success("Generated XTTS voice is available for the teaching assistant. Use: Play generated XTTS voice in assistant.")
        else:
            st.warning(
                "This visible assistant panel uses browser voice until generated XTTS audio/video is ready. "
                "After rendering or after Refresh pipeline status, it will show generated voice/video buttons inside the assistant. The app also restores the latest generated media after page refresh."
            )
        training_presenter_html(training, int(idx), generated_audio_for_assistant, generated_video_for_assistant)
        st.subheader("Checkpoint question")
        seg = training.get("segments", [])[int(idx)]
        st.info(seg.get("checkpoint_question", ""))
        checkpoint_answer = st.text_area("Candidate checkpoint answer", key=f"checkpoint_{idx}", height=120)
        if st.button("Evaluate checkpoint answer"):
            ev = llm_evaluate(seg.get("checkpoint_question", ""), checkpoint_answer, "Training learner", seg.get("expected_answer", ""), model_name)
            st.json(ev)
        st.subheader("Preview and download training notes")
        notes_md = training_notes_markdown(training, st.session_state.selected_training_topic)
        pdf_bytes = training_notes_pdf_bytes(training, st.session_state.selected_training_topic)
        pdf_filename = safe_filename(st.session_state.selected_training_topic or "training_notes") + "_notes.pdf"

        preview_tab, notes_tab, downloads_tab = st.tabs(["PDF preview", "Readable notes", "Downloads"])
        with preview_tab:
            if SimpleDocTemplate is not None and pdf_bytes:
                render_pdf_preview(pdf_bytes, pdf_filename)
            else:
                st.info("ReportLab PDF support is not available, so showing readable notes instead.")
                render_markdown_notes_preview(notes_md)
        with notes_tab:
            render_markdown_notes_preview(notes_md)
        with downloads_tab:
            st.info("Downloaded files are saved by your browser, usually in the Downloads folder. You can also preview the notes in the tabs above before downloading.")
            st.download_button(
                "Download training notes PDF",
                data=pdf_bytes,
                file_name=pdf_filename,
                mime="application/pdf" if SimpleDocTemplate is not None else "text/markdown",
            )
            st.download_button(
                "Download editable notes Markdown",
                data=notes_md,
                file_name=safe_filename(st.session_state.selected_training_topic or "training_notes") + "_notes.md",
                mime="text/markdown",
            )
            slides_payload = {"title": training.get("title"), "segments": training.get("segments", []), "quiz": training.get("quiz", [])}
            st.download_button(
                "Download slide/quiz JSON",
                data=json_dumps(slides_payload),
                file_name=safe_filename(st.session_state.selected_training_topic or "training_slides") + "_slides.json",
                mime="application/json",
            )
        with st.expander("Training content JSON", expanded=False):
            st.json(training)

# -----------------------------------------------------------------------------
# Tab 7: Live Human-Led Session Capture
# -----------------------------------------------------------------------------
with tabs[7]:
    st.header("Live Human-Led Training / Interview")
    st.markdown("Record a real trainer-led class or a real interviewer-led interview, then attach the session video, transcript, screenshots, and notes to the final ASHU bundle for later demonstration or audit.")
    live_human_session_panel()

# -----------------------------------------------------------------------------
# Tab 8: Evaluation Report
# -----------------------------------------------------------------------------
with tabs[8]:
    st.header("Evaluation Report & Bundle")
    rows = flatten_score_rows()
    if rows:
        df = pd.DataFrame(rows)
        st.dataframe(df, use_container_width=True)
        avg = round(df["overall_score"].fillna(0).mean(), 2) if "overall_score" in df else 0
        st.metric("Average score", f"{avg}/100")
    else:
        st.info("No evaluated answers yet.")
    report_md = build_final_report()
    st.download_button("Download candidate_final_report.md", data=report_md, file_name="candidate_final_report.md", mime="text/markdown")
    if st.button("Build complete candidate report bundle ZIP"):
        zip_path = make_report_bundle()
        st.session_state.latest_zip_path = str(zip_path)
        st.success(f"Bundle created: {zip_path.name}")
    latest = st.session_state.get("latest_zip_path")
    if latest and Path(latest).exists():
        st.download_button("Download complete_candidate_report_bundle.zip", data=Path(latest).read_bytes(), file_name="complete_candidate_report_bundle.zip", mime="application/zip")

# -----------------------------------------------------------------------------
# Tab 9: Architecture
# -----------------------------------------------------------------------------
with tabs[9]:
    st.header("Technical Architecture")
    st.markdown("""
<div class='info-box'><b>Architecture view:</b> ASHU Mentor AI is organized as a local-first, consent-aware interview and adaptive training studio. The diagrams below show runtime flow, voice/video generation, caching, and evidence/reporting.</div>
    """, unsafe_allow_html=True)

    arch_css = """
<style>
.arch-wrap{display:flex;flex-direction:column;gap:22px;margin-top:12px}.arch-title{font-size:20px;font-weight:900;color:#071A3D;margin:4px 0 8px}.arch-row{display:flex;align-items:stretch;gap:10px;flex-wrap:wrap}.arch-box{min-width:175px;max-width:230px;flex:1;background:linear-gradient(180deg,#F8FBFF,#EAF4FF);border:1px solid #CFE1FF;border-radius:18px;padding:14px;box-shadow:0 8px 22px rgba(7,26,61,.08)}.arch-box b{display:block;color:#0B5FFF;margin-bottom:5px}.arch-box span{font-size:13px;color:#24324B;line-height:1.35}.arch-arrow{display:flex;align-items:center;justify-content:center;font-size:28px;color:#0B5FFF;font-weight:900;min-width:24px}.arch-note{background:#071A3D;color:#EAF7FF;border-radius:16px;padding:14px;line-height:1.45}.arch-note b{color:#35D6FF}.arch-lane{border-left:5px solid #35D6FF;padding-left:16px}.arch-mini{font-size:12px;color:#58708A;margin-top:8px}.arch-safe{background:#FFF7E8;border-left:5px solid #FF8A00;border-radius:14px;padding:14px;color:#071A3D}</style>
"""
    st.markdown(arch_css, unsafe_allow_html=True)

    st.markdown("""
<div class='arch-wrap'>
  <div class='arch-lane'>
    <div class='arch-title'>1. Candidate Interview & Evaluation Runtime</div>
    <div class='arch-row'>
      <div class='arch-box'><b>Candidate Inputs</b><span>Resume, optional JD/domain focus, camera/mic consent, answers, code, checkpoint responses.</span></div>
      <div class='arch-arrow'>→</div>
      <div class='arch-box'><b>Local Context Builder</b><span>Extracts skills, projects, gaps, weak areas, recommended topics, and evidence fields.</span></div>
      <div class='arch-arrow'>→</div>
      <div class='arch-box'><b>Local LLM Engine</b><span>Ollama/Qwen generates questions, training scripts, rubrics, feedback, and summaries.</span></div>
      <div class='arch-arrow'>→</div>
      <div class='arch-box'><b>Evaluation Report</b><span>Scores, strengths, gaps, human-review notes, CSV/PDF/ZIP evidence export.</span></div>
    </div>
  </div>

  <div class='arch-lane'>
    <div class='arch-title'>2. Digital Presenter + Voice/Video Generation</div>
    <div class='arch-row'>
      <div class='arch-box'><b>Authorized Presenter</b><span>Built-in avatar or approved photo/video/URL with presenter release confirmation.</span></div>
      <div class='arch-arrow'>→</div>
      <div class='arch-box'><b>Voice Sample</b><span>Optional 30–90 sec authorized sample stored locally and prefetched for reuse.</span></div>
      <div class='arch-arrow'>→</div>
      <div class='arch-box'><b>XTTS Voice Env</b><span>Separate <code>voice</code> conda env creates consent-based generated lecture audio.</span></div>
      <div class='arch-arrow'>→</div>
      <div class='arch-box'><b>Lip-Sync Renderer</b><span>SadTalker for photo route, Wav2Lip for video route, browser-safe MP4 conversion.</span></div>
      <div class='arch-arrow'>→</div>
      <div class='arch-box'><b>Streaming Assistant</b><span>YouTube-style player with play/pause, seek, speed, volume, and cached video prefetch.</span></div>
    </div>
  </div>

  <div class='arch-lane'>
    <div class='arch-title'>3. Background Pipeline & Cache Reuse</div>
    <div class='arch-row'>
      <div class='arch-box'><b>Start Pipeline</b><span>User starts full voice + video generation or prefetches previous outputs.</span></div>
      <div class='arch-arrow'>→</div>
      <div class='arch-box'><b>Background Voice Job</b><span>XTTS runs without freezing Streamlit; progress shows staged state.</span></div>
      <div class='arch-arrow'>→</div>
      <div class='arch-box'><b>Background Render Job</b><span>Renderer runs asynchronously, logs progress, and outputs MP4.</span></div>
      <div class='arch-arrow'>→</div>
      <div class='arch-box'><b>Cache Store</b><span><code>lipsync_renders/</code> keeps tts_audio.wav, manifest.json, logs, MP4, and browser MP4.</span></div>
      <div class='arch-arrow'>→</div>
      <div class='arch-box'><b>Prefetch Latest</b><span>Loads last generated audio/video for the same segment to avoid slow regeneration.</span></div>
    </div>
  </div>

  <div class='arch-lane'>
    <div class='arch-title'>4. Evidence, Recording & Safety Boundary</div>
    <div class='arch-row'>
      <div class='arch-box'><b>Candidate Capture</b><span>Candidate camera/mic/screen capture supports performance review and audit trail.</span></div>
      <div class='arch-arrow'>→</div>
      <div class='arch-box'><b>Separate Presenter Path</b><span>Candidate video is never used as presenter avatar or voice source.</span></div>
      <div class='arch-arrow'>→</div>
      <div class='arch-box'><b>Consent Controls</b><span>Presenter, candidate, and voice workflows require explicit authorization.</span></div>
      <div class='arch-arrow'>→</div>
      <div class='arch-box'><b>Export Bundle</b><span>Reports, logs, screenshots, recordings, and generated media packaged for review.</span></div>
    </div>
  </div>

  <div class='arch-safe'><b>Safety boundary:</b> the app supports consent-based presenter and voice generation only. It must not be used for non-consensual cloning, deceptive impersonation, or unauthorized reuse of a person’s image/voice.</div>
</div>
""", unsafe_allow_html=True)

    st.subheader("Runtime sequence: training video generation")
    st.markdown("""
```text
Training topic + segment script
        ↓
Prefetch latest cached segment output if available
        ↓
If not cached: XTTS voice env generates tts_audio.wav
        ↓
Create manifest.json + script.txt + presenter source package
        ↓
SadTalker/Wav2Lip background render creates MP4
        ↓
Browser-safe MP4 conversion for Streamlit/Chrome playback
        ↓
Teaching assistant streaming player + download final lecture video
```
""")

    st.subheader("Current state objects")
    with st.expander("Candidate artifacts"):
        st.json(st.session_state.candidate_artifacts)
    with st.expander("Presenter profile"):
        st.json(st.session_state.presenter_profile)
    with st.expander("Ollama status"):
        st.json(check_ollama(model_name))

st.markdown("---")
st.caption("ASHU Mentor AI Studio v72 | Local SadTalker/Wav2Lip Runtime Health Check + JD-Aware Interview & Training | Human review required.")
