#!/usr/bin/env bash
set -e
mkdir -p ~/.streamlit
cat > ~/.streamlit/config.toml <<'CFG'
[server]
fileWatcherType = "none"
runOnSave = false

[browser]
gatherUsageStats = false
CFG
printf "Done. Restart Streamlit. Use: ./RUN_LINUX_SILENT.sh\n"
